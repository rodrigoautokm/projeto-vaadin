package com.exemplo;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ColumnConfigUsuarioRepository extends JpaRepository<ColumnConfigUsuario, Integer> {

    List<ColumnConfigUsuario> findByUsuarioAndClassName(String usuario, String className);

    List<ColumnConfigUsuario> findByUsuarioAndClassNameAndFieldName(String usuario, String className, String fieldName);
}
