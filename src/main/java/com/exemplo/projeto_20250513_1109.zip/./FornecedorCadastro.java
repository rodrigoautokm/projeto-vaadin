package com.exemplo;

import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.formlayout.FormLayout;
import com.vaadin.flow.component.textfield.TextField;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Arrays;
import java.util.List;

public class FornecedorCadastro extends GenericaCadastro<Fornecedor> {

    private final FornecedorRepository repository;
    private TextField nmFornecedorField;
    private ComboBox<String> tipoField;

    @Autowired
    public FornecedorCadastro(FornecedorRepository repository) {
        super(repository, new Fornecedor(), savedFornecedor -> {});
        this.repository = repository;
    }

    @Override
    protected String getTitle() {
        return "Cadastro de Fornecedor";
    }

    @Override
    protected String getClassName() {
        return "fornecedor";
    }

    @Override
    protected List<String> getCamposFixos() {
        return Arrays.asList("nmFornecedor", "tipo");
    }

    @Override
    protected String getSuccessMessage() {
        return "Fornecedor salvo com sucesso!";
    }

    @Override
    protected void buildForm() {
        FormLayout form = new FormLayout();

        nmFornecedorField = new TextField("Nome");
        nmFornecedorField.setRequired(true);

        tipoField = new ComboBox<>("Tipo");
        tipoField.setItems("Física", "Jurídica");

        // Adicionar os campos ao FormLayout
        form.add(nmFornecedorField, tipoField);

        // Vincular os campos ao binder
        binder.forField(nmFornecedorField)
              .asRequired("Nome é obrigatório")
              .bind("nmFornecedor");
        binder.forField(tipoField)
              .bind("tipo");

        // Adicionar o FormLayout ao dialog
        dialog.add(form);
    }

    @Override
    protected void beforeSave(Fornecedor entity) {
        // Atualizar o entity com os valores dos campos do formulário
        entity.setNmFornecedor(nmFornecedorField.getValue());
        entity.setTipo(tipoField.getValue());
    }
}