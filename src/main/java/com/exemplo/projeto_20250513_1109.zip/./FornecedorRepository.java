package com.exemplo;

import org.springframework.stereotype.Repository;

@Repository
public interface FornecedorRepository extends GenericRepository<Fornecedor, Integer> {
}