package com.exemplo;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Objects;

@Entity
@Table(name = "filtro_usuario")
@IdClass(FiltroUsuarioId.class)
public class FiltroUsuario {

    @Id
    @Column(name = "usuario")
    private String usuario;

    @Id
    @Column(name = "view_id")
    private String viewId;

    @Id
    @Column(name = "coluna")
    private String coluna;

    @Column(name = "filtros")
    private String filtros;

    public FiltroUsuario() {}

    public FiltroUsuario(String usuario, String viewId, String coluna, String filtros) {
        this.usuario = usuario;
        this.viewId = viewId;
        this.coluna = coluna;
        this.filtros = filtros;
    }

    public String getUsuario() { return usuario; }
    public void setUsuario(String usuario) { this.usuario = usuario; }

    public String getViewId() { return viewId; }
    public void setViewId(String viewId) { this.viewId = viewId; }

    public String getColuna() { return coluna; }
    public void setColuna(String coluna) { this.coluna = coluna; }

    public String getFiltros() { return filtros; }
    public void setFiltros(String filtros) { this.filtros = filtros; }
}

class FiltroUsuarioId implements Serializable {
    private String usuario;
    private String viewId;
    private String coluna;

    public FiltroUsuarioId() {}

    public FiltroUsuarioId(String usuario, String viewId, String coluna) {
        this.usuario = usuario;
        this.viewId = viewId;
        this.coluna = coluna;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof FiltroUsuarioId)) return false;
        FiltroUsuarioId that = (FiltroUsuarioId) o;
        return Objects.equals(usuario, that.usuario) &&
               Objects.equals(viewId, that.viewId) &&
               Objects.equals(coluna, that.coluna);
    }

    @Override
    public int hashCode() {
        return Objects.hash(usuario, viewId, coluna);
    }
}