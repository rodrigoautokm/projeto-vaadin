package com.exemplo;

import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import org.springframework.beans.factory.annotation.Autowired;

@PageTitle("Marcas")
@Route(value = "marcas", layout = MainLayout.class)
public class MarcaView extends AbstractGridView<Marca> {

    private final MarcaRepository marcaRepository;

    @Autowired
    public MarcaView(MarcaRepository marcaRepository) {
        super("Marcas", "marcas", marcaRepository::findAll);
        this.marcaRepository = marcaRepository;
    }

    @Override
    public Class<Marca> getEntityClass() {
        return Marca.class;
    }

    @Override
    protected GenericRepository<Marca, ?> getRepository() {
        return marcaRepository;
    }
}