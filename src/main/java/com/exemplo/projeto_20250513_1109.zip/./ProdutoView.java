package com.exemplo;

import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import org.springframework.beans.factory.annotation.Autowired;

@PageTitle("Produtos")
@Route(value = "produtos", layout = MainLayout.class)
public class ProdutoView extends AbstractGridView<Produto> {

    private final ProdutoRepository produtoRepository;

    @Autowired
    public ProdutoView(ProdutoRepository produtoRepository) {
        super("Produtos", "produtos", produtoRepository::findAll);
        this.produtoRepository = produtoRepository;
    }

    @Override
    public Class<Produto> getEntityClass() {
        return Produto.class;
    }

    @Override
    protected GenericRepository<Produto, ?> getRepository() {
        return produtoRepository;
    }
}