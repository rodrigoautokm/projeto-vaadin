package com.exemplo;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface FiltroUsuarioRepository extends JpaRepository<FiltroUsuario, FiltroUsuarioId> {
    List<FiltroUsuario> findByUsuarioAndViewId(String usuario, String viewId);
    void deleteByUsuarioAndViewId(String usuario, String viewId);
}