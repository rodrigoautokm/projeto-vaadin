package com.exemplo;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface OrdemColunaRepository extends JpaRepository<OrdemColuna, OrdemColunaId> {
    Optional<OrdemColuna> findByUsuarioAndViewId(String usuario, String viewId);
    void deleteByUsuarioAndViewId(String usuario, String viewId);
}