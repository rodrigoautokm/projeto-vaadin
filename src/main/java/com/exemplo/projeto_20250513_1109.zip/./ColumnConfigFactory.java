package com.exemplo;

import com.vaadin.flow.component.grid.Grid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

@Component
public class ColumnConfigFactory {

    @Autowired
    private ColumnConfigPrincipalRepository columnConfigRepository;

    public List<GridColumnConfig> loadColumnConfigs() {
        List<GridColumnConfig> columnConfigs = new ArrayList<>();
        try {
            // Buscar todas as configurações do banco de dados (genéricas e específicas)
            List<ColumnConfigEntity> entities = columnConfigRepository.findAll();

            for (ColumnConfigEntity entity : entities) {
                GridColumnConfig columnConfig = mapEntityToConfig(entity);
                if (columnConfig != null) {
                    columnConfigs.add(columnConfig);
                }
            }
        } catch (Exception e) {
            System.out.println("❌ Erro ao carregar configurações de colunas do banco de dados: " + e.getMessage());
            e.printStackTrace();
        }
        return columnConfigs;
    }

    public List<GridColumnConfig> getColumnConfigs(String viewName, Grid<?> grid, Map<String, Function<String, Object>> propertyMappers, List<String> camposFixos) {
        return getColumnConfigs(viewName, null, grid, propertyMappers, camposFixos);
    }

    public List<GridColumnConfig> getColumnConfigs(String viewName, String usuario, Grid<?> grid, Map<String, Function<String, Object>> propertyMappers, List<String> camposFixos) {
        List<GridColumnConfig> columnConfigs = new ArrayList<>();
        try {
            // Passo 1: Buscar configurações específicas para a visão (class_name = viewName) e usuario
            List<ColumnConfigEntity> specificEntities = usuario != null ?
                    columnConfigRepository.findByClassNameAndUsuario(viewName, usuario) :
                    new ArrayList<>();

            // Passo 2: Buscar configurações específicas para a visão, mas com usuario como 'default'
            List<ColumnConfigEntity> specificNoUserEntities = columnConfigRepository.findByClassNameAndUsuarioIsDefault(viewName);

            // Passo 3: Buscar configurações genéricas (class_name = 'default') e usuario
            List<ColumnConfigEntity> defaultEntities = usuario != null ?
                    columnConfigRepository.findByClassNameAndUsuario("default", usuario) :
                    new ArrayList<>();

            // Passo 4: Buscar configurações genéricas (class_name = 'default') com usuario como 'default'
            List<ColumnConfigEntity> defaultNoUserEntities = columnConfigRepository.findByClassNameDefault();

            // Mapear as configurações específicas com usuario
            for (ColumnConfigEntity entity : specificEntities) {
                GridColumnConfig columnConfig = mapEntityToConfig(entity);
                if (columnConfig != null) {
                    columnConfigs.add(columnConfig);
                }
            }

            // Mapear as configurações específicas sem usuario (se não houver configuração com usuario)
            for (ColumnConfigEntity entity : specificNoUserEntities) {
                if (columnConfigs.stream().noneMatch(config -> config.getField().equals(entity.getFieldName()))) {
                    GridColumnConfig columnConfig = mapEntityToConfig(entity);
                    if (columnConfig != null) {
                        columnConfigs.add(columnConfig);
                    }
                }
            }

            // Para cada campo fixo, verificar se há configuração ou usar a genérica
            for (String campo : camposFixos) {
                boolean hasConfig = columnConfigs.stream()
                        .anyMatch(config -> config.getField().equals(campo));

                if (!hasConfig) {
                    // Tentar buscar configuração genérica com usuario
                    ColumnConfigEntity defaultEntity = null;
                    if (usuario != null) {
                        defaultEntity = defaultEntities.stream()
                                .filter(entity -> entity.getFieldName().equals(campo))
                                .findFirst()
                                .orElse(null);
                    }

                    // Se não encontrou com usuario, buscar genérica com usuario 'default'
                    if (defaultEntity == null) {
                        defaultEntity = defaultNoUserEntities.stream()
                                .filter(entity -> entity.getFieldName().equals(campo))
                                .findFirst()
                                .orElse(null);
                    }

                    if (defaultEntity != null) {
                        GridColumnConfig columnConfig = mapEntityToConfig(defaultEntity);
                        if (columnConfig != null) {
                            columnConfigs.add(columnConfig);
                        }
                    }
                }
            }
        } catch (Exception e) {
            System.out.println("❌ Erro ao carregar configurações de colunas para view " + viewName + " e usuario " + usuario + ": " + e.getMessage());
            e.printStackTrace();
        }
        return columnConfigs;
    }

    private GridColumnConfig mapEntityToConfig(ColumnConfigEntity entity) {
        String field = entity.getFieldName();
        String header = entity.getHeader();
        String visibleText = entity.getVisible();
        String width = entity.getWidth();
        String type = entity.getDataType();
        String style = entity.getStyle();
        String filterType = entity.getFilterType();

        if (field == null || field.isEmpty()) {
            System.out.println("⚠️ Campo field_name vazio ou nulo na configuração. Ignorando essa coluna.");
            return null;
        }

        boolean visible = "1".equals(visibleText);

        // Criando o GridColumnConfig
        GridColumnConfig columnConfig = new GridColumnConfig();
        columnConfig.setField(field);
        columnConfig.setHeader(header != null ? header : field);
        columnConfig.setVisible(visible);
        columnConfig.setWidth(width != null ? width : "100px");
        columnConfig.setType(type != null ? type : "STRING");
        columnConfig.setStyle(style != null ? style : "");
        columnConfig.setFilterType(filterType != null ? filterType : "EQUALS");

        return columnConfig;
    }
}