package com.exemplo;

import org.springframework.stereotype.Repository;

@Repository
public interface MarcaRepository extends GenericRepository<Marca, Integer> {
}