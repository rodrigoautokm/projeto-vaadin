package com.exemplo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ColumnConfigRepository extends JpaRepository<ColumnConfigEntity, Integer> {

    List<ColumnConfigEntity> findAll();

    List<ColumnConfigEntity> findByClassNameAndUsuario(String className, String usuario);

    @Query("SELECT c FROM ColumnConfigEntity c WHERE c.className = :className AND (c.usuario IS NULL OR c.usuario = 'default')")
    List<ColumnConfigEntity> findByClassNameAndUsuarioIsDefault(@Param("className") String className);

    @Query("SELECT c FROM ColumnConfigEntity c WHERE c.className = 'default' AND (c.usuario IS NULL OR c.usuario = 'default')")
    List<ColumnConfigEntity> findByClassNameDefault();
}