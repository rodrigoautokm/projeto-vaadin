package com.exemplo;

import com.vaadin.flow.component.grid.Grid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

@Component
public class ColumnConfigFactory {

    @Autowired
    private ColumnConfigRepository columnConfigRepository;

    public List<GridColumnConfig> loadColumnConfigs() {
        List<GridColumnConfig> columnConfigs = new ArrayList<>();
        try {
            List<ColumnConfigEntity> entities = columnConfigRepository.findAll();
            for (ColumnConfigEntity entity : entities) {
                GridColumnConfig columnConfig = mapEntityToConfig(entity);
                if (columnConfig != null) {
                    columnConfigs.add(columnConfig);
                }
            }
        } catch (Exception e) {
            System.out.println("❌ Erro ao carregar configurações de colunas do banco de dados: " + e.getMessage());
            e.printStackTrace();
        }
        return columnConfigs;
    }

    public List<GridColumnConfig> getColumnConfigs(String viewName, Grid<?> grid, Map<String, Function<String, Object>> propertyMappers, List<String> camposFixos) {
        return getColumnConfigs(viewName, null, grid, propertyMappers, camposFixos);
    }

    public List<GridColumnConfig> getColumnConfigs(String viewName, String usuario, Grid<?> grid, Map<String, Function<String, Object>> propertyMappers, List<String> camposFixos) {
        List<GridColumnConfig> columnConfigs = new ArrayList<>();
        try {
            List<ColumnConfigEntity> specificEntities = usuario != null ?
                    columnConfigRepository.findByClassNameAndUsuario(viewName, usuario) :
                    new ArrayList<>();

            List<ColumnConfigEntity> specificNoUserEntities = columnConfigRepository.findByClassNameAndUsuarioIsDefault(viewName);

            List<ColumnConfigEntity> defaultEntities = usuario != null ?
                    columnConfigRepository.findByClassNameAndUsuario("default", usuario) :
                    new ArrayList<>();

            List<ColumnConfigEntity> defaultNoUserEntities = columnConfigRepository.findByClassNameDefault();

            for (ColumnConfigEntity entity : specificEntities) {
                GridColumnConfig columnConfig = mapEntityToConfig(entity);
                if (columnConfig != null) {
                    columnConfigs.add(columnConfig);
                }
            }

            for (ColumnConfigEntity entity : specificNoUserEntities) {
                if (columnConfigs.stream().noneMatch(config -> config.getField().equals(entity.getFieldName()))) {
                    GridColumnConfig columnConfig = mapEntityToConfig(entity);
                    if (columnConfig != null) {
                        columnConfigs.add(columnConfig);
                    }
                }
            }

            for (String campo : camposFixos) {
                boolean hasConfig = columnConfigs.stream()
                        .anyMatch(config -> config.getField().equals(campo));

                if (!hasConfig) {
                    ColumnConfigEntity defaultEntity = null;
                    if (usuario != null) {
                        defaultEntity = defaultEntities.stream()
                                .filter(entity -> entity.getFieldName().equals(campo))
                                .findFirst()
                                .orElse(null);
                    }

                    if (defaultEntity == null) {
                        defaultEntity = defaultNoUserEntities.stream()
                                .filter(entity -> entity.getFieldName().equals(campo))
                                .findFirst()
                                .orElse(null);
                    }

                    if (defaultEntity != null) {
                        GridColumnConfig columnConfig = mapEntityToConfig(defaultEntity);
                        if (columnConfig != null) {
                            columnConfigs.add(columnConfig);
                        }
                    }
                }
            }
        } catch (Exception e) {
            System.out.println("❌ Erro ao carregar configurações de colunas para view " + viewName + " e usuario " + usuario + ": " + e.getMessage());
            e.printStackTrace();
        }
        return columnConfigs;
    }

    private GridColumnConfig mapEntityToConfig(ColumnConfigEntity entity) {
        String field = entity.getFieldName();
        String header = entity.getHeader();
        Boolean visible = entity.getVisible();
        String width = entity.getWidth();
        String style = entity.getStyle();
        String type = entity.getType();
        String filterType = entity.getFilterType();
        String dropdownValues = entity.getDropdownValues();
        Integer numericWidth = entity.getNumericWidth();

        if (field == null || field.isEmpty()) {
            System.out.println("⚠️ Campo field_name vazio ou nulo na configuração. Ignorando essa coluna.");
            return null;
        }

        GridColumnConfig columnConfig = new GridColumnConfig();
        columnConfig.setGridId(entity.getClassName());
        columnConfig.setField(field);
        columnConfig.setHeader(header != null ? header : field);
        columnConfig.setVisible(visible != null && visible);
        columnConfig.setNumericWidth(numericWidth);
        columnConfig.setWidth(width != null ? width : "100px");
        columnConfig.setClassName(entity.getClassName());
        columnConfig.setType(type != null ? type : "STRING");
        columnConfig.setStyle(style != null ? style : "");
        columnConfig.setFilterType(filterType != null ? filterType : "EQUALS");
        columnConfig.setDropdownValues(dropdownValues);
        columnConfig.setAlias(entity.getAlias());

        return columnConfig;
    }
}