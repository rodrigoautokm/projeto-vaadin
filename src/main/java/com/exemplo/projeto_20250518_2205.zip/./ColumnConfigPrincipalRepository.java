
package com.exemplo;

import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@Primary
public interface ColumnConfigPrincipalRepository extends JpaRepository<ColumnConfigEntity, Integer> {
    List<ColumnConfigEntity> findByClassName(String className);

    ColumnConfigEntity findByClassNameAndFieldName(String className, String fieldName);

    @Query("SELECT c FROM ColumnConfigEntity c WHERE c.className = 'default'")
    List<ColumnConfigEntity> findByClassNameDefault();

    List<ColumnConfigEntity> findByClassNameAndUsuario(String className, String usuario);

    @Query("SELECT c FROM ColumnConfigEntity c WHERE c.className = :className AND c.usuario = 'default'")
    List<ColumnConfigEntity> findByClassNameAndUsuarioIsDefault(String className);

    ColumnConfigEntity findByClassNameAndFieldNameAndUsuario(String className, String fieldName, String usuario);

    @Query("SELECT c FROM ColumnConfigEntity c WHERE c.className = :className AND c.fieldName = :fieldName AND c.usuario = 'default'")
    ColumnConfigEntity findByClassNameAndFieldNameAndUsuarioIsDefault(String className, String fieldName);
}
