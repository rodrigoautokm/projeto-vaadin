package com.exemplo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class VisibilidadeColunaService {

    private static final Logger logger = LoggerFactory.getLogger(VisibilidadeColunaService.class);

    @PersistenceContext
    private EntityManager em;

    public Map<String, Boolean> carregarPreferencias(String usuario, String viewId, DataSource dataSource) {
        logger.debug("Carregando preferências para usuário: {}, viewId: {}", usuario, viewId);
        Map<String, Boolean> preferencias = new HashMap<>();

        try {
            List<VisibilidadeColuna> configs = em.createQuery(
                "SELECT v FROM VisibilidadeColuna v WHERE v.usuario = :usuario AND v.viewId = :viewId",
                VisibilidadeColuna.class)
                .setParameter("usuario", usuario)
                .setParameter("viewId", viewId)
                .getResultList();

            for (VisibilidadeColuna config : configs) {
                preferencias.put(config.getColuna(), "S".equalsIgnoreCase(config.getVisivel()));
            }
            logger.debug("Preferências carregadas: {}", preferencias);
        } catch (Exception e) {
            logger.error("Erro ao carregar preferências para usuário: {}, viewId: {}", usuario, viewId, e);
        }

        return preferencias;
    }

    @Transactional
    public void salvar(String usuario, String viewId, Map<String, Boolean> preferencias, DataSource dataSource) {
        logger.debug("Salvando preferências para usuário: {}, viewId: {}", usuario, viewId);

        try {
            em.createQuery("DELETE FROM VisibilidadeColuna v WHERE v.usuario = :usuario AND v.viewId = :viewId")
                .setParameter("usuario", usuario)
                .setParameter("viewId", viewId)
                .executeUpdate();

            for (Map.Entry<String, Boolean> entry : preferencias.entrySet()) {
                VisibilidadeColuna config = new VisibilidadeColuna();
                config.setUsuario(usuario);
                config.setViewId(viewId);
                config.setColuna(entry.getKey());
                config.setVisivel(entry.getValue() ? "S" : "N");
                em.persist(config);
            }

            logger.info("Preferências salvas para usuário: {}, viewId: {}", usuario, viewId);
        } catch (Exception e) {
            logger.error("Erro ao salvar preferências para usuário: {}, viewId: {}", usuario, viewId, e);
            throw new RuntimeException("Erro ao salvar visibilidade de colunas", e);
        }
    }

    public List<VisibilidadeColuna> findByUsuarioAndViewId(String usuario, String viewId) {
        logger.debug("Buscando preferências para usuário: {}, viewId: {}", usuario, viewId);
        try {
            return em.createQuery(
                "SELECT v FROM VisibilidadeColuna v WHERE v.usuario = :usuario AND v.viewId = :viewId",
                VisibilidadeColuna.class)
                .setParameter("usuario", usuario)
                .setParameter("viewId", viewId)
                .getResultList();
        } catch (Exception e) {
            logger.error("Erro ao buscar preferências para usuário: {}, viewId: {}", usuario, viewId, e);
            throw new RuntimeException("Erro ao buscar visibilidade de colunas", e);
        }
    }

    @Transactional
    public void deleteByUsuarioAndViewId(String usuario, String viewId) {
        logger.debug("Deletando preferências para usuário: {}, viewId: {}", usuario, viewId);
        try {
            em.createQuery("DELETE FROM VisibilidadeColuna v WHERE v.usuario = :usuario AND v.viewId = :viewId")
                .setParameter("usuario", usuario)
                .setParameter("viewId", viewId)
                .executeUpdate();
        } catch (Exception e) {
            logger.error("Erro ao deletar preferências para usuário: {}, viewId: {}", usuario, viewId, e);
            throw new RuntimeException("Erro ao deletar visibilidade de colunas", e);
        }
    }

    @Transactional
    public void saveAll(List<VisibilidadeColuna> preferences) {
        logger.debug("Salvando todas as preferências: {}", preferences.size());
        try {
            for (VisibilidadeColuna config : preferences) {
                em.persist(config);
            }
            logger.info("Todas as preferências salvas com sucesso");
        } catch (Exception e) {
            logger.error("Erro ao salvar todas as preferências", e);
            throw new RuntimeException("Erro ao salvar visibilidade de colunas", e);
        }
    }
}