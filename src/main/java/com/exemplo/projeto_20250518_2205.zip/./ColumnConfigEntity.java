package com.exemplo;

import javax.persistence.*;

@Entity
@Table(name = "vw_column_config")
public class ColumnConfigEntity {

    @Id
    @Column(name = "id")
    private Integer id;

    @Column(name = "class_name")
    private String className;

    @Column(name = "usuario")
    private String usuario;

    @Column(name = "field_name")
    private String fieldName;

    @Column(name = "header")
    private String header;

    @Column(name = "type")
    private String type;

    @Column(name = "visible")
    private Boolean visible;

    @Column(name = "numeric_width")
    private Integer numericWidth;

    @Column(name = "width")
    private String width;

    @Column(name = "style")
    private String style;

    @Column(name = "filter_type")
    private String filterType;

    @Column(name = "dropdown_values")
    private String dropdownValues;

    @Column(name = "alias")
    private String alias;

    // Getters e Setters
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getFieldName() {
        return fieldName;
    }

    public void setFieldName(String fieldName) {
        this.fieldName = fieldName;
    }

    public String getHeader() {
        return header;
    }

    public void setHeader(String header) {
        this.header = header;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Boolean getVisible() {
        return visible;
    }

    public void setVisible(Boolean visible) {
        this.visible = visible;
    }

    public Integer getNumericWidth() {
        return numericWidth;
    }

    public void setNumericWidth(Integer numericWidth) {
        this.numericWidth = numericWidth;
    }

    public String getWidth() {
        return width;
    }

    public void setWidth(String width) {
        this.width = width;
    }

    public String getStyle() {
        return style;
    }

    public void setStyle(String style) {
        this.style = style;
    }

    public String getFilterType() {
        return filterType;
    }

    public void setFilterType(String filterType) {
        this.filterType = filterType;
    }

    public String getDropdownValues() {
        return dropdownValues;
    }

    public void setDropdownValues(String dropdownValues) {
        this.dropdownValues = dropdownValues;
    }

    public String getAlias() {
        return alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }
}