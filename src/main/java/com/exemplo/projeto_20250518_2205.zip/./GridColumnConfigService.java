package com.exemplo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import javax.sql.DataSource;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class GridColumnConfigService {

    private static final Logger logger = LoggerFactory.getLogger(GridColumnConfigService.class);

    private final EmpresaConnectionManager empresaConnectionManager;

    @Autowired
    public GridColumnConfigService(EmpresaConnectionManager empresaConnectionManager) {
        this.empresaConnectionManager = empresaConnectionManager;
    }

    private JdbcTemplate getJdbcTemplate() {
        Object principal = SecurityContextHolder.getContext().getAuthentication() != null ?
                SecurityContextHolder.getContext().getAuthentication().getPrincipal() : null;
        Integer cdEmpresa = null;

        if (principal instanceof CustomUserDetails) {
            cdEmpresa = ((CustomUserDetails) principal).getCdEmpresa();
            if (cdEmpresa == null) {
                logger.error("❌ Erro: cdEmpresa é nulo para o usuário autenticado.");
                throw new IllegalStateException("Código da empresa não encontrado para o usuário autenticado.");
            }
        } else {
            logger.warn("⚠️ Principal não é CustomUserDetails, é: {}. Usando cdEmpresa padrão (0).", 
                principal != null ? principal.getClass().getName() : "null");
            cdEmpresa = 0;
        }

        DataSource ds = empresaConnectionManager.getDataSourceForEmpresa(cdEmpresa);
        if (ds == null) {
            logger.error("❌ Erro: DataSource não encontrado para cdEmpresa={}", cdEmpresa);
            throw new IllegalStateException("DataSource não encontrado para a empresa: " + cdEmpresa);
        }
        return new JdbcTemplate(ds);
    }

    public List<GridColumnConfig> listar(String className) {
        logger.info("🔍 Buscando configurações de colunas para className: {}", className);

        String sql = "SELECT id, class_name, field_name AS field, header, type AS column_type, visible, numeric_width, width, style, filter_type, dropdown_values, alias " +
                     "FROM vw_column_config WHERE class_name = ?";

        JdbcTemplate jdbcTemplate = getJdbcTemplate();

        List<Map<String, Object>> rows;
        try {
            rows = jdbcTemplate.queryForList(sql, className);
            logger.debug("Configurações retornadas para className {}: {}", className, 
                rows.stream().map(row -> String.format("id=%s, field=%s, header=%s", 
                    row.get("id"), row.get("field"), row.get("header"))).collect(Collectors.toList()));
        } catch (Exception e) {
            logger.error("❌ Erro ao consultar vw_column_config para className '{}': {}", className, e.getMessage(), e);
            return Collections.emptyList();
        }

        List<GridColumnConfig> configs = new ArrayList<>();
        for (Map<String, Object> row : rows) {
            GridColumnConfig config = new GridColumnConfig();

            String field = getString(row, "field");
            if (field == null || field.isBlank()) {
                logger.warn("⚠️ Ignorando configuração com field nulo ou vazio para className={}.", className);
                continue;
            }

            config.setGridId(getString(row, "class_name"));
            config.setField(field);
            config.setHeader(getString(row, "header"));
            config.setVisible(getBoolean(row.get("visible")));
            config.setNumericWidth(getInteger(row, "numeric_width"));
            config.setWidth(getString(row, "width"));
            config.setClassName(getString(row, "class_name"));
            config.setType(getString(row, "column_type"));
            config.setStyle(getString(row, "style"));
            config.setFilterType(getString(row, "filter_type"));
            config.setDropdownValues(getString(row, "dropdown_values"));
            config.setAlias(getString(row, "alias"));

            logger.debug("🧩 Configuração carregada: className={}, field={}, header={}, visible={}, width={}", 
                config.getGridId(), config.getField(), config.getHeader(), config.isVisible(), 
                config.getWidth());

            configs.add(config);
        }

        logger.info("✅ Total de configurações carregadas para className {}: {}", className, configs.size());
        return configs;
    }

    public List<GridColumnConfig> listar() {
        logger.info("🔍 Buscando todas as configurações de colunas de vw_column_config");

        String sql = "SELECT id, class_name, field_name AS field, header, type AS column_type, visible, numeric_width, width, style, filter_type, dropdown_values, alias " +
                     "FROM vw_column_config";

        JdbcTemplate jdbcTemplate = getJdbcTemplate();

        List<Map<String, Object>> rows;
        try {
            rows = jdbcTemplate.queryForList(sql);
            logger.debug("Configurações retornadas: {}", 
                rows.stream().map(row -> String.format("id=%s, class_name=%s, field=%s, header=%s", 
                    row.get("id"), row.get("class_name"), row.get("field"), row.get("header")))
                    .collect(Collectors.toList()));
        } catch (Exception e) {
            logger.error("❌ Erro ao consultar vw_column_config: {}", e.getMessage(), e);
            return Collections.emptyList();
        }

        List<GridColumnConfig> configs = new ArrayList<>();
        for (Map<String, Object> row : rows) {
            GridColumnConfig config = new GridColumnConfig();

            String field = getString(row, "field");
            if (field == null || field.isBlank()) {
                logger.warn("⚠️ Ignorando configuração com field nulo ou vazio.");
                continue;
            }

            config.setGridId(getString(row, "class_name"));
            config.setField(field);
            config.setHeader(getString(row, "header"));
            config.setVisible(getBoolean(row.get("visible")));
            config.setNumericWidth(getInteger(row, "numeric_width"));
            config.setWidth(getString(row, "width"));
            config.setClassName(getString(row, "class_name"));
            config.setType(getString(row, "column_type"));
            config.setStyle(getString(row, "style"));
            config.setFilterType(getString(row, "filter_type"));
            config.setDropdownValues(getString(row, "dropdown_values"));
            config.setAlias(getString(row, "alias"));

            logger.debug("🧩 Configuração carregada: className={}, field={}, header={}, visible={}, width={}", 
                config.getGridId(), config.getField(), config.getHeader(), config.isVisible(), 
                config.getWidth());

            configs.add(config);
        }

        logger.info("✅ Total de configurações carregadas: {}", configs.size());
        return configs;
    }

    public GridColumnConfig getColumnConfig(String className, String usuarioId, String field) {
        logger.debug("🔍 Buscando configuração de coluna para className={}, usuarioId={}, field={}", 
            className, usuarioId, field);

        String sql = "SELECT id, class_name, field_name AS field, header, type AS column_type, visible, numeric_width, width, style, filter_type, dropdown_values, alias " +
                     "FROM vw_column_config WHERE class_name = ? AND field_name = ?";

        JdbcTemplate jdbcTemplate = getJdbcTemplate();

        List<Map<String, Object>> rows;
        try {
            rows = jdbcTemplate.queryForList(sql, className, field);
        } catch (Exception e) {
            logger.error("❌ Erro ao consultar configuração de coluna para className={}, field={}: {}", 
                className, field, e.getMessage(), e);
            return null;
        }

        if (rows.isEmpty()) {
            logger.debug("⚠️ Nenhuma configuração encontrada para className={}, field={}", className, field);
            return null;
        }

        Map<String, Object> row = rows.get(0);
        GridColumnConfig config = new GridColumnConfig();

        config.setGridId(getString(row, "class_name"));
        config.setField(getString(row, "field"));
        config.setHeader(getString(row, "header"));
        config.setVisible(getBoolean(row.get("visible")));
        config.setNumericWidth(getInteger(row, "numeric_width"));
        config.setWidth(getString(row, "width"));
        config.setClassName(getString(row, "class_name"));
        config.setType(getString(row, "column_type"));
        config.setStyle(getString(row, "style"));
        config.setFilterType(getString(row, "filter_type"));
        config.setDropdownValues(getString(row, "dropdown_values"));
        config.setAlias(getString(row, "alias"));

        logger.debug("✅ Configuração encontrada: className={}, field={}, header={}, visible={}, width={}", 
            config.getGridId(), config.getField(), config.getHeader(), config.isVisible(), config.getWidth());

        return config;
    }

    private String getString(Map<String, Object> row, String key) {
        Object value = row.get(key);
        return value != null ? value.toString().trim() : null;
    }

    private Integer getInteger(Map<String, Object> row, String key) {
        Object value = row.get(key);
        if (value instanceof Number) {
            return ((Number) value).intValue();
        }
        try {
            return value != null ? Integer.parseInt(value.toString()) : null;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private boolean getBoolean(Object obj) {
        if (obj instanceof Boolean) return (Boolean) obj;
        if (obj instanceof Number) return ((Number) obj).intValue() == 1;
        if (obj instanceof String) return "S".equalsIgnoreCase((String) obj) || "true".equalsIgnoreCase((String) obj);
        return false;
    }
}