package com.exemplo;

import org.hibernate.dialect.SQLServerDialect;
import org.hibernate.type.descriptor.sql.LongNVarcharTypeDescriptor;
import org.hibernate.type.descriptor.sql.NVarcharTypeDescriptor;
import org.hibernate.type.descriptor.sql.SqlTypeDescriptor;
import java.sql.Types;

public class SQLAnywhere10Dialect extends SQLServerDialect {
    public SQLAnywhere10Dialect() {
        super();
        registerHibernateType(Types.NVARCHAR, "nvarchar($l)");
        registerHibernateType(Types.LONGNVARCHAR, "nvarchar(max)");
    }

    @Override
    protected SqlTypeDescriptor getSqlTypeDescriptorOverride(int sqlCode) {
        switch (sqlCode) {
            case Types.NVARCHAR:
                return NVarcharTypeDescriptor.INSTANCE;
            case Types.LONGNVARCHAR:
                return LongNVarcharTypeDescriptor.INSTANCE;
            default:
                return super.getSqlTypeDescriptorOverride(sqlCode);
        }
    }
}