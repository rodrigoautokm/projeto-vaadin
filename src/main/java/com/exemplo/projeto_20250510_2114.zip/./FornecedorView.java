package com.exemplo;

import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.router.Route;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.List;

@Route(value = "fornecedores", layout = MainLayout.class)
public class FornecedorView extends AbstractGridView<Fornecedor> {

    private static final Logger logger = LoggerFactory.getLogger(FornecedorView.class);

    private final GridColumnConfigService columnConfigService;

    @Autowired
    public FornecedorView(FornecedorService fornecedorService, GridColumnConfigService columnConfigService) {
        super("Fornecedores", "fornecedores", fornecedorService::listar);
        this.columnConfigService = columnConfigService;
    }

    @Override
    protected Class<Fornecedor> getEntityClass() {
        return Fornecedor.class;
    }

    @Override
    protected List<GridFilterUtil.ColumnConfig<Fornecedor>> configureColumns() {
        logger.info("Configurando colunas da grid para FornecedorView");

        String[] fields = {
            "cd_fornecedor", "nm_fornecedor", "nm_fantasia", "nm_representante",
            "fone", "email", "tipo", "situacao"
        };

        List<GridFilterUtil.ColumnConfig<Fornecedor>> columnConfigs = new ArrayList<>();
        for (String field : fields) {
            GridColumnConfig config = columnConfigService.getColumnConfig(field);
            if (config == null) {
                logger.warn("Configuração não encontrada para o campo: {}. Usando configuração padrão.", field);
                config = new GridColumnConfig();
                config.setField(field);
                config.setHeader(field);
                config.setWidth("100px");
                config.setVisible(true);
                config.setType("STRING");
            }

            if (config.isVisible()) {
                Grid.Column<Fornecedor> column = grid.addColumn(fornecedor -> {
                    try {
                        switch (field) {
                            case "cd_fornecedor": return fornecedor.getCdFornecedor();
                            case "nm_fornecedor": return fornecedor.getNmFornecedor();
                            case "nm_fantasia": return fornecedor.getNmFantasia();
                            case "nm_representante": return fornecedor.getNmRepresentante();
                            case "fone": return fornecedor.getFone();
                            case "email": return fornecedor.getEmail();
                            case "tipo": return fornecedor.getTipo();
                            case "situacao": return fornecedor.getSituacao();
                            default:
                                logger.warn("Campo não reconhecido: {}", field);
                                return null;
                        }
                    } catch (Exception e) {
                        logger.error("Erro ao acessar campo {} para fornecedor: {}", field, fornecedor, e);
                        return null;
                    }
                }).setKey(field);

                column.setHeader(config.getHeader());
                column.setWidth(config.getWidth());
                column.setSortable(true);
                column.setVisible(true);

                if (config.getStyle() != null && !config.getStyle().isEmpty()) {
                    String[] styleRules = config.getStyle().split(";");
                    for (String rule : styleRules) {
                        if (rule.trim().isEmpty()) continue;
                        String[] parts = rule.split(":");
                        if (parts.length == 2) {
                            String property = parts[0].trim();
                            String value = parts[1].trim();
                            column.getElement().getStyle().set(property, value);
                        }
                    }
                }

                GridFilterUtil.ColumnConfig<Fornecedor> columnConfig = new GridFilterUtil.ColumnConfig<>(
                    column,
                    config.getHeader(),
                    fornecedor -> {
                        switch (field) {
                            case "cd_fornecedor":
                                return String.valueOf(fornecedor.getCdFornecedor());
                            case "nm_fornecedor":
                                return fornecedor.getNmFornecedor();
                            case "nm_fantasia":
                                return fornecedor.getNmFantasia();
                            case "nm_representante":
                                return fornecedor.getNmRepresentante();
                            case "fone":
                                return fornecedor.getFone();
                            case "email":
                                return fornecedor.getEmail();
                            case "tipo":
                                return fornecedor.getTipo();
                            case "situacao":
                                return fornecedor.getSituacao();
                            default:
                                return null;
                        }
                    },
                    config
                );

                columnConfigs.add(columnConfig);
            }
        }

        return columnConfigs;
    }
}