package com.exemplo;

import java.io.Serializable;
import java.util.Objects;

public class VisibilidadeColunaId implements Serializable {
    private String usuario;
    private String viewId;
    private String coluna;

    public VisibilidadeColunaId() {}

    public VisibilidadeColunaId(String usuario, String viewId, String coluna) {
        this.usuario = usuario;
        this.viewId = viewId;
        this.coluna = coluna;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof VisibilidadeColunaId)) return false;
        VisibilidadeColunaId that = (VisibilidadeColunaId) o;
        return Objects.equals(usuario, that.usuario) &&
               Objects.equals(viewId, that.viewId) &&
               Objects.equals(coluna, that.coluna);
    }

    @Override
    public int hashCode() {
        return Objects.hash(usuario, viewId, coluna);
    }
}