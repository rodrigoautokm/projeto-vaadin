
package com.exemplo;

import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@Route(value = "clientes", layout = MainLayout.class)
public class ClienteView extends AbstractGridView<Cliente> {

    private static final Logger logger = LoggerFactory.getLogger(ClienteView.class);

    private final GridColumnConfigService columnConfigService;
    private final ClienteService clienteService;
    private final ClienteCadastro clienteCadastro;

    @Autowired
    public ClienteView(ClienteService clienteService, GridColumnConfigService columnConfigService, ClienteCadastro clienteCadastro) {
        super("Clientes", "clientes", clienteService::listar);
        this.columnConfigService = columnConfigService;
        this.clienteService = clienteService;
        this.clienteCadastro = clienteCadastro;
        logger.info("Inicializando ClienteView");

        grid.setSelectionMode(Grid.SelectionMode.SINGLE);

        Button newClientButton = new Button("Novo Cliente", new Icon(VaadinIcon.PLUS));
        newClientButton.addClickListener(event -> {
            Cliente novoCliente = new Cliente();
            novoCliente.setId(new ClienteId(getCdEmpresaUsuario(), null));
            openCadastroDialog(novoCliente);
        });

        Button editClientButton = new Button("Editar Cliente", new Icon(VaadinIcon.EDIT));
        editClientButton.addClickListener(event -> {
            Set<Cliente> selectedItems = grid.getSelectedItems();
            if (selectedItems.isEmpty()) {
                Notification.show("Por favor, selecione um cliente para editar.", 3000, Notification.Position.TOP_CENTER);
                return;
            }
            Cliente cliente = selectedItems.iterator().next();
            openCadastroDialog(cliente);
        });

        HorizontalLayout buttonLayout = new HorizontalLayout(newClientButton, editClientButton);
        buttonLayout.setWidthFull();
        add(buttonLayout);

        grid.addItemDoubleClickListener(event -> {
            Cliente cliente = event.getItem();
            if (cliente != null) {
                openCadastroDialog(cliente);
            }
        });
    }

    @Override
    protected Class<Cliente> getEntityClass() {
        return Cliente.class;
    }

    @Override
    protected List<GridFilterUtil.ColumnConfig<Cliente>> configureColumns() {
        logger.info("Configurando colunas da grid para ClienteView");

        String[] fields = {
            "cd_empresa", "cd_cliente", "nm_cliente", "tipo", "endereco", "bairro", "fone", "celular", "cpf"
        };

        List<GridFilterUtil.ColumnConfig<Cliente>> columnConfigs = new ArrayList<>();
        for (String field : fields) {
            GridColumnConfig config = columnConfigService.getColumnConfig(field);
            if (config == null) {
                logger.warn("Configuração não encontrada para o campo: {}. Usando configuração padrão.", field);
                config = new GridColumnConfig();
                config.setField(field);
                config.setHeader(field);
                config.setWidth("100px");
                config.setVisible(true);
                config.setType("STRING");
            }

            if (config.isVisible()) {
                Grid.Column<Cliente> column = grid.addColumn(cliente -> {
                    try {
                        switch (field) {
                            case "cd_empresa":
                                return cliente.getId().getCdEmpresa();
                            case "cd_cliente":
                                return cliente.getId().getCdCliente();
                            case "nm_cliente":
                                return cliente.getNmCliente();
                            case "tipo":
                                return cliente.getTipo();
                            case "endereco":
                                return cliente.getEndereco();
                            case "bairro":
                                return cliente.getBairro();
                            case "fone":
                                return cliente.getFone();
                            case "celular":
                                return cliente.getCelular();
                            case "cpf":
                                return cliente.getCpf();
                            default:
                                return null;
                        }
                    } catch (Exception e) {
                        logger.error("Erro ao acessar o campo {} para o cliente: {}", field, cliente, e);
                        return null;
                    }
                }).setKey(field);

                column.setHeader(config.getHeader());
                column.setWidth(config.getWidth());
                column.setSortable(true);
                column.setVisible(true);

                GridFilterUtil.ColumnConfig<Cliente> columnConfig = new GridFilterUtil.ColumnConfig<>(
                    column,
                    config.getHeader(),
                    cliente -> {
                        switch (field) {
                            case "cd_empresa":
                                return String.valueOf(cliente.getId().getCdEmpresa());
                            case "cd_cliente":
                                return String.valueOf(cliente.getId().getCdCliente());
                            case "nm_cliente":
                                return cliente.getNmCliente();
                            case "tipo":
                                return cliente.getTipo();
                            case "endereco":
                                return cliente.getEndereco();
                            case "bairro":
                                return cliente.getBairro();
                            case "fone":
                                return cliente.getFone();
                            case "celular":
                                return cliente.getCelular();
                            case "cpf":
                                return cliente.getCpf();
                            default:
                                return null;
                        }
                    },
                    config
                );

                columnConfigs.add(columnConfig);
            }
        }

        logger.info("Total de colunas configuradas: {}", grid.getColumns().size());
        return columnConfigs;
    }

    private void openCadastroDialog(Cliente cliente) {
        clienteCadastro.initialize(cliente, updatedCliente -> grid.getDataProvider().refreshAll());
        clienteCadastro.open();
    }

    private Integer getCdEmpresaUsuario() {
        return 1;
    }
}
