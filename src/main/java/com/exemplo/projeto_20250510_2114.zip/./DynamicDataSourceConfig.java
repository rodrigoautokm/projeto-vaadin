package com.exemplo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

import javax.sql.DataSource;
import java.util.HashMap;
import java.util.Map;

@Configuration
@EnableJpaRepositories(
    basePackages = "com.exemplo",
    excludeFilters = {
        @org.springframework.context.annotation.ComponentScan.Filter(
            type = org.springframework.context.annotation.FilterType.ASSIGNABLE_TYPE,
            classes = {EmpresaRepository.class, UsuarioAcessoRepository.class}
        )
    },
    entityManagerFactoryRef = "entityManagerFactory",
    transactionManagerRef = "transactionManager"
)
public class DynamicDataSourceConfig {

    @Autowired
    private ConfigurableApplicationContext context;

    @Autowired
    private EmpresaConnectionManager empresaConnectionManager;

    @Autowired
    private EmpresaAwareService empresaAwareService;

    @Bean(name = "primaryDataSource")
    public DataSource primaryDataSource() {
        HikariConfig config = new HikariConfig();
        config.setJdbcUrl("jdbc:sqlanywhere:ServerName=autokm;DatabaseName=autokm;Host=10.0.14.130:2688");
        config.setDriverClassName("sap.jdbc4.sqlanywhere.IDriver");
        config.setUsername("dbo");
        config.setPassword("dircri17");
        config.addDataSourceProperty("charset", "iso_1");

        // Configurações do HikariCP
        config.setConnectionTestQuery("SELECT 1");
        config.setMinimumIdle(1);
        config.setMaximumPoolSize(5);
        config.setConnectionTimeout(30000);
        config.setIdleTimeout(600000);
        config.setMaxLifetime(1800000);
        config.setLeakDetectionThreshold(2000);

        return new HikariDataSource(config);
    }

    @Bean
    @Primary
    public DataSource dataSource() {
        AbstractRoutingDataSource routingDataSource = new AbstractRoutingDataSource() {
            @Override
            protected Object determineCurrentLookupKey() {
                try {
                    Short cdEmpresaShort = empresaAwareService.getCdEmpresa();
                    Integer cdEmpresa = cdEmpresaShort != null ? cdEmpresaShort.intValue() : 1;
                    System.out.println("Determinando cdEmpresa para DataSource: " + cdEmpresa);
                    return cdEmpresa;
                } catch (Exception e) {
                    System.out.println("Erro ao determinar cdEmpresa: " + e.getMessage());
                    return 1; // Fallback para empresa padrão
                }
            }
        };

        Map<Object, Object> targetDataSources = new HashMap<>();
        Integer defaultCdEmpresa = 1;
        try {
            Empresa empresaPadrao = new Empresa();
            empresaPadrao.setCd_empresa(defaultCdEmpresa);
            empresaPadrao.setServer_name("autokm");
            empresaPadrao.setNomeBanco("autokm");
            empresaPadrao.setIp_bd("10.0.14.130");
            empresaPadrao.setPorta_bd("2688");
            empresaPadrao.setUsuario_bd("dbo");
            empresaPadrao.setSenha_bd("dircri17");

            EmpresaConnectionManager.configure(empresaPadrao);

            DataSource defaultDataSource = empresaConnectionManager.getDataSourceForEmpresa(defaultCdEmpresa);
            if (defaultDataSource == null) {
                throw new IllegalStateException("DataSource para a empresa padrão (" + defaultCdEmpresa + ") é nulo!");
            }
            targetDataSources.put(defaultCdEmpresa, defaultDataSource);
            System.out.println("DataSources configurados: " + targetDataSources.keySet());
        } catch (Exception e) {
            System.out.println("Erro ao configurar DataSources: " + e.getMessage());
            throw new RuntimeException("Falha ao configurar DataSources", e);
        }

        routingDataSource.setTargetDataSources(targetDataSources);
        routingDataSource.setDefaultTargetDataSource(targetDataSources.get(defaultCdEmpresa));
        routingDataSource.afterPropertiesSet();

        return routingDataSource;
    }

    @Bean(name = "entityManagerFactory")
    @Primary
    public LocalContainerEntityManagerFactoryBean entityManagerFactory() {
        LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
        em.setDataSource(dataSource());
        em.setPackagesToScan("com.exemplo");
        em.setJpaVendorAdapter(new HibernateJpaVendorAdapter());

        Map<String, Object> properties = new HashMap<>();
        properties.put("hibernate.dialect", "org.hibernate.dialect.SybaseDialect");
        properties.put("hibernate.hbm2ddl.auto", "none");
        properties.put("hibernate.show_sql", true);
        properties.put("hibernate.format_sql", true);
        properties.put("hibernate.connection.charSet", "ISO-8859-1");
        properties.put("hibernate.connection.characterEncoding", "ISO-8859-1");
        properties.put("hibernate.connection.useUnicode", "false");
        properties.put("hibernate.connection.catalog", "autokm");
        properties.put("hibernate.jdbc.batch_versioned_data", "false");
        properties.put("hibernate.physical_naming_strategy", "org.hibernate.boot.model.naming.PhysicalNamingStrategyStandardImpl");
        properties.put("hibernate.implicit_naming_strategy", "org.hibernate.boot.model.naming.ImplicitNamingStrategyComponentPathImpl");
        em.setJpaPropertyMap(properties);

        System.out.println("Configurando entityManagerFactory...");
        return em;
    }

    @Bean(name = "transactionManager")
    @Primary
    public PlatformTransactionManager transactionManager() {
        JpaTransactionManager transactionManager = new JpaTransactionManager();
        transactionManager.setEntityManagerFactory(entityManagerFactory().getObject());
        System.out.println("Configurando transactionManager...");
        return transactionManager;
    }

    @Bean
    public DynamicDataSourceSwitcher dynamicDataSourceSwitcher() {
        return new DynamicDataSourceSwitcher(context);
    }
}