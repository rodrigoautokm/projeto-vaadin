package com.exemplo;

import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@Route(value = "produtos", layout = MainLayout.class)
public class ProdutoView extends AbstractGridView<Produto> {

    private static final Logger logger = LoggerFactory.getLogger(ProdutoView.class);

    private final GridColumnConfigService columnConfigService;
    private final ProdutoService produtoService;
    private final ProdutoCadastro produtoCadastro;

    @Autowired
    public ProdutoView(ProdutoService produtoService, GridColumnConfigService columnConfigService, ProdutoCadastro produtoCadastro) {
        super("Produtos", "produtos", produtoService::listar);
        this.columnConfigService = columnConfigService;
        this.produtoService = produtoService;
        this.produtoCadastro = produtoCadastro;
        logger.info("Inicializando ProdutoView");
        logger.info("produtoCadastro injetado: {}", produtoCadastro != null ? "Sim" : "Não");

        // Configurar o grid para permitir seleção de um único produto
        grid.setSelectionMode(Grid.SelectionMode.SINGLE);

        // Adicionar botões "Novo Produto" e "Editar Produto" acima do grid
        Button newProductButton = new Button("Novo Produto", new Icon(VaadinIcon.PLUS));
        newProductButton.addClickListener(event -> {
            logger.info("Botão 'Novo Produto' clicado");
            Produto novoProduto = new Produto();
            novoProduto.setCdProduto(getNextCdProduto());
            openCadastroDialog(novoProduto);
        });

        Button editProductButton = new Button("Editar Produto", new Icon(VaadinIcon.EDIT));
        editProductButton.addClickListener(event -> {
            logger.info("Botão 'Editar Produto' clicado");
            Set<Produto> selectedItems = grid.getSelectedItems();
            if (selectedItems.isEmpty()) {
                logger.warn("Nenhum produto selecionado para edição");
                Notification.show("Por favor, selecione um produto para editar.", 3000, Notification.Position.TOP_CENTER);
                return;
            }
            Produto produto = selectedItems.iterator().next();
            openCadastroDialog(produto);
        });

        HorizontalLayout buttonLayout = new HorizontalLayout(newProductButton, editProductButton);
        buttonLayout.setWidthFull();
        add(buttonLayout);

        // Adicionar listener de duplo clique para abrir o diálogo de edição
        grid.addItemDoubleClickListener(event -> {
            logger.info("Duplo clique detectado no grid");
            Produto produto = event.getItem();
            if (produto != null) {
                logger.info("Produto selecionado para edição: {}", produto.getCdProduto());
                openCadastroDialog(produto);
            } else {
                logger.warn("Nenhum produto selecionado ao dar duplo clique");
                Notification.show("Nenhum produto selecionado.", 3000, Notification.Position.TOP_CENTER);
            }
        });
    }

    @Override
    protected Class<Produto> getEntityClass() {
        return Produto.class;
    }

    @Override
    protected List<GridFilterUtil.ColumnConfig<Produto>> configureColumns() {
        logger.info("Configurando colunas da grid para ProdutoView");

        String[] fields = {
            "cd_produto", "nr_digito", "ds_produto", "ds_abreviacao", "cd_subgrupo", "cd_grupo", "cd_marca",
            "cd_cor", "voltagem", "cd_fornecedor", "situacao", "reducao_icms", "icms", "ipi", "classificacao_fiscal",
            "origem_situacao_tributaria", "situacao_tributaria", "vl_contabil", "vl_compra", "vl_venda", "vl_custo",
            "comissao", "lucro", "estoque_minimo", "estoque_maximo", "cd_unidade", "vl_custo_medio",
            "pr_desconto_vendedor", "pr_desconto_gerente", "saldo_negativo", "cd_barra", "nr_componentes",
            "referencia", "dt_cadastro", "altera_preco", "prateleira", "peso", "cubagem", "cd_fabrica",
            "capacidade", "combustivel", "renavam", "chassi", "motor", "potencia", "ano_fabricacao", "ano_modelo",
            "cilindrada", "cd_perfil", "cd_acabamento", "gravura", "sombra", "ncm", "vl_ipi", "vl_substituicao",
            "cd_montadora", "tamanho", "pr_proteina", "tp_produto", "ds_modelo", "comissao2", "comissao3", "numero",
            "capacidade_volumetrica", "cd_produto_dnf", "kg_milheiro", "nm_usuario", "dias_entrega",
            "classificacao", "qt_pecas_um_volume", "obs_orcamento", "obs_nf", "nr_meses_garantia",
            "pr_desconto_gerente_2", "pr_desconto_vendedor_2", "peso_bruto", "caminho_foto", "vl_dec",
            "montadora", "ipi_venda", "ano_fabricabao", "prioridade", "pis_cofins", "dt_vencimento_nota",
            "cd_receita", "cd_despesa", "cd_tipo", "vl_mao_obra", "modalidade_bc_icms", "modalidade_bc_icms_st",
            "enquadramento_ipi", "situacao_tributaria_ipi", "situacao_tributaria_pis", "pr_aliquota_pis",
            "situacao_tributaria_cofins", "pr_aliquota_cofins", "pr_adicionado_substituicao", "pr_substituicao",
            "cd_tipo_entrada", "ds_aplicacao", "conversao", "pr_icms_compra", "somente_cotacao_compra",
            "cd_grupo_servico_classificacao", "cd_servico_classificacao", "cd_tributacao_iss", "cd_tipo_item_sped",
            "cd_excecao_ncm_sped", "cd_genero_sped", "pr_reducao_icms_st", "pr_fator_reducao_sn_st",
            "indice_ajuste_mva", "movto_sped", "prioridade_ordem", "altera_descricao_compra", "libera_locacao",
            "criptografia", "cd_anp", "largura", "profundidade", "altura", "sazonal", "nr_especificacao_icms",
            "nr_especificacao_pis_cofins", "nr_especificacao_ipi", "situacao_tributaria_compra",
            "pr_icms_ajuste_mva", "pr_reducao_icms_compra", "nr_especificacao_compras", "nm_usuario_alteracao",
            "dt_alteracao", "cest", "pr_desconto_demander", "fci", "cd_fabricante", "pis_cofins_monofasico",
            "vl_bc_icms_st_ret", "pr_st_ret", "vl_icms_ret", "vl_icms_st_ret", "cd_similaridade",
            "verificado_autokm", "ds_fabricante_autokm", "qt_fracionada", "cd_unidade_fracionada", "cd_aliquota",
            "cd_produto_agrupador", "obs_loja_virtual", "icms_st_retido_anteriormente"
        };

        List<GridFilterUtil.ColumnConfig<Produto>> columnConfigs = new ArrayList<>();
        for (String field : fields) {
            GridColumnConfig config = columnConfigService.getColumnConfig(field);
            if (config == null) {
                logger.warn("Configuração não encontrada para o campo: {}. Usando configuração padrão.", field);
                config = new GridColumnConfig();
                config.setField(field);
                config.setHeader(field);
                config.setWidth("100px");
                config.setVisible(true);
                config.setType("STRING");
            }

            logger.debug("Configuração para o campo {}: header={}, visible={}, width={}, type={}, style={}",
                field, config.getHeader(), config.isVisible(), config.getWidth(), config.getType(), config.getStyle());

            if (config.isVisible()) {
                logger.debug("Adicionando coluna: {}", field);
                Grid.Column<Produto> column = grid.addColumn(produto -> {
                    try {
                        switch (field) {
                            case "cd_produto":
                                return produto.getCdProduto();
                            case "nr_digito":
                                return produto.getNrDigito();
                            case "ds_produto":
                                return produto.getDsProduto();
                            case "ds_abreviacao":
                                return produto.getDsAbreviacao();
                            case "cd_subgrupo":
                                return produto.getCdSubgrupo();
                            case "cd_grupo":
                                return produto.getCdGrupo();
                            case "cd_marca":
                                return produto.getCdMarca();
                            case "cd_cor":
                                return produto.getCdCor();
                            case "voltagem":
                                return produto.getVoltagem();
                            case "cd_fornecedor":
                                return produto.getCdFornecedor();
                            case "situacao":
                                return produto.getSituacao();
                            case "reducao_icms":
                                return produto.getReducaoIcms();
                            case "icms":
                                return produto.getIcms();
                            case "ipi":
                                return produto.getIpi();
                            case "classificacao_fiscal":
                                return produto.getClassificacaoFiscal();
                            case "origem_situacao_tributaria":
                                return produto.getOrigemSituacaoTributaria();
                            case "situacao_tributaria":
                                return produto.getSituacaoTributaria();
                            case "vl_contabil":
                                return produto.getVlContabil();
                            case "vl_compra":
                                return produto.getVlCompra();
                            case "vl_venda":
                                return produto.getVlVenda();
                            case "vl_custo":
                                return produto.getVlCusto();
                            case "comissao":
                                return produto.getComissao();
                            case "lucro":
                                return produto.getLucro();
                            case "estoque_minimo":
                                return produto.getEstoqueMinimo();
                            case "estoque_maximo":
                                return produto.getEstoqueMaximo();
                            case "cd_unidade":
                                return produto.getCdUnidade();
                            case "vl_custo_medio":
                                return produto.getVlCustoMedio();
                            case "pr_desconto_vendedor":
                                return produto.getPrDescontoVendedor();
                            case "pr_desconto_gerente":
                                return produto.getPrDescontoGerente();
                            case "saldo_negativo":
                                return produto.getSaldoNegativo();
                            case "cd_barra":
                                return produto.getCdBarra();
                            case "nr_componentes":
                                return produto.getNrComponentes();
                            case "referencia":
                                return produto.getReferencia();
                            case "dt_cadastro":
                                return produto.getDtCadastro();
                            case "altera_preco":
                                return produto.getAlteraPreco();
                            case "prateleira":
                                return produto.getPrateleira();
                            case "peso":
                                return produto.getPeso();
                            case "cubagem":
                                return produto.getCubagem();
                            case "cd_fabrica":
                                return produto.getCdFabrica();
                            case "capacidade":
                                return produto.getCapacidade();
                            case "combustivel":
                                return produto.getCombustivel();
                            case "renavam":
                                return produto.getRenavam();
                            case "chassi":
                                return produto.getChassi();
                            case "motor":
                                return produto.getMotor();
                            case "potencia":
                                return produto.getPotencia();
                            case "ano_fabricacao":
                                return produto.getAnoFabricacao();
                            case "ano_modelo":
                                return produto.getAnoModelo();
                            case "cilindrada":
                                return produto.getCilindrada();
                            case "cd_perfil":
                                return produto.getCdPerfil();
                            case "cd_acabamento":
                                return produto.getCdAcabamento();
                            case "gravura":
                                return produto.getGravura();
                            case "sombra":
                                return produto.getSombra();
                            case "ncm":
                                return produto.getNcm();
                            case "vl_ipi":
                                return produto.getVlIpi();
                            case "vl_substituicao":
                                return produto.getVlSubstituicao();
                            case "cd_montadora":
                                return produto.getCdMontadora();
                            case "tamanho":
                                return produto.getTamanho();
                            case "pr_proteina":
                                return produto.getPrProteina();
                            case "tp_produto":
                                return produto.getTpProduto();
                            case "ds_modelo":
                                return produto.getDsModelo();
                            case "comissao2":
                                return produto.getComissao2();
                            case "comissao3":
                                return produto.getComissao3();
                            case "numero":
                                return produto.getNumero();
                            case "capacidade_volumetrica":
                                return produto.getCapacidadeVolumetrica();
                            case "cd_produto_dnf":
                                return produto.getCdProdutoDnf();
                            case "kg_milheiro":
                                return produto.getKgMilheiro();
                            case "nm_usuario":
                                return produto.getNmUsuario();
                            case "dias_entrega":
                                return produto.getDiasEntrega();
                            case "classificacao":
                                return produto.getClassificacao();
                            case "qt_pecas_um_volume":
                                return produto.getQtPecasUmVolume();
                            case "obs_orcamento":
                                return produto.getObsOrcamento();
                            case "obs_nf":
                                return produto.getObsNf();
                            case "nr_meses_garantia":
                                return produto.getNrMesesGarantia();
                            case "pr_desconto_gerente_2":
                                return produto.getPrDescontoGerente2();
                            case "pr_desconto_vendedor_2":
                                return produto.getPrDescontoVendedor2();
                            case "peso_bruto":
                                return produto.getPesoBruto();
                            case "caminho_foto":
                                return produto.getCaminhoFoto();
                            case "vl_dec":
                                return produto.getVlDec();
                            case "montadora":
                                return produto.getMontadora();
                            case "ipi_venda":
                                return produto.getIpiVenda();
                            case "ano_fabricabao":
                                return produto.getAnoFabricabao();
                            case "prioridade":
                                return produto.getPrioridade();
                            case "pis_cofins":
                                return produto.getPisCofins();
                            case "dt_vencimento_nota":
                                return produto.getDtVencimentoNota();
                            case "cd_receita":
                                return produto.getCdReceita();
                            case "cd_despesa":
                                return produto.getCdDespesa();
                            case "cd_tipo":
                                return produto.getCdTipo();
                            case "vl_mao_obra":
                                return produto.getVlMaoObra();
                            case "modalidade_bc_icms":
                                return produto.getModalidadeBcIcms();
                            case "modalidade_bc_icms_st":
                                return produto.getModalidadeBcIcmsSt();
                            case "enquadramento_ipi":
                                return produto.getEnquadramentoIpi();
                            case "situacao_tributaria_ipi":
                                return produto.getSituacaoTributariaIpi();
                            case "situacao_tributaria_pis":
                                return produto.getSituacaoTributariaPis();
                            case "pr_aliquota_pis":
                                return produto.getPrAliquotaPis();
                            case "situacao_tributaria_cofins":
                                return produto.getSituacaoTributariaCofins();
                            case "pr_aliquota_cofins":
                                return produto.getPrAliquotaCofins();
                            case "pr_adicionado_substituicao":
                                return produto.getPrAdicionadoSubstituicao();
                            case "pr_substituicao":
                                return produto.getPrSubstituicao();
                            case "cd_tipo_entrada":
                                return produto.getCdTipoEntrada();
                            case "ds_aplicacao":
                                return produto.getDsAplicacao();
                            case "conversao":
                                return produto.getConversao();
                            case "pr_icms_compra":
                                return produto.getPrIcmsCompra();
                            case "somente_cotacao_compra":
                                return produto.getSomenteCotacaoCompra();
                            case "cd_grupo_servico_classificacao":
                                return produto.getCdGrupoServicoClassificacao();
                            case "cd_servico_classificacao":
                                return produto.getCdServicoClassificacao();
                            case "cd_tributacao_iss":
                                return produto.getCdTributacaoIss();
                            case "cd_tipo_item_sped":
                                return produto.getCdTipoItemSped();
                            case "cd_excecao_ncm_sped":
                                return produto.getCdExcecaoNcmSped();
                            case "cd_genero_sped":
                                return produto.getCdGeneroSped();
                            case "pr_reducao_icms_st":
                                return produto.getPrReducaoIcmsSt();
                            case "pr_fator_reducao_sn_st":
                                return produto.getPrFatorReducaoSnSt();
                            case "indice_ajuste_mva":
                                return produto.getIndiceAjusteMva();
                            case "movto_sped":
                                return produto.getMovtoSped();
                            case "prioridade_ordem":
                                return produto.getPrioridadeOrdem();
                            case "altera_descricao_compra":
                                return produto.getAlteraDescricaoCompra();
                            case "libera_locacao":
                                return produto.getLiberaLocacao();
                            case "criptografia":
                                return produto.getCriptografia();
                            case "cd_anp":
                                return produto.getCdAnp();
                            case "largura":
                                return produto.getLargura();
                            case "profundidade":
                                return produto.getProfundidade();
                            case "altura":
                                return produto.getAltura();
                            case "sazonal":
                                return produto.getSazonal();
                            case "nr_especificacao_icms":
                                return produto.getNrEspecificacaoIcms();
                            case "nr_especificacao_pis_cofins":
                                return produto.getNrEspecificacaoPisCofins();
                            case "nr_especificacao_ipi":
                                return produto.getNrEspecificacaoIpi();
                            case "situacao_tributaria_compra":
                                return produto.getSituacaoTributariaCompra();
                            case "pr_icms_ajuste_mva":
                                return produto.getPrIcmsAjusteMva();
                            case "pr_reducao_icms_compra":
                                return produto.getPrReducaoIcmsCompra();
                            case "nr_especificacao_compras":
                                return produto.getNrEspecificacaoCompras();
                            case "nm_usuario_alteracao":
                                return produto.getNmUsuarioAlteracao();
                            case "dt_alteracao":
                                return produto.getDtAlteracao();
                            case "cest":
                                return produto.getCest();
                            case "pr_desconto_demander":
                                return produto.getPrDescontoDemander();
                            case "fci":
                                return produto.getFci();
                            case "cd_fabricante":
                                return produto.getCdFabricante();
                            case "pis_cofins_monofasico":
                                return produto.getPisCofinsMonofasico();
                            case "vl_bc_icms_st_ret":
                                return produto.getVlBcIcmsStRet();
                            case "pr_st_ret":
                                return produto.getPrStRet();
                            case "vl_icms_ret":
                                return produto.getVlIcmsRet();
                            case "vl_icms_st_ret":
                                return produto.getVlIcmsStRet();
                            case "cd_similaridade":
                                return produto.getCdSimilaridade();
                            case "verificado_autokm":
                                return produto.getVerificadoAutokm();
                            case "ds_fabricante_autokm":
                                return produto.getDsFabricanteAutokm();
                            case "qt_fracionada":
                                return produto.getQtFracionada();
                            case "cd_unidade_fracionada":
                                return produto.getCdUnidadeFracionada();
                            case "cd_aliquota":
                                return produto.getCdAliquota();
                            case "cd_produto_agrupador":
                                return produto.getCdProdutoAgrupador();
                            case "obs_loja_virtual":
                                return produto.getObsLojaVirtual();
                            case "icms_st_retido_anteriormente":
                                return produto.getIcmsStRetidoAnteriormente();
                            default:
                                logger.warn("Campo não reconhecido: {}", field);
                                return null;
                        }
                    } catch (Exception e) {
                        logger.error("Erro ao acessar o campo {} para o produto: {}", field, produto, e);
                        return null;
                    }
                }).setKey(field);

                column.setHeader(config.getHeader());
                column.setWidth(config.getWidth());
                column.setSortable(true);
                column.setVisible(true);

                // Aplicar estilo do XML
                if (config.getStyle() != null && !config.getStyle().isEmpty()) {
                    String[] styleRules = config.getStyle().split(";");
                    for (String rule : styleRules) {
                        if (rule.trim().isEmpty()) continue;
                        String[] parts = rule.split(":");
                        if (parts.length == 2) {
                            String property = parts[0].trim();
                            String value = parts[1].trim();
                            column.getElement().getStyle().set(property, value);
                        }
                    }
                }

                GridFilterUtil.ColumnConfig<Produto> columnConfig = new GridFilterUtil.ColumnConfig<>(
                    column,
                    config.getHeader(),
                    produto -> {
                        switch (field) {
                            case "cd_produto":
                                return String.valueOf(produto.getCdProduto());
                            case "nr_digito":
                                return String.valueOf(produto.getNrDigito());
                            case "ds_produto":
                                return produto.getDsProduto();
                            case "ds_abreviacao":
                                return produto.getDsAbreviacao();
                            case "cd_subgrupo":
                                return String.valueOf(produto.getCdSubgrupo());
                            case "cd_grupo":
                                return String.valueOf(produto.getCdGrupo());
                            case "cd_marca":
                                return String.valueOf(produto.getCdMarca());
                            case "cd_cor":
                                return String.valueOf(produto.getCdCor());
                            case "voltagem":
                                return produto.getVoltagem();
                            case "cd_fornecedor":
                                return String.valueOf(produto.getCdFornecedor());
                            case "situacao":
                                return produto.getSituacao();
                            case "reducao_icms":
                                return String.valueOf(produto.getReducaoIcms());
                            case "icms":
                                return String.valueOf(produto.getIcms());
                            case "ipi":
                                return String.valueOf(produto.getIpi());
                            case "classificacao_fiscal":
                                return String.valueOf(produto.getClassificacaoFiscal());
                            case "origem_situacao_tributaria":
                                return produto.getOrigemSituacaoTributaria();
                            case "situacao_tributaria":
                                return produto.getSituacaoTributaria();
                            case "vl_contabil":
                                return String.valueOf(produto.getVlContabil());
                            case "vl_compra":
                                return String.valueOf(produto.getVlCompra());
                            case "vl_venda":
                                return String.valueOf(produto.getVlVenda());
                            case "vl_custo":
                                return String.valueOf(produto.getVlCusto());
                            case "comissao":
                                return String.valueOf(produto.getComissao());
                            case "lucro":
                                return String.valueOf(produto.getLucro());
                            case "estoque_minimo":
                                return String.valueOf(produto.getEstoqueMinimo());
                            case "estoque_maximo":
                                return String.valueOf(produto.getEstoqueMaximo());
                            case "cd_unidade":
                                return String.valueOf(produto.getCdUnidade());
                            case "vl_custo_medio":
                                return String.valueOf(produto.getVlCustoMedio());
                            case "pr_desconto_vendedor":
                                return String.valueOf(produto.getPrDescontoVendedor());
                            case "pr_desconto_gerente":
                                return String.valueOf(produto.getPrDescontoGerente());
                            case "saldo_negativo":
                                return produto.getSaldoNegativo();
                            case "cd_barra":
                                return produto.getCdBarra();
                            case "nr_componentes":
                                return String.valueOf(produto.getNrComponentes());
                            case "referencia":
                                return produto.getReferencia();
                            case "dt_cadastro":
                                return produto.getDtCadastro() != null ? produto.getDtCadastro().toString() : null;
                            case "altera_preco":
                                return produto.getAlteraPreco();
                            case "prateleira":
                                return produto.getPrateleira();
                            case "peso":
                                return String.valueOf(produto.getPeso());
                            case "cubagem":
                                return String.valueOf(produto.getCubagem());
                            case "cd_fabrica":
                                return produto.getCdFabrica();
                            case "capacidade":
                                return String.valueOf(produto.getCapacidade());
                            case "combustivel":
                                return produto.getCombustivel();
                            case "renavam":
                                return produto.getRenavam();
                            case "chassi":
                                return produto.getChassi();
                            case "motor":
                                return produto.getMotor();
                            case "potencia":
                                return produto.getPotencia();
                            case "ano_fabricacao":
                                return String.valueOf(produto.getAnoFabricacao());
                            case "ano_modelo":
                                return String.valueOf(produto.getAnoModelo());
                            case "cilindrada":
                                return produto.getCilindrada();
                            case "cd_perfil":
                                return produto.getCdPerfil();
                            case "cd_acabamento":
                                return produto.getCdAcabamento();
                            case "gravura":
                                return produto.getGravura();
                            case "sombra":
                                return produto.getSombra();
                            case "ncm":
                                return produto.getNcm();
                            case "vl_ipi":
                                return String.valueOf(produto.getVlIpi());
                            case "vl_substituicao":
                                return String.valueOf(produto.getVlSubstituicao());
                            case "cd_montadora":
                                return produto.getCdMontadora();
                            case "tamanho":
                                return produto.getTamanho();
                            case "pr_proteina":
                                return String.valueOf(produto.getPrProteina());
                            case "tp_produto":
                                return produto.getTpProduto();
                            case "ds_modelo":
                                return produto.getDsModelo();
                            case "comissao2":
                                return String.valueOf(produto.getComissao2());
                            case "comissao3":
                                return String.valueOf(produto.getComissao3());
                            case "numero":
                                return produto.getNumero();
                            case "capacidade_volumetrica":
                                return String.valueOf(produto.getCapacidadeVolumetrica());
                            case "cd_produto_dnf":
                                return produto.getCdProdutoDnf();
                            case "kg_milheiro":
                                return String.valueOf(produto.getKgMilheiro());
                            case "nm_usuario":
                                return produto.getNmUsuario();
                            case "dias_entrega":
                                return String.valueOf(produto.getDiasEntrega());
                            case "classificacao":
                                return produto.getClassificacao();
                            case "qt_pecas_um_volume":
                                return String.valueOf(produto.getQtPecasUmVolume());
                            case "obs_orcamento":
                                return produto.getObsOrcamento();
                            case "obs_nf":
                                return produto.getObsNf();
                            case "nr_meses_garantia":
                                return String.valueOf(produto.getNrMesesGarantia());
                            case "pr_desconto_gerente_2":
                                return String.valueOf(produto.getPrDescontoGerente2());
                            case "pr_desconto_vendedor_2":
                                return String.valueOf(produto.getPrDescontoVendedor2());
                            case "peso_bruto":
                                return String.valueOf(produto.getPesoBruto());
                            case "caminho_foto":
                                return produto.getCaminhoFoto();
                            case "vl_dec":
                                return produto.getVlDec();
                            case "montadora":
                                return produto.getMontadora();
                            case "ipi_venda":
                                return String.valueOf(produto.getIpiVenda());
                            case "ano_fabricabao":
                                return produto.getAnoFabricabao();
                            case "prioridade":
                                return produto.getPrioridade();
                            case "pis_cofins":
                                return produto.getPisCofins();
                            case "dt_vencimento_nota":
                                return produto.getDtVencimentoNota() != null ? produto.getDtVencimentoNota().toString() : null;
                            case "cd_receita":
                                return produto.getCdReceita();
                            case "cd_despesa":
                                return String.valueOf(produto.getCdDespesa());
                            case "cd_tipo":
                                return String.valueOf(produto.getCdTipo());
                            case "vl_mao_obra":
                                return String.valueOf(produto.getVlMaoObra());
                            case "modalidade_bc_icms":
                                return String.valueOf(produto.getModalidadeBcIcms());
                            case "modalidade_bc_icms_st":
                                return String.valueOf(produto.getModalidadeBcIcmsSt());
                            case "enquadramento_ipi":
                                return produto.getEnquadramentoIpi();
                            case "situacao_tributaria_ipi":
                                return produto.getSituacaoTributariaIpi();
                            case "situacao_tributaria_pis":
                                return produto.getSituacaoTributariaPis();
                            case "pr_aliquota_pis":
                                return String.valueOf(produto.getPrAliquotaPis());
                            case "situacao_tributaria_cofins":
                                return produto.getSituacaoTributariaCofins();
                            case "pr_aliquota_cofins":
                                return String.valueOf(produto.getPrAliquotaCofins());
                            case "pr_adicionado_substituicao":
                                return String.valueOf(produto.getPrAdicionadoSubstituicao());
                            case "pr_substituicao":
                                return String.valueOf(produto.getPrSubstituicao());
                            case "cd_tipo_entrada":
                                return String.valueOf(produto.getCdTipoEntrada());
                            case "ds_aplicacao":
                                return produto.getDsAplicacao();
                            case "conversao":
                                return produto.getConversao();
                            case "pr_icms_compra":
                                return String.valueOf(produto.getPrIcmsCompra());
                            case "somente_cotacao_compra":
                                return produto.getSomenteCotacaoCompra();
                            case "cd_grupo_servico_classificacao":
                                return String.valueOf(produto.getCdGrupoServicoClassificacao());
                            case "cd_servico_classificacao":
                                return String.valueOf(produto.getCdServicoClassificacao());
                            case "cd_tributacao_iss":
                                return produto.getCdTributacaoIss();
                            case "cd_tipo_item_sped":
                                return produto.getCdTipoItemSped();
                            case "cd_excecao_ncm_sped":
                                return produto.getCdExcecaoNcmSped();
                            case "cd_genero_sped":
                                return produto.getCdGeneroSped();
                            case "pr_reducao_icms_st":
                                return String.valueOf(produto.getPrReducaoIcmsSt());
                            case "pr_fator_reducao_sn_st":
                                return String.valueOf(produto.getPrFatorReducaoSnSt());
                            case "indice_ajuste_mva":
                                return String.valueOf(produto.getIndiceAjusteMva());
                            case "movto_sped":
                                return produto.getMovtoSped();
                            case "prioridade_ordem":
                                return String.valueOf(produto.getPrioridadeOrdem());
                            case "altera_descricao_compra":
                                return produto.getAlteraDescricaoCompra();
                            case "libera_locacao":
                                return produto.getLiberaLocacao();
                            case "criptografia":
                                return produto.getCriptografia();
                            case "cd_anp":
                                return produto.getCdAnp();
                            case "largura":
                                return String.valueOf(produto.getLargura());
                            case "profundidade":
                                return String.valueOf(produto.getProfundidade());
                            case "altura":
                                return String.valueOf(produto.getAltura());
                            case "sazonal":
                                return produto.getSazonal();
                            case "nr_especificacao_icms":
                                return String.valueOf(produto.getNrEspecificacaoIcms());
                            case "nr_especificacao_pis_cofins":
                                return String.valueOf(produto.getNrEspecificacaoPisCofins());
                            case "nr_especificacao_ipi":
                                return String.valueOf(produto.getNrEspecificacaoIpi());
                            case "situacao_tributaria_compra":
                                return produto.getSituacaoTributariaCompra();
                            case "pr_icms_ajuste_mva":
                                return String.valueOf(produto.getPrIcmsAjusteMva());
                            case "pr_reducao_icms_compra":
                                return String.valueOf(produto.getPrReducaoIcmsCompra());
                            case "nr_especificacao_compras":
                                return String.valueOf(produto.getNrEspecificacaoCompras());
                            case "nm_usuario_alteracao":
                                return produto.getNmUsuarioAlteracao();
                            case "dt_alteracao":
                                return produto.getDtAlteracao() != null ? produto.getDtAlteracao().toString() : null;
                            case "cest":
                                return produto.getCest();
                            case "pr_desconto_demander":
                                return String.valueOf(produto.getPrDescontoDemander());
                            case "fci":
                                return produto.getFci();
                            case "cd_fabricante":
                                return produto.getCdFabricante();
                            case "pis_cofins_monofasico":
                                return String.valueOf(produto.getPisCofinsMonofasico());
                            case "vl_bc_icms_st_ret":
                                return String.valueOf(produto.getVlBcIcmsStRet());
                            case "pr_st_ret":
                                return String.valueOf(produto.getPrStRet());
                            case "vl_icms_ret":
                                return String.valueOf(produto.getVlIcmsRet());
                            case "vl_icms_st_ret":
                                return String.valueOf(produto.getVlIcmsStRet());
                            case "cd_similaridade":
                                return String.valueOf(produto.getCdSimilaridade());
                            case "verificado_autokm":
                                return String.valueOf(produto.getVerificadoAutokm());
                            case "ds_fabricante_autokm":
                                return produto.getDsFabricanteAutokm();
                            case "qt_fracionada":
                                return String.valueOf(produto.getQtFracionada());
                            case "cd_unidade_fracionada":
                                return String.valueOf(produto.getCdUnidadeFracionada());
                            case "cd_aliquota":
                                return String.valueOf(produto.getCdAliquota());
                            case "cd_produto_agrupador":
                                return String.valueOf(produto.getCdProdutoAgrupador());
                            case "obs_loja_virtual":
                                return produto.getObsLojaVirtual();
                            case "icms_st_retido_anteriormente":
                                return String.valueOf(produto.getIcmsStRetidoAnteriormente());
                            default:
                                return null;
                        }
                    },
                    config
                );

                columnConfigs.add(columnConfig);
            }
        }

        logger.info("Total de colunas configuradas: {}", grid.getColumns().size());
        return columnConfigs;
    }

    private void openCadastroDialog(Produto produto) {
        logger.info("Abrindo diálogo de edição para produto: {}", produto.getCdProduto());
        try {
            produtoCadastro.initialize(produto, updatedProduto -> {
                logger.info("Produto atualizado: {}", updatedProduto.getCdProduto());
                grid.getDataProvider().refreshAll();
            });
            logger.info("Chamando produtoCadastro.open()");
            produtoCadastro.open();
            logger.info("Diálogo de edição aberto com sucesso");
        } catch (Exception e) {
            logger.error("Erro ao abrir diálogo de edição: {}", e.getMessage(), e);
            Notification.show("Erro ao abrir a tela de edição: " + e.getMessage(), 3000, Notification.Position.TOP_CENTER);
        }
    }

    private Integer getNextCdProduto() {
        logger.info("Calculando próximo cd_produto");
        List<Produto> produtos = produtoService.listar();
        return produtos.stream()
                .map(Produto::getCdProduto)
                .max(Integer::compareTo)
                .map(max -> max + 1)
                .orElse(1);
    }
}