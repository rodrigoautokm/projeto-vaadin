
package com.exemplo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.sql.DataSource;
import java.util.Date;
import java.util.List;

@Service
public class ListagemPedidoService {

    private static final Logger logger = LoggerFactory.getLogger(ListagemPedidoService.class);

    @Autowired
    private EmpresaConnectionManager empresaConnectionManager;

    @SuppressWarnings("unchecked")
    public List<ListagemPedidoResult> consultar(Date inicio, Date fim) {
        logger.info("Iniciando consulta de pedidos para o período: {} a {}", inicio, fim);

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        CustomUserDetails userDetails = (CustomUserDetails) auth.getPrincipal();
        Integer cdEmpresa = userDetails.getCdEmpresa().intValue();

        DataSource dataSource = empresaConnectionManager.getDataSourceForEmpresa(cdEmpresa);
        EntityManager em = JpaUtil.getEntityManager(dataSource);

        try {
            Query query = em.createNativeQuery("CALL pr_listagem_pedidos(:inicio, :fim)", "ListagemPedidoResultMapping");
            query.setParameter("inicio", inicio);
            query.setParameter("fim", fim);
            List<ListagemPedidoResult> result = query.getResultList();
            logger.info("Consulta retornou {} pedidos", result.size());
            return result;
        } catch (Exception e) {
            logger.error("Erro ao consultar pedidos: {}", e.getMessage(), e);
            throw new RuntimeException("Falha ao consultar pedidos: " + e.getMessage(), e);
        } finally {
            if (em != null && em.isOpen()) {
                em.close();
            }
        }
    }
}
