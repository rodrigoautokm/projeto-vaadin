package com.exemplo;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;

import java.util.Collection;

public class CustomUserDetails extends User {
    private Empresa empresa;

    private final Short cdEmpresa;

    public CustomUserDetails(String username, String password, Short cdEmpresa, Collection<? extends GrantedAuthority> authorities) {
        super(username, password, authorities);
        this.cdEmpresa = cdEmpresa;
    }

    public Short getCdEmpresa() {
        return cdEmpresa;
    }

    public void setEmpresa(Empresa empresa) {
        this.empresa = empresa;
    }
}