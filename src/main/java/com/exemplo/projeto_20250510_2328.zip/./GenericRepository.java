package com.exemplo;

import java.util.List;
import java.util.Optional;

public interface GenericRepository<T, ID> {
    List<T> listar();
    void save(T entity);
    Optional<T> findById(ID id);
    void delete(T entity);
}