package com.exemplo;

import org.hibernate.query.NativeQuery;
import org.hibernate.transform.ResultTransformer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.sql.DataSource;
import java.util.ArrayList;
import java.util.List;

@Service
public class VendasService {

    private static final Logger logger = LoggerFactory.getLogger(VendasService.class);

    @Autowired
    private EmpresaConnectionManager empresaConnectionManager;

    public List<VendasItem> executarRelVendas(int param1, String dataInicio, String dataFim, int param4, int param5,
                                              int param6, int param7, int param8, int param9, int param10, int param11,
                                              int param12, String param13, int param14, String param15, String param16,
                                              int param17, String param18, String param19, int param20) {
        logger.info("Consultando Vendas via JPA para o período: {} a {}", dataInicio, dataFim);

        CustomUserDetails userDetails = (CustomUserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Integer cdEmpresa = userDetails.getCdEmpresa().intValue();
        logger.info("Usuário autenticado com cdEmpresa: {}", cdEmpresa.intValue());

        DataSource dataSource = empresaConnectionManager.getDataSourceForEmpresa(cdEmpresa.intValue());
        if (dataSource == null) {
            logger.error("DataSource não configurado para a empresa: {}", cdEmpresa.intValue());
            return new ArrayList<>();
        }

        EntityManager em = null;
        try {
            em = JpaUtil.getEntityManager(dataSource);

            String sql = "CALL pr_rel_vendas_r04(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

            Query nativeQuery = em.createNativeQuery(sql);
            nativeQuery.setParameter(1, param1);
            nativeQuery.setParameter(2, dataInicio);
            nativeQuery.setParameter(3, dataFim);
            nativeQuery.setParameter(4, param4);
            nativeQuery.setParameter(5, param5);
            nativeQuery.setParameter(6, param6);
            nativeQuery.setParameter(7, param7);
            nativeQuery.setParameter(8, param8);
            nativeQuery.setParameter(9, param9);
            nativeQuery.setParameter(10, param10);
            nativeQuery.setParameter(11, param11);
            nativeQuery.setParameter(12, param12);
            nativeQuery.setParameter(13, param13);
            nativeQuery.setParameter(14, param14);
            nativeQuery.setParameter(15, param15);
            nativeQuery.setParameter(16, param16);
            nativeQuery.setParameter(17, param17);
            nativeQuery.setParameter(18, param18);
            nativeQuery.setParameter(19, param19);
            nativeQuery.setParameter(20, param20);

            NativeQuery<?> hibernateQuery = nativeQuery.unwrap(NativeQuery.class);
            hibernateQuery.setResultTransformer(new ResultTransformer() {
                @Override
                public Object transformTuple(Object[] tuple, String[] aliases) {
                    return new VendasItem(
                        safeString(tuple, 0),
                        safeString(tuple, 1),
                        safeString(tuple, 2),
                        safeDouble(tuple, 3),
                        safeDouble(tuple, 4),
                        safeDouble(tuple, 5),
                        safeDouble(tuple, 6),
                        safeString(tuple, 7),
                        safeString(tuple, 8),
                        safeString(tuple, 9)
                    );
                }

                @Override
                public List transformList(List collection) {
                    return collection;
                }
            });

            @SuppressWarnings("unchecked")
            List<VendasItem> resultados = (List<VendasItem>) hibernateQuery.getResultList();
            logger.info("Consulta executada com sucesso. Total de itens: {}", resultados.size());
            return resultados;

        } catch (Exception e) {
            logger.error("Erro ao consultar vendas via JPA: {}", e.getMessage(), e);
            return new ArrayList<>();
        } finally {
            if (em != null && em.isOpen()) {
                em.close();
            }
        }
    }

    private String safeString(Object[] row, int index) {
        try {
            Object value = row[index];
            return value != null ? value.toString() : "N/A";
        } catch (Exception e) {
            return "N/A";
        }
    }

    private Double safeDouble(Object[] row, int index) {
        try {
            Object value = row[index];
            return value != null ? Double.parseDouble(value.toString().replace(",", ".")) : 0.0;
        } catch (Exception e) {
            return 0.0;
        }
    }
}