package com.exemplo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class FiltroUsuarioService {

    private static final Logger logger = LoggerFactory.getLogger(FiltroUsuarioService.class);

    @Autowired
    private FiltroUsuarioRepository repository;

    public Map<String, String> carregarFiltros(String usuario, String viewId) {
        logger.debug("Carregando filtros para usuario: {} e viewId: {}", usuario, viewId);
        List<FiltroUsuario> filtros = repository.findByUsuarioAndViewId(usuario, viewId);
        return filtros.stream()
            .collect(Collectors.toMap(
                FiltroUsuario::getColuna,
                FiltroUsuario::getFiltros
            ));
    }

    @Transactional
    public void salvarFiltros(String usuario, String viewId, Map<String, String> filtros) {
        logger.debug("Salvando filtros para usuario: {} e viewId: {}", usuario, viewId);
        // Deletar filtros existentes para o usuario e viewId
        repository.deleteByUsuarioAndViewId(usuario, viewId);

        // Salvar novos filtros
        List<FiltroUsuario> entidades = filtros.entrySet().stream()
            .filter(entry -> entry.getValue() != null && !entry.getValue().isEmpty())
            .map(entry -> new FiltroUsuario(usuario, viewId, entry.getKey(), entry.getValue()))
            .collect(Collectors.toList());
        repository.saveAll(entidades);
        logger.debug("Filtros salvos: {}", entidades);
    }
}