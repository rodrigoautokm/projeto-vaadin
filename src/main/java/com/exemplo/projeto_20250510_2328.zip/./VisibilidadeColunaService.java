package com.exemplo;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.sql.DataSource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class VisibilidadeColunaService {

    public Map<String, Boolean> carregarPreferencias(String usuario, String viewId, DataSource dataSource) {
        EntityManager em = JpaUtil.getEntityManager(dataSource);
        try {
            String sql = "SELECT v FROM VisibilidadeColuna v WHERE v.usuario = :usuario AND v.viewId = :viewId";
            Query query = em.createQuery(sql, VisibilidadeColuna.class);
            query.setParameter("usuario", usuario);
            query.setParameter("viewId", viewId);
            List<VisibilidadeColuna> resultados = query.getResultList();

            Map<String, Boolean> mapa = new HashMap<>();
            for (VisibilidadeColuna v : resultados) {
                mapa.put(v.getColuna(), v.isVisivel());
            }
            return mapa;
        } finally {
            em.close();
        }
    }

    @Transactional
    public void salvar(String usuario, String viewId, Map<String, Boolean> preferencias, DataSource dataSource) {
        EntityManager em = JpaUtil.getEntityManager(dataSource);
        try {
            em.getTransaction().begin();
            em.createQuery("DELETE FROM VisibilidadeColuna v WHERE v.usuario = :usuario AND v.viewId = :viewId")
              .setParameter("usuario", usuario)
              .setParameter("viewId", viewId)
              .executeUpdate();

            for (Map.Entry<String, Boolean> entry : preferencias.entrySet()) {
                VisibilidadeColuna nova = new VisibilidadeColuna(usuario, viewId, entry.getKey(), entry.getValue());
                em.merge(nova);
            }

            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            throw new RuntimeException("Erro ao salvar visibilidade de colunas", e);
        } finally {
            em.close();
        }
    }
}