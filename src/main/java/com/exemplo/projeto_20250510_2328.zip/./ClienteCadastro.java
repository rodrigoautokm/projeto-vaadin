package com.exemplo;

import com.vaadin.flow.component.formlayout.FormLayout;
import com.vaadin.flow.component.textfield.TextField;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;

@Component
public class ClienteCadastro extends GenericaCadastro<Cliente> {

    public ClienteCadastro() {
        super();
    }

    @Override
    protected String getTitle() {
        return entity != null && entity.getId() != null ? "Editar Cliente" : "Novo Cliente";
    }

    @Override
    protected List<String> getCamposFixos() {
        return Arrays.asList("cd_cliente", "nm_cliente", "tipo", "endereco", "bairro", "fone", "celular", "cpf");
    }

    @Override
    protected String getSuccessMessage() {
        return "Cliente salvo com sucesso!";
    }

    @Override
    protected void buildForm(FormLayout form) {
        TextField nome = new TextField("Nome");
        binder.bind(nome, "nmCliente");
        form.add(nome);
    }
}
