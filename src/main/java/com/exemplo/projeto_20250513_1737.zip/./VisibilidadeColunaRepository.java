package com.exemplo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface VisibilidadeColunaRepository extends JpaRepository<VisibilidadeColuna, VisibilidadeColunaId> {
    List<VisibilidadeColuna> findByUsuarioAndViewId(String usuario, String viewId);

    @Modifying
    @Query("DELETE FROM VisibilidadeColuna v WHERE v.usuario = :usuario AND v.viewId = :viewId")
    void deleteByUsuarioAndViewId(String usuario, String viewId);
}