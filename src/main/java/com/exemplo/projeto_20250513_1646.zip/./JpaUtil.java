package com.exemplo;

import org.hibernate.jpa.HibernatePersistenceProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;
import java.util.HashMap;
import java.util.Map;

@Component
public class JpaUtil {

    private static EntityManagerFactory emf;

    @Autowired
    public JpaUtil(EntityManagerFactory entityManagerFactory) {
        JpaUtil.emf = entityManagerFactory;
    }

    public static EntityManager getEntityManager() {
        if (emf == null) {
            throw new IllegalStateException("EntityManagerFactory is not initialized");
        }
        return emf.createEntityManager();
    }

    public static EntityManager getEntityManager(DataSource dataSource) {
        Map<String, Object> properties = new HashMap<>();
        properties.put("hibernate.connection.datasource", dataSource);
        properties.put("hibernate.dialect", "org.hibernate.dialect.SQLAnywhereDialect");
        properties.put("hibernate.show_sql", false);
        properties.put("hibernate.format_sql", false);
        properties.put("hibernate.hbm2ddl.auto", "none");
        properties.put("hibernate.temp.use_jdbc_metadata_defaults", false);
        properties.put("hibernate.connection.characterEncoding", "ISO-8859-1");

        EntityManagerFactory dynamicEmf = new HibernatePersistenceProvider()
                .createEntityManagerFactory("dynamic-unit", properties);
        if (dynamicEmf == null) {
            throw new IllegalStateException("Failed to create EntityManagerFactory for DataSource");
        }
        return dynamicEmf.createEntityManager();
    }

    public static void closeEntityManager(EntityManager em) {
        if (em != null && em.isOpen()) {
            em.close();
        }
    }
}