package com.exemplo;

import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.router.BeforeEnterEvent;
import com.vaadin.flow.router.BeforeEnterObserver;
import com.vaadin.flow.router.Route;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication; // Adicionado
import org.springframework.security.core.context.SecurityContextHolder; // Adicionado
import org.springframework.stereotype.Component;

@Route(value = "marcas", layout = MainLayout.class)
@Component
public class MarcaView extends AbstractGridView<Marca> implements BeforeEnterObserver {

    private final MarcaRepository repository;

    @Autowired
    public MarcaView(MarcaRepository repository) {
        super("Marcas", "marcas", repository::findAll);
        this.repository = repository;
    }

    @Override
    protected Object getRepository() {
        return repository;
    }

    @Override
    public Class<Marca> getEntityClass() {
        return Marca.class;
    }

    @Override
    public void beforeEnter(BeforeEnterEvent event) {
        if (!isUserAuthenticated()) {
            event.rerouteTo("login");
            Notification.show("Por favor, faça login para acessar esta página.", 3000, Notification.Position.TOP_CENTER);
        }
    }

    private boolean isUserAuthenticated() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        return authentication != null && authentication.isAuthenticated() && !"anonymousUser".equals(authentication.getPrincipal());
    }
}