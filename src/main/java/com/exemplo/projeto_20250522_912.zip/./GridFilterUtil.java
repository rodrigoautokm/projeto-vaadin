package com.exemplo;

import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.checkbox.Checkbox;
import com.vaadin.flow.component.combobox.MultiSelectComboBox;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.grid.GridSortOrder;
import com.vaadin.flow.component.grid.HeaderRow;
import com.vaadin.flow.component.html.Span;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.data.provider.SortDirection;
import com.vaadin.flow.data.renderer.ComponentRenderer;
import com.vaadin.flow.shared.Registration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import org.springframework.dao.DataIntegrityViolationException;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class GridFilterUtil<T> {

    private static final Logger logger = LoggerFactory.getLogger(GridFilterUtil.class);

    private Grid<T> grid;
    private List<T> items;
    private String gridId;
    private String usuarioId;
    private Consumer<Map<String, String>> filterChangeListener;
    private Map<String, Set<String>> activeFilters = new HashMap<>();
    private List<ColumnConfig<T>> columnConfigs;
    private GridAggregationUtil<T> aggregationUtil;
    private final HorizontalLayout activeFiltersLayout;
    private boolean filtersChanged = false;
    private boolean columnOrderChanged = false;
    private boolean visibilityChanged = false;
    private List<String> initialColumnOrder;
    private Registration sortOrderListener;
    private String sortColumn;
    private String sortDirection;
    private boolean sortChanged = false;
    private boolean isProcessingReorder = false;
    private final GridColumnConfigService gridColumnConfigService;
    private VerticalLayout layoutRaiz;

    public GridFilterUtil(String gridId, Grid<T> grid, List<ColumnConfig<T>> columnConfigs, String usuarioId, Integer cdEmpresa) {
        logger.info("Inicializando GridFilterUtil para gridId: {}", gridId);
        this.gridId = gridId;
        this.grid = grid;
        this.columnConfigs = columnConfigs;
        this.usuarioId = usuarioId;
        this.activeFiltersLayout = new HorizontalLayout();
        this.activeFiltersLayout.setAlignItems(VerticalLayout.Alignment.CENTER);
        this.activeFiltersLayout.setSpacing(true);
        this.activeFiltersLayout.setMinWidth("300px");
        this.activeFiltersLayout.getStyle()
                .set("margin-left", "10px")
                .set("white-space", "nowrap")
                .set("flex-shrink", "0");

        this.gridColumnConfigService = AppContext.getBean(GridColumnConfigService.class);
        this.items = new ArrayList<>(); // Inicializar como mutável

        this.layoutRaiz = new VerticalLayout();
        this.layoutRaiz.setSizeFull();
        this.layoutRaiz.add(grid);

        initialize(gridId, grid, columnConfigs, () -> null);
    }

    public GridFilterUtil(Grid<T> grid, List<T> items, String gridId, String usuarioId, GridColumnConfigService gridColumnConfigService) {
        logger.info("Inicializando GridFilterUtil para gridId: {}", gridId);
        this.grid = grid;
        this.items = new ArrayList<>(items != null ? items : new ArrayList<>()); // Garantir que seja mutável
        this.gridId = gridId;
        this.usuarioId = usuarioId;
        this.gridColumnConfigService = gridColumnConfigService;
        this.activeFiltersLayout = new HorizontalLayout();
        this.activeFiltersLayout.setAlignItems(VerticalLayout.Alignment.CENTER);
        this.activeFiltersLayout.setSpacing(true);
        this.activeFiltersLayout.setMinWidth("300px");
        this.activeFiltersLayout.getStyle()
                .set("margin-left", "10px")
                .set("white-space", "nowrap")
                .set("flex-shrink", "0");

        this.layoutRaiz = new VerticalLayout();
        this.layoutRaiz.setSizeFull();
        this.layoutRaiz.add(grid);
    }

    public void initialize(String gridId, Grid<T> grid, List<ColumnConfig<T>> columnConfigs, Supplier<T> itemSupplier) {
        logger.info("Inicializando GridFilterUtil para gridId: {}. Colunas fornecidas: {}", gridId, columnConfigs.size());
        this.gridId = gridId;
        this.grid = grid;
        this.columnConfigs = new ArrayList<>(columnConfigs); // Garantir que seja mutável
        this.aggregationUtil = new GridAggregationUtil<>(this.items, this.columnConfigs);

        grid.setItems(this.items);
        grid.setColumnReorderingAllowed(true);
        logger.debug("Reordenação de colunas habilitada: {}", grid.isColumnReorderingAllowed());
        grid.getElement().setProperty("resizable", true);

        // Inicializar configurações padrão para todas as colunas
        initializeDefaultColumnConfigs();

        sortOrderListener = grid.addSortListener(event -> {
            logger.debug("Evento de ordenação disparado para gridId: {}", gridId);
            List<GridSortOrder<T>> sortOrders = event.getSortOrder();
            if (!sortOrders.isEmpty()) {
                GridSortOrder<T> sortOrder = sortOrders.get(0);
                sortColumn = sortOrder.getSorted().getKey();
                sortDirection = sortOrder.getDirection() == SortDirection.ASCENDING ? "ASC" : "DESC";
                logger.debug("Ordenação alterada para gridId: {}. Coluna: {}, Direção: {}", gridId, sortColumn, sortDirection);
                sortChanged = true;
            } else {
                sortColumn = null;
                sortDirection = null;
                logger.debug("Ordenação removida para gridId: {}", gridId);
                sortChanged = true;
            }
            salvarSortConfig();
        });

        grid.addColumnReorderListener(event -> {
            if (isProcessingReorder) {
                logger.debug("Evento de reordenação ignorado para evitar loop para gridId: {}", gridId);
                return;
            }

            try {
                isProcessingReorder = true;
                logger.debug("Evento de reordenação de colunas disparado para gridId: {}", gridId);
                final List<Grid.Column<T>> newOrder = event.getColumns();
                IntStream.range(0, newOrder.size()).forEach(i -> {
                    Grid.Column<T> column = newOrder.get(i);
                    String columnKey = column.getKey();
                    if (columnKey != null) {
                        columnConfigs.stream()
                            .filter(cfg -> columnKey.equals(cfg.getColumn().getKey()))
                            .findFirst()
                            .ifPresent(cfg -> {
                                ColumnConfigUsuario config = new ColumnConfigUsuario();
                                config.setClassName(gridId);
                                String fieldName = cfg.getGridColumnConfig().getField();
                                config.setFieldName(fieldName);
                                config.setUsuario(usuarioId);
                                config.setOrdenacaoGrid(i + 1);
                                saveColumnConfig(config);
                            });
                    }
                });
                logger.debug("Nova ordem das colunas salva para gridId: {}", gridId);
            } finally {
                isProcessingReorder = false;
            }
        });

        logger.debug("GridFilterUtil inicializado com {} itens iniciais", this.items.size());
        adicionarFiltrosNoCabecalho(columnConfigs);
    }

    private void initializeDefaultColumnConfigs() {
        logger.debug("Inicializando configurações padrão para gridId: {} e usuario: {}", gridId, usuarioId);
        ColumnConfigUsuarioRepository repository = AppContext.getBean(ColumnConfigUsuarioRepository.class);
        List<ColumnConfigUsuario> existingConfigs = repository.findByUsuarioAndClassName(usuarioId, gridId);

        Set<String> existingFields = existingConfigs.stream()
            .map(ColumnConfigUsuario::getFieldName)
            .collect(Collectors.toSet());

        List<String> columnKeys = columnConfigs.stream()
            .map(cfg -> cfg.column.getKey())
            .filter(Objects::nonNull)
            .collect(Collectors.toList());

        IntStream.range(0, columnKeys.size()).forEach(i -> {
            String columnKey = columnKeys.get(i);
            String fieldName = columnConfigs.stream()
                .filter(cfg -> cfg.column.getKey().equals(columnKey))
                .findFirst()
                .map(cfg -> cfg.getGridColumnConfig().getField())
                .orElse(columnKey);

            if (existingFields.contains(fieldName)) {
                logger.debug("Configuração já existe para field_name='{}', ignorando inserção.", fieldName);
                return;
            }

            existingFields.add(fieldName);

            logger.debug("Criando configuração padrão para coluna: {}, field_name: {}", columnKey, fieldName);
            ColumnConfigUsuario config = new ColumnConfigUsuario();
            config.setClassName(gridId);
            config.setFieldName(fieldName);
            config.setUsuario(usuarioId);
            config.setVisible("1");
            config.setOrdenacaoGrid(i + 1);
            config.setSort(null);
            config.setFiltroAplicado(null);
            repository.save(config);
        });
    }

    public void saveChanges() {
        logger.debug("Verificando mudanças para salvar no gridId: {}", gridId);

        logger.debug("visibilityChanged: {}, filtersChanged: {}, columnOrderChanged: {}", 
                visibilityChanged, filtersChanged, columnOrderChanged);
        if (visibilityChanged) {
            salvarPreferencias();
            visibilityChanged = false;
        }
        if (filtersChanged) {
            salvarFiltros();
            filtersChanged = false;
        }
        if (columnOrderChanged) {
            List<Grid.Column<T>> columns = grid.getColumns();
            IntStream.range(0, columns.size()).forEach(i -> {
                Grid.Column<T> column = columns.get(i);
                String columnKey = column.getKey();
                if (columnKey != null) {
                    columnConfigs.stream()
                        .filter(cfg -> columnKey.equals(cfg.getColumn().getKey()))
                        .findFirst()
                        .ifPresent(cfg -> {
                            ColumnConfigUsuario config = new ColumnConfigUsuario();
                            config.setClassName(gridId);
                            String fieldName = cfg.getGridColumnConfig().getField();
                            config.setFieldName(fieldName);
                            config.setUsuario(usuarioId);
                            config.setOrdenacaoGrid(i + 1);
                            saveColumnConfig(config);
                        });
                }
            });
            columnOrderChanged = false;
        }

        if (sortOrderListener != null) {
            sortOrderListener.remove();
            sortOrderListener = null;
        }
    }

    private List<VwColumnConfigEntity> loadColumnConfigs() {
        VwColumnConfigRepository repository = AppContext.getBean(VwColumnConfigRepository.class);
        List<VwColumnConfigEntity> configs = repository.findByClassName(gridId);
        logger.debug("Configurações carregadas da view vw_column_config para gridId {}: {} entradas", gridId, configs.size());
        return configs;
    }

    private void carregarPreferencias() {
        logger.debug("Carregando preferências para gridId: {} e usuario: {}", gridId, usuarioId);
        
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        Integer cdEmpresa = null;
        if (auth != null && auth.getPrincipal() instanceof CustomUserDetails) {
            Integer cdEmpresaInteger = ((CustomUserDetails) auth.getPrincipal()).getCdEmpresa();
            cdEmpresa = cdEmpresaInteger != null ? cdEmpresaInteger.intValue() : null;
        }

        if (cdEmpresa == null || cdEmpresa <= 0) {
            logger.warn("cdEmpresa ausente ou inválido ({}), ignorando carregamento de preferências para gridId: {}", cdEmpresa, gridId);
            return;
        }

        Map<String, Boolean> preferencias = new HashMap<>();
        try {
            List<VwColumnConfigEntity> configs = loadColumnConfigs();
            for (VwColumnConfigEntity config : configs) {
                String visibleValue = config.getVisible();
                boolean isVisible = "1".equalsIgnoreCase(visibleValue) || "S".equalsIgnoreCase(visibleValue);
                preferencias.put(config.getFieldName(), isVisible);
            }
            logger.debug("Preferências carregadas para gridId {} e usuario {}: {}", gridId, usuarioId, preferencias);
            List<String> columnKeys = grid.getColumns().stream()
                .map(Grid.Column::getKey)
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
            logger.debug("Chaves das colunas no grid: {}", columnKeys);
        } catch (Exception e) {
            logger.error("Erro ao carregar preferências para gridId: {} e usuario: {}. Usando configurações padrão.", gridId, usuarioId, e);
            preferencias = new HashMap<>();
        }
    
        if (!preferencias.isEmpty()) {
            final Map<String, Boolean> preferenciaFinal = preferencias;
            grid.getColumns().forEach(column -> {
                String columnKey = column.getKey();
                if (columnKey != null && preferenciaFinal.containsKey(columnKey)) {
                    Boolean visible = preferenciaFinal.get(columnKey);
                    column.setVisible(visible);
                    logger.debug("Coluna {} visibilidade definida como {} via preferências do banco de dados", columnKey, visible);
                } else {
                    logger.warn("Coluna {} não encontrada nas preferências ou chave ausente, usando visibilidade padrão (true)", columnKey);
                    column.setVisible(true);
                }
            });
        } else {
            logger.debug("Nenhuma preferência encontrada para gridId: {} e usuario: {}, inicializando configurações padrão", gridId, usuarioId);
            initializeDefaultColumnConfigs();
            carregarPreferencias();
        }
    }

    private void salvarPreferencias() {
        logger.debug("Salvando preferências para gridId: {} e usuario: {}", gridId, usuarioId);
        try {
            ColumnConfigUsuarioRepository repository = AppContext.getBean(ColumnConfigUsuarioRepository.class);
            Map<String, Boolean> preferencias = grid.getColumns().stream()
                    .filter(col -> col.getKey() != null)
                    .collect(Collectors.toMap(
                            Grid.Column::getKey,
                            Grid.Column::isVisible
                    ));
            
            logger.debug("Preferências a serem salvas: {}", preferencias);
            
            for (Map.Entry<String, Boolean> entry : preferencias.entrySet()) {
                String columnKey = entry.getKey();
                Boolean visible = entry.getValue();
                
                String fieldName = columnConfigs.stream()
                    .filter(cfg -> cfg.column.getKey().equals(columnKey))
                    .findFirst()
                    .map(cfg -> cfg.getGridColumnConfig().getField())
                    .orElse(columnKey);
                
                List<ColumnConfigUsuario> existingList = repository.findByUsuarioAndClassNameAndFieldName(usuarioId, gridId, fieldName);
                Optional<ColumnConfigUsuario> existingConfig = existingList.stream().findFirst();
                
                ColumnConfigUsuario config = existingConfig.orElse(new ColumnConfigUsuario());
                
                config.setClassName(gridId);
                config.setFieldName(fieldName);
                config.setUsuario(usuarioId);
                config.setVisible(visible ? "1" : "0");
                if (config.getOrdenacaoGrid() == null) {
                    config.setOrdenacaoGrid(0);
                }
                
                try {
                    repository.save(config);
                    logger.debug("Configuração salva: fieldName={}, visible={}", fieldName, visible);
                } catch (DataIntegrityViolationException e) {
                    logger.warn("Configuração duplicada detectada para usuario={}, className={}, fieldName={}. Tentando atualizar...", 
                        usuarioId, gridId, fieldName);
                    existingList = repository.findByUsuarioAndClassNameAndFieldName(usuarioId, gridId, fieldName);
                    existingConfig = existingList.stream().findFirst();
                    if (existingConfig.isPresent()) {
                        ColumnConfigUsuario existing = existingConfig.get();
                        existing.setVisible(visible ? "1" : "0");
                        repository.save(existing);
                        logger.info("Configuração atualizada com sucesso: fieldName={}", fieldName);
                    } else {
                        logger.error("Erro ao salvar configuração: {}", e.getMessage(), e);
                        throw e;
                    }
                }
            }

            logger.info("Preferências de visibilidade salvas no banco de dados para gridId={} e usuario={}", gridId, usuarioId);
        } catch (Exception e) {
            logger.error("Erro ao salvar preferências de visibilidade para gridId: {} e usuario: {}", gridId, usuarioId, e);
            throw e;
        }
    }

    private Map<String, String> carregarFiltros() {
        logger.debug("Carregando filtros para gridId: {} e usuario: {}", gridId, usuarioId);
        Map<String, String> filtros = new HashMap<>();
        try {
            List<ColumnConfig<T>> configs = columnConfigs;
            for (ColumnConfig<T> config : configs) {
                GridColumnConfig gridColumnConfig = config.getGridColumnConfig();
                if (gridColumnConfig != null && gridColumnConfig.getFiltroAplicado() != null && !gridColumnConfig.getFiltroAplicado().isEmpty()) {
                    filtros.put(gridColumnConfig.getField(), gridColumnConfig.getFiltroAplicado());
                }
            }
            logger.debug("Filtros carregados: {}", filtros);
            return filtros;
        } catch (Exception e) {
            logger.error("Erro ao carregar filtros para gridId: {} e usuario: {}", gridId, usuarioId, e);
            return new HashMap<>();
        }
    }

    private void salvarFiltros() {
    logger.debug("Salvando filtros para gridId: {} e usuario: {}", gridId, usuarioId);
    try {
        ColumnConfigUsuarioRepository repository = AppContext.getBean(ColumnConfigUsuarioRepository.class);

        Map<String, String> filtros = activeFilters.entrySet().stream()
                .collect(Collectors.toMap(
                        Map.Entry::getKey,
                        entry -> String.join("-", entry.getValue())
                ));

        for (Map.Entry<String, String> entry : filtros.entrySet()) {
            String columnKey = entry.getKey();
            String filterValue = entry.getValue();

            String fieldName = columnConfigs.stream()
                    .filter(cfg -> cfg.column.getKey().equals(columnKey))
                    .findFirst()
                    .map(cfg -> cfg.getGridColumnConfig().getField())
                    .orElse(columnKey);

            Optional<ColumnConfigUsuario> existingConfigOpt = repository
                    .findByUsuarioAndClassNameAndFieldName(usuarioId, gridId, fieldName)
                    .stream()
                    .findFirst();

            ColumnConfigUsuario config = existingConfigOpt.orElse(new ColumnConfigUsuario());
            config.setClassName(gridId);
            config.setFieldName(fieldName);
            config.setUsuario(usuarioId);
            config.setFiltroAplicado(filterValue);

            if (config.getOrdenacaoGrid() == null) {
                config.setOrdenacaoGrid(0);
            }
            if (config.getVisible() == null) {
                config.setVisible("1");
            }

            repository.save(config);
            logger.debug("Filtro salvo para coluna '{}': {}", fieldName, filterValue);
        }

        logger.info("Filtros salvos no banco de dados para gridId={} e usuario={}", gridId, usuarioId);
    } catch (Exception e) {
        logger.error("Erro ao salvar filtros para gridId: {} e usuario: {}", gridId, usuarioId, e);
    }
}

	
    private String carregarOrdemColunas() {
        logger.debug("Carregando ordem das colunas para gridId: {} e usuario: {}", gridId, usuarioId);
        try {
            List<ColumnConfig<T>> configs = columnConfigs;
            List<String> orderedKeys = configs.stream()
                .filter(cfg -> cfg.getGridColumnConfig() != null)
                .filter(cfg -> cfg.getGridColumnConfig().getOrdenacaoGrid() != null)
                .sorted(Comparator.comparingInt(cfg -> cfg.getGridColumnConfig().getOrdenacaoGrid()))
                .map(cfg -> cfg.getGridColumnConfig().getField())
                .collect(Collectors.toList());
            String ordemColunas = String.join("-", orderedKeys);
            logger.debug("Ordem das colunas carregada: {}", ordemColunas);
            return ordemColunas;
        } catch (Exception e) {
            logger.error("Erro ao carregar ordem das colunas para gridId: {} e usuario: {}", gridId, usuarioId, e);
            return null;
        }
    }

@Transactional
private void salvarSortConfig() {
    logger.debug("Salvando sort_config para gridId={} e usuario={}", gridId, usuarioId);
    try {
        ColumnConfigUsuarioRepository repository = AppContext.getBean(ColumnConfigUsuarioRepository.class);

        // Zera a ordenação de todas as colunas do usuário e grid
        List<ColumnConfigUsuario> allConfigs = repository.findByUsuarioAndClassName(usuarioId, gridId);
        for (ColumnConfigUsuario cfg : allConfigs) {
            if (cfg.getSort() != null) {
                cfg.setSort(null);
                repository.save(cfg);
            }
        }

        if (sortColumn != null && sortDirection != null) {
            String fieldName = columnConfigs.stream()
                .filter(cfg -> cfg.column.getKey().equals(sortColumn))
                .findFirst()
                .map(cfg -> cfg.getGridColumnConfig().getField())
                .orElse(sortColumn);

            List<ColumnConfigUsuario> existingConfigs = repository.findByUsuarioAndClassNameAndFieldName(
                usuarioId, gridId, fieldName
            );

            ColumnConfigUsuario config;
            if (!existingConfigs.isEmpty()) {
                config = existingConfigs.get(0);
                logger.debug("Atualizando sort da coluna '{}'", fieldName);
            } else {
                config = new ColumnConfigUsuario();
                config.setClassName(gridId);
                config.setFieldName(fieldName);
                config.setUsuario(usuarioId);
                config.setVisible("1");
                config.setOrdenacaoGrid(0);
                logger.debug("Criando nova configuração com sort para '{}'", fieldName);
            }

            config.setSort(sortDirection);
            repository.save(config);

            logger.info("Sort_config salvo: usuario={}, gridId={}, sortColumn={}, sortDirection={}", 
                usuarioId, gridId, fieldName, sortDirection);
        } else {
            logger.debug("sortColumn ou sortDirection nulo. Nenhuma ordenação será salva.");
        }
    } catch (Exception e) {
        logger.error("Erro ao salvar sort_config para gridId={} e usuario={}: {}", gridId, usuarioId, e.getMessage(), e);
    }
}


    private void carregarSortConfig() {
        logger.debug("Carregando configuração de sort para gridId={} e usuario={}", gridId, usuarioId);
        try {
            List<ColumnConfig<T>> configs = columnConfigs;
            ColumnConfig<T> configWithSort = configs.stream()
                .filter(c -> c.getGridColumnConfig() != null && c.getGridColumnConfig().getSort() != null)
                .findFirst()
                .orElse(null);
            
            if (configWithSort != null) {
                sortColumn = configWithSort.getGridColumnConfig().getField();
                sortDirection = configWithSort.getGridColumnConfig().getSort();
                logger.debug("Configuração de ordenação encontrada: coluna={}, direção={}", sortColumn, sortDirection);
                grid.getColumns().stream()
                        .filter(c -> sortColumn.equals(c.getKey()))
                        .filter(Grid.Column::isVisible)
                        .findFirst()
                        .ifPresentOrElse(column -> {
                            SortDirection dir = "ASC".equalsIgnoreCase(sortDirection) ? SortDirection.ASCENDING : SortDirection.DESCENDING;
                            grid.sort(Collections.singletonList(new GridSortOrder<>(column, dir)));
                            logger.info("Ordenação aplicada: coluna={}, direção={}", sortColumn, sortDirection);
                        }, () -> {
                            logger.warn("Coluna de ordenação {} não está visível ou não existe. Usando ordenação padrão.", sortColumn);
                            aplicarOrdenacaoPadrao();
                        });
            } else {
                logger.debug("Nenhuma configuração de sort encontrada para gridId={} e usuario={}. Usando ordenação padrão.", gridId, usuarioId);
                aplicarOrdenacaoPadrao();
            }
        } catch (Exception e) {
            logger.error("Erro ao carregar sort_config para gridId={} e usuario={}. Usando ordenação padrão.", gridId, usuarioId, e);
            aplicarOrdenacaoPadrao();
        }
    }

    private void aplicarOrdenacaoPadrao() {
        logger.debug("Aplicando ordenação padrão para gridId={}", gridId);
        grid.getColumns().stream()
                .filter(Grid.Column::isVisible)
                .findFirst()
                .ifPresentOrElse(column -> {
                    grid.sort(Collections.singletonList(new GridSortOrder<>(column, SortDirection.ASCENDING)));
                    logger.info("Ordenação padrão aplicada: coluna={}, direção=ASC", column.getKey());
                }, () -> {
                    logger.warn("Nenhuma coluna visível encontrada para aplicar ordenação padrão para gridId={}", gridId);
                });
    }

    private void saveColumnConfig(ColumnConfigUsuario config) {
        ColumnConfigUsuarioRepository repository = AppContext.getBean(ColumnConfigUsuarioRepository.class);
        List<ColumnConfigUsuario> existingConfigs = repository.findByUsuarioAndClassName(usuarioId, gridId);
        ColumnConfigUsuario existingConfig = existingConfigs.stream()
            .filter(c -> c.getFieldName().equals(config.getFieldName()))
            .findFirst()
            .orElse(new ColumnConfigUsuario());
        
        existingConfig.setClassName(config.getClassName());
        existingConfig.setFieldName(config.getFieldName());
        existingConfig.setUsuario(config.getUsuario());
        existingConfig.setOrdenacaoGrid(config.getOrdenacaoGrid());
        if (existingConfig.getVisible() == null) {
            existingConfig.setVisible("1");
        }
        repository.save(existingConfig);
    }

    public void setFilterChangeListener(Consumer<Map<String, String>> listener) {
        logger.debug("Configurando listener de mudança de filtro para gridId: {}", gridId);
        this.filterChangeListener = listener;
        notifyFilterChange();
    }

    public void updateItems(List<T> newItems) {
        logger.info("Atualizando itens no gridId: {}. Novos itens: {}", gridId, newItems != null ? newItems.size() : 0);
        this.items = new ArrayList<>(newItems != null ? newItems : new ArrayList<>());
        grid.setItems(this.items);
        clearAllFilters();
        if (aggregationUtil != null) {
            logger.debug("Atualizando itens no GridAggregationUtil para gridId: {}", gridId);
            aggregationUtil.updateItems(this.items);
        }
        if (columnConfigs != null) {
            logger.debug("Recarregando filtros com base nos novos itens");
            adicionarFiltrosNoCabecalho(columnConfigs);
        }
        logger.debug("Itens atualizados com sucesso, total: {}", this.items.size());
    }

    public void clearAllFilters() {
        logger.info("Limpando todos os filtros para gridId: {}", gridId);
        activeFilters.clear();
        grid.setItems(items);
        filtersChanged = true;
        notifyFilterChange();
        updateFilterRowHighlight();
        logger.debug("Filtros limpos com sucesso");
    }

    @SuppressWarnings("unchecked")
    public void adicionarFiltrosNoCabecalho(List<ColumnConfig<T>> columnConfigs) {
        logger.info("Adicionando filtros no cabeçalho para gridId: {}. Colunas fornecidas: {}", gridId, columnConfigs.size());
        this.columnConfigs = new ArrayList<>(columnConfigs);
        this.aggregationUtil = new GridAggregationUtil<>(this.items, this.columnConfigs);
        logger.debug("Itens disponíveis: {}", items.size());
        logger.debug("Colunas fornecidas: {}", columnConfigs.stream().map(cfg -> cfg.getHeader()).collect(Collectors.toList()));
        if (items.isEmpty()) {
            logger.warn("Lista de itens vazia. Filtros não serão configurados até que os itens sejam atualizados.");
            return;
        }

        String ordemColunas = carregarOrdemColunas();
        if (ordemColunas != null && !ordemColunas.isEmpty()) {
            List<String> orderedKeys = Arrays.asList(ordemColunas.split("-"));
            List<Grid.Column<T>> columns = grid.getColumns();
            List<Grid.Column<T>> reorderedColumns = orderedKeys.stream()
                    .map(key -> columns.stream().filter(col -> key.equals(col.getKey())).findFirst().orElse(null))
                    .filter(col -> col != null)
                    .collect(Collectors.toList());
            columns.stream()
                    .filter(col -> !reorderedColumns.contains(col))
                    .forEach(reorderedColumns::add);
            grid.setColumnOrder(reorderedColumns);
            logger.debug("Ordem das colunas aplicada: {}", ordemColunas);
        } else {
            List<Grid.Column<T>> columns = grid.getColumns();
            IntStream.range(0, columns.size()).forEach(i -> {
                Grid.Column<T> column = columns.get(i);
                String columnKey = column.getKey();
                if (columnKey != null) {
                    ColumnConfigUsuario config = new ColumnConfigUsuario();
                    config.setClassName(gridId);
                    String fieldName = columnConfigs.stream()
                        .filter(cfg -> cfg.column.getKey().equals(columnKey))
                        .findFirst()
                        .map(cfg -> cfg.getGridColumnConfig().getField())
                        .orElse(columnKey);
                    config.setFieldName(fieldName);
                    config.setUsuario(usuarioId);
                    config.setOrdenacaoGrid(i + 1);
                    saveColumnConfig(config);
                }
            });
            logger.debug("Nenhuma ordem de colunas encontrada, salvando ordem inicial");
        }

        initialColumnOrder = grid.getColumns().stream()
                .map(Grid.Column::getKey)
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
        logger.debug("Ordem inicial das colunas: {}", initialColumnOrder);

        carregarSortConfig();

        List<String> currentColumnKeys = columnConfigs.stream()
                .map(config -> config.column.getKey())
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
        logger.debug("Chaves das colunas: {}", currentColumnKeys);

        activeFilters.keySet().removeIf(columnKey -> {
            if (!currentColumnKeys.contains(columnKey)) {
                logger.warn("Removendo filtro ativo para coluna desconhecida {} em gridId: {}", columnKey, gridId);
                return true;
            }
            return false;
        });

        Button configButton = new Button(new Icon(VaadinIcon.COG));
        configButton.getElement().setAttribute("title", "Configurar colunas");
        configButton.addClickListener(event -> {
            logger.debug("Botão de configuração de colunas clicado para gridId: {}", gridId);
            abrirDialogoConfiguracaoColunas(columnConfigs);
        });

        Button saveOrderButton = new Button("Salvar Ordenação", event -> {
            logger.debug("Botão 'Salvar Ordenação' clicado para gridId: {}", gridId);
            columnOrderChanged = true;
            saveChanges();
        });

        Button agruparButton = aggregationUtil.createAggregationButton();

        HorizontalLayout configLayout = new HorizontalLayout(configButton, saveOrderButton, agruparButton);
        configLayout.setDefaultVerticalComponentAlignment(VerticalLayout.Alignment.CENTER);
        configLayout.getStyle().set("flex-shrink", "0");

        HorizontalLayout combinedLayout = new HorizontalLayout(configLayout);
        combinedLayout.setDefaultVerticalComponentAlignment(VerticalLayout.Alignment.CENTER);
        combinedLayout.setWidthFull();
        combinedLayout.getStyle()
                .set("flex-wrap", "nowrap")
                .set("overflow", "visible")
                .set("position", "sticky")
                .set("top", "0")
                .set("z-index", "100")
                .set("background-color", "var(--lumo-base-color)")
                .set("padding", "var(--lumo-space-s)")
                .set("box-shadow", "0 2px 4px rgba(0,0,0,0.1)");
        combinedLayout.addClassName("grid-filter-header-cell");

        HeaderRow configRow = grid.prependHeaderRow();
        configRow.getCells().forEach(cell -> cell.setText(""));
        configRow.join(configRow.getCells().toArray(new HeaderRow.HeaderCell[0])).setComponent(combinedLayout);

        HeaderRow filterRow = grid.appendHeaderRow();

        Map<String, String> savedFilters = carregarFiltros();
        logger.debug("Filtros salvos carregados para gridId {}: {}", gridId, savedFilters);

        int processedColumns = 0;
        for (ColumnConfig<T> config : columnConfigs) {
            Grid.Column<T> column = config.column;
            String columnKey = column.getKey();
            if (columnKey == null) {
                logger.warn("Coluna sem chave definida, ignorando para evitar erro.");
                continue;
            }

            if (!column.isVisible()) {
                logger.debug("Coluna {} está oculta, pulando configuração de filtro", columnKey);
                continue;
            }

            column.setResizable(true);
            column.setAutoWidth(false);
            column.setSortable(true);

            GridColumnConfig gridColumnConfig = gridColumnConfigService.getColumnConfig(gridId, usuarioId, columnKey);
            if (gridColumnConfig == null) {
                gridColumnConfig = config.getGridColumnConfig();
            }
            if (gridColumnConfig != null) {
                logger.debug("Coluna {}: largura definida: {}", columnKey, gridColumnConfig.getWidth());
                logger.debug("Coluna {}: dropdownValueMap: {}", columnKey, gridColumnConfig.getDropdownValueMap());
            }

            if (gridColumnConfig != null && gridColumnConfig.getDropdownValueMap() != null && !gridColumnConfig.getDropdownValueMap().isEmpty()) {
                Map<String, String> valueMap = gridColumnConfig.getDropdownValueMap();
                grid.removeColumn(column);
                column = grid.addColumn(item -> {
                    Object rawValue = config.getValueExtractor().apply(item);
                    return rawValue != null ? valueMap.getOrDefault(rawValue.toString(), rawValue.toString()) : "";
                });
                column.setKey(columnKey);
                column.setResizable(true);
                column.setAutoWidth(false);
                column.setSortable(true);
                column.setHeader(config.getHeader());
                config.setColumn(column);
            }

            final String finalColumnKey = columnKey;

            HorizontalLayout headerLayout = new HorizontalLayout();
            headerLayout.setDefaultVerticalComponentAlignment(VerticalLayout.Alignment.CENTER);
            headerLayout.setWidth(gridColumnConfig != null ? gridColumnConfig.getWidth() : "120px");
            headerLayout.getStyle()
                    .set("display", "flex")
                    .set("justify-content", "space-between")
                    .set("align-items", "center")
                    .set("padding", "0 8px")
                    .set("margin", "0")
                    .set("box-sizing", "border-box")
                    .set("overflow", "hidden");

if (gridColumnConfig != null) {
    StringBuilder tooltip = new StringBuilder("Configurações da Coluna:\n");
    tooltip.append("Field: ").append(gridColumnConfig.getField()).append("\n");
    tooltip.append("Header: ").append(gridColumnConfig.getHeader()).append("\n");
    tooltip.append("Type: ").append(gridColumnConfig.getType()).append("\n");
    tooltip.append("Width: ").append(gridColumnConfig.getWidth()).append("\n");
    tooltip.append("Style: ").append(gridColumnConfig.getStyle()).append("\n");
    tooltip.append("Filter Type: ").append(gridColumnConfig.getFilterType()).append("\n");
    tooltip.append("Visible: ").append(gridColumnConfig.isVisible());

    // Verifica se a instância é da view e faz cast manualmente
    if (gridColumnConfig instanceof VwColumnConfigEntity) {
        VwColumnConfigEntity vw = (VwColumnConfigEntity) gridColumnConfig;
        tooltip.append("\nAlias: ").append(vw.getAlias());
        tooltip.append("\nUsuário: ").append(vw.getUsuario());
    }

    headerLayout.getElement().setAttribute("title", tooltip.toString());
}

            Span headerSpan = new Span(config.header);
            headerSpan.getStyle()
                    .set("flex-grow", "1")
                    .set("overflow", "hidden")
                    .set("text-overflow", "ellipsis")
                    .set("white-space", "nowrap");
            headerLayout.add(headerSpan);
            column.setHeader(headerLayout);

            final MultiSelectComboBox<String> multiSelectComboBox = new MultiSelectComboBox<>();
            multiSelectComboBox.setClearButtonVisible(true);
            multiSelectComboBox.setPlaceholder("Selecionar...");
            multiSelectComboBox.getStyle().set("font-size", "12px");

            Map<String, Long> contagemPorValor = items.stream()
                    .map(item -> {
                        Object value = config.valueExtractor.apply(item);
                        logger.debug("Valor extraído para coluna {}: {}", finalColumnKey, value);
                        return value != null ? String.valueOf(value) : "N/A";
                    })
                    .collect(Collectors.groupingBy(v -> v, Collectors.counting()));

            List<String> valoresUnicos = contagemPorValor.entrySet().stream()
                    .sorted(Map.Entry.<String, Long>comparingByValue(Comparator.reverseOrder())
                            .thenComparing(Map.Entry.comparingByKey()))
                    .map(Map.Entry::getKey)
                    .collect(Collectors.toList());
            logger.debug("Valores únicos para coluna {}: {}", finalColumnKey, valoresUnicos);

            if (gridColumnConfig != null && gridColumnConfig.getDropdownValueMap() != null && !gridColumnConfig.getDropdownValueMap().isEmpty()) {
                Map<String, String> valueMap = gridColumnConfig.getDropdownValueMap();
                valoresUnicos = valoresUnicos.stream()
                        .map(rawValue -> valueMap.getOrDefault(rawValue, rawValue))
                        .distinct()
                        .collect(Collectors.toList());
                logger.debug("Valores exibidos ajustados para filtro da coluna {}: {}", finalColumnKey, valoresUnicos);
            }

            if (valoresUnicos.isEmpty()) {
                logger.warn("Nenhum valor único encontrado para coluna {}. Filtro não será configurado.", finalColumnKey);
                continue;
            }

            multiSelectComboBox.setItems(valoresUnicos);
            multiSelectComboBox.setRenderer(new ComponentRenderer<>(item -> {
                String texto = item + " (" + contagemPorValor.getOrDefault(item, 0L) + ")";
                return new Span(texto);
            }));

            int maxLength = valoresUnicos.stream()
                    .mapToInt(item -> (item + " (" + contagemPorValor.get(item) + ")").length())
                    .max()
                    .orElse(10);
            int widthPx = Math.min(Math.max(maxLength * 8, 100), 200);
            multiSelectComboBox.setWidth(widthPx + "px");

            multiSelectComboBox.addValueChangeListener(event -> {
                logger.debug("Filtro alterado para coluna {} em gridId: {}. Valores selecionados: {}", finalColumnKey, gridId, event.getValue());
                Set<String> selectedValues = event.getValue();
                if (selectedValues == null || selectedValues.isEmpty()) {
                    activeFilters.remove(finalColumnKey);
                } else {
                    activeFilters.put(finalColumnKey, selectedValues);
                }
                applyFilters();
                updateFilterRowHighlight();
				saveChanges(); // <-- Adicionado aqui para salvar o filtro no banco
            });

            if (column.isVisible()) {
                HeaderRow.HeaderCell filterCell = filterRow.getCell(column);
                filterCell.setComponent(multiSelectComboBox);
                if (activeFilters.containsKey(finalColumnKey) && !activeFilters.get(finalColumnKey).isEmpty()) {
                    multiSelectComboBox.getStyle()
                            .set("background-color", "var(--lumo-primary-color-10pct)")
                            .set("border", "1px solid var(--lumo-primary-color)");
                }
            }

            if (savedFilters != null && savedFilters.containsKey(finalColumnKey)) {
                String savedFilterValue = savedFilters.get(finalColumnKey);
                logger.info("Aplicando filtro salvo para coluna {} em gridId: {}. Valores: {}", finalColumnKey, gridId, savedFilterValue);
                Set<String> selectedValues = new HashSet<>(Arrays.asList(savedFilterValue.split("-")));
                if (selectedValues.stream().allMatch(valoresUnicos::contains)) {
                    activeFilters.put(finalColumnKey, selectedValues);
                    multiSelectComboBox.setValue(selectedValues);
                    applyFilters();
                    updateFilterRowHighlight();
                } else {
                    logger.warn("Valores de filtro salvos inválidos para coluna {} em gridId: {}. Limpando filtro.", finalColumnKey, gridId);
                    activeFilters.remove(finalColumnKey);
                }
            }

            processedColumns++;
        }

        logger.info("Total de colunas processadas para gridId {}: {}", gridId, processedColumns);
        List<String> visibleColumns = grid.getColumns().stream()
                .filter(Grid.Column::isVisible)
                .map(Grid.Column::getKey)
                .collect(Collectors.toList());
        logger.info("Colunas visíveis após configuração para gridId {}: {}", gridId, visibleColumns);
        logger.debug("Filtros adicionados ao cabeçalho com sucesso para gridId: {}", gridId);
        grid.getDataProvider().refreshAll();
    }

    private void applyFilters() {
        List<T> filteredItems = items.stream()
                .filter(item -> {
                    for (Map.Entry<String, Set<String>> filter : activeFilters.entrySet()) {
                        String filterKey = filter.getKey();
                        Set<String> filterValues = filter.getValue();
                        if (filterValues == null || filterValues.isEmpty()) {
                            continue;
                        }
                        ColumnConfig<T> cfg = columnConfigs.stream()
                                .filter(c -> c.column.getKey().equals(filterKey))
                                .findFirst()
                                .orElse(null);
                        if (cfg == null) continue;
                        Object value = cfg.valueExtractor.apply(item);
                        String stringValue = value != null ? String.valueOf(value) : "N/A";
                        if (!filterValues.contains(stringValue)) {
                            return false;
                        }
                    }
                    return true;
                })
                .collect(Collectors.toList());

        logger.info("Itens após aplicar filtros para gridId {}: {}", gridId, filteredItems.size());
        if (filteredItems.isEmpty() && !activeFilters.isEmpty()) {
            logger.warn("Nenhum item corresponde aos filtros aplicados para gridId {}. Filtros: {}", gridId, activeFilters);
        }

        grid.setItems(filteredItems);
        filtersChanged = true;
        notifyFilterChange();
    }

    private String mapTextAlignToJustifyContent(String textAlign) {
        switch (textAlign.toLowerCase()) {
            case "left":
                return "flex-start";
            case "right":
                return "flex-end";
            case "center":
                return "center";
            default:
                return "flex-start";
        }
    }

    private void updateFilterRowHighlight() {
        logger.debug("Atualizando destaque na linha de filtro para gridId: {}", gridId);
        HeaderRow filterRow = grid.getHeaderRows().stream()
                .filter(row -> row.getCells().stream().anyMatch(cell -> cell.getComponent() instanceof MultiSelectComboBox))
                .findFirst()
                .orElse(null);

        if (filterRow == null) {
            logger.warn("Linha de filtro não encontrada para gridId: {}", gridId);
            return;
        }

        for (ColumnConfig<T> config : columnConfigs) {
            Grid.Column<T> column = config.column;
            String columnKey = column.getKey();
            HeaderRow.HeaderCell filterCell = filterRow.getCell(column);
            if (filterCell != null && filterCell.getComponent() != null) {
                Component component = filterCell.getComponent();
                if (component instanceof MultiSelectComboBox) {
                    @SuppressWarnings("unchecked")
                    MultiSelectComboBox<String> comboBox = (MultiSelectComboBox<String>) component;
                    boolean hasFilter = activeFilters.containsKey(columnKey) && activeFilters.get(columnKey) != null && !activeFilters.get(columnKey).isEmpty();
                    if (hasFilter) {
                        comboBox.getStyle()
                                .set("background-color", "var(--lumo-primary-color-10pct)")
                                .set("border", "1px solid var(--lumo-primary-color)");
                    } else {
                        comboBox.getStyle()
                                .remove("background-color")
                                .remove("border");
                    }
                }
            }
        }
    }

    private void abrirDialogoConfiguracaoColunas(List<ColumnConfig<T>> columnConfigs) {
        logger.info("Abrindo diálogo de configuração de colunas para gridId: {}", gridId);
        Dialog dialog = new Dialog();
        dialog.setModal(true);
        dialog.setWidth("300px");

        VerticalLayout layout = new VerticalLayout();
        layout.setPadding(false);
        layout.setSpacing(true);

        List<Checkbox> columnCheckboxes = new ArrayList<>();
        for (ColumnConfig<T> config : columnConfigs) {
            Grid.Column<T> column = config.column;
            Checkbox checkbox = new Checkbox(config.header, column.isVisible());
            checkbox.addValueChangeListener(event -> {
                logger.debug("Visibilidade da coluna {} alterada para {} em gridId: {}", config.header, event.getValue(), gridId);
                column.setVisible(event.getValue());
                visibilityChanged = true;
                grid.getDataProvider().refreshAll();
                saveChanges();
            });
            columnCheckboxes.add(checkbox);
            layout.add(checkbox);
        }

        Button selectAllButton = new Button("Selecionar Todos", event -> {
            logger.debug("Botão 'Selecionar Todos' clicado para gridId: {}", gridId);
            for (Checkbox checkbox : columnCheckboxes) {
                checkbox.setValue(true);
                Grid.Column<T> column = columnConfigs.get(columnCheckboxes.indexOf(checkbox)).column;
                column.setVisible(true);
            }
            visibilityChanged = true;
            grid.getDataProvider().refreshAll();
            saveChanges();
        });
        layout.add(selectAllButton);

        Button fecharButton = new Button("Fechar", event -> dialog.close());
        layout.add(fecharButton);

        dialog.add(layout);
        dialog.open();
    }

    private void notifyFilterChange() {
        logger.debug("Notificando mudança de filtros para gridId: {}", gridId);
        if (filterChangeListener != null) {
            Map<String, String> filterMap = activeFilters.entrySet().stream()
                    .filter(entry -> entry.getValue() != null && !entry.getValue().isEmpty())
                    .collect(Collectors.toMap(
                            Map.Entry::getKey,
                            entry -> String.join("-", entry.getValue())
                    ));
            filterChangeListener.accept(filterMap);
        }
    }

    public Component getLayout() {
        return layoutRaiz;
    }

    public void clearGrid() {
        logger.info("Limpando completamente o grid para gridId: {}", gridId);
        grid.getColumns().forEach(column -> grid.removeColumn(column));
        activeFilters.clear();
        items.clear();
        grid.setItems(new ArrayList<>());
        logger.debug("Grid limpo com sucesso");
    }

    public void addColumns(List<GridColumnConfig> configs) {
        logger.info("🧩 Adicionando {} colunas ao grid {}", configs.size(), gridId);
        Set<String> keysJaAdicionados = new HashSet<>();
        this.columnConfigs = new ArrayList<>();

        for (GridColumnConfig config : configs) {
            String field = config.getField();
            if (keysJaAdicionados.contains(field)) {
                logger.warn("🔁 Ignorando coluna duplicada: {}", field);
                continue;
            }
            keysJaAdicionados.add(field);

            Grid.Column<T> column = grid.addColumn(item -> {
                if (item instanceof RelatorioDinamicoResult) {
                    Object valor = ((RelatorioDinamicoResult) item).getValores().get(field);
                    return valor != null ? valor.toString() : "";
                }
                return "";
            });

            column.setKey(field);
            column.setHeader(config.getHeader() != null ? config.getHeader() : field);
            column.setSortable(true);
            column.setResizable(true);
            column.setAutoWidth(true);
            column.setVisible(config.isVisible());

            ColumnConfig<T> columnConfig = new ColumnConfig<>(
                column,
                config.getHeader() != null ? config.getHeader() : field,
                item -> {
                    if (item instanceof RelatorioDinamicoResult) {
                        return ((RelatorioDinamicoResult) item).getValores().get(field);
                    }
                    return null;
                },
                config
            );

            this.columnConfigs.add(columnConfig);
        }
    }

    public static String serializarFiltros(Map<String, List<String>> filtros) {
        return filtros.entrySet().stream()
            .map(entry -> entry.getKey() + "=" + String.join(",", entry.getValue()))
            .collect(Collectors.joining(";"));
    }

    public static class ColumnConfig<T> {
        private Grid.Column<T> column;
        private final String header;
        private final Function<T, Object> valueExtractor;
        private final GridColumnConfig gridColumnConfig;

        public ColumnConfig(Grid.Column<T> column, String header, Function<T, Object> valueExtractor, GridColumnConfig gridColumnConfig) {
            this.column = column;
            this.header = header;
            this.valueExtractor = valueExtractor;
            this.gridColumnConfig = gridColumnConfig;
        }

        public Grid.Column<T> getColumn() {
            return column;
        }

        public String getHeader() {
            return header;
        }

        public Function<T, Object> getValueExtractor() {
            return valueExtractor;
        }

        public GridColumnConfig getGridColumnConfig() {
            return gridColumnConfig;
        }

        public void setColumn(Grid.Column<T> column) {
            this.column = column;
        }

        public void setProperty(String property) {
            // Método necessário para compatibilidade com AbstractGridView
        }

        public void setVisible(boolean visible) {
            column.setVisible(visible);
        }
    }

    public static class GridColumnDto<T> {
        private Grid.Column<T> column;
        private Function<T, ?> valueExtractor;
        private GridColumnConfig gridColumnConfig;

        public GridColumnDto(Grid.Column<T> column, Function<T, ?> extractor, GridColumnConfig config) {
            this.column = column;
            this.valueExtractor = extractor;
            this.gridColumnConfig = config;
        }

        public Grid.Column<T> getColumn() {
            return column;
        }

        public void setColumn(Grid.Column<T> column) {
            this.column = column;
        }

        public Function<T, ?> getValueExtractor() {
            return valueExtractor;
        }

        public GridColumnConfig getGridColumnConfig() {
            return gridColumnConfig;
        }
    }
}