package com.exemplo;

import com.vaadin.flow.component.AttachEvent;
import com.vaadin.flow.component.DetachEvent;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.grid.ItemDoubleClickEvent;
import com.vaadin.flow.component.html.H1;
import com.vaadin.flow.component.html.Span;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.progressbar.ProgressBar;
import com.vaadin.flow.router.BeforeEnterEvent;
import com.vaadin.flow.router.BeforeEnterObserver;
import com.vaadin.flow.function.ValueProvider;
import com.vaadin.flow.component.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Supplier;

public abstract class AbstractGridView<T> extends VerticalLayout implements BeforeEnterObserver {

    private static final Logger logger = LoggerFactory.getLogger(AbstractGridView.class);

    protected final String title;
    protected final String gridId;
    protected final Supplier<List<T>> dataSupplier;
    protected Grid<T> grid;
    protected GridFilterUtil<T> gridUtil;
    protected List<T> items;
    protected List<GridFilterUtil.ColumnConfig<T>> columnConfigs;

    private VerticalLayout loadingOverlay;
    private ProgressBar loadingBar;
    private Span loadingMessage;

    @Autowired
    protected GridColumnConfigService gridColumnConfigService;

    @Autowired
    protected GridColumnConfigCadastroService gridColumnConfigCadastroService;

    @Autowired
    protected VisibilidadeColunaService visibilidadeColunaService;

    @Autowired
    private ApplicationContext applicationContext;

    private static final Map<Class<?>, Class<? extends GenericaCadastro<?>>> CADASTRO_CLASSES = new HashMap<>();

    static {
        CADASTRO_CLASSES.put(Cliente.class, ClienteCadastro.class);
        CADASTRO_CLASSES.put(Fornecedor.class, FornecedorCadastro.class);
        CADASTRO_CLASSES.put(Produto.class, ProdutoCadastro.class);
        CADASTRO_CLASSES.put(Marca.class, MarcaCadastro.class);
    }

    public AbstractGridView(String title, String gridId, Supplier<List<T>> dataSupplier) {
        logger.info("Construindo AbstractGridView: title={}, gridId={}", title, gridId);
        this.title = title;
        this.gridId = gridId;
        this.dataSupplier = dataSupplier;

        setSizeFull();
        setPadding(false);
        setMargin(false);
        setSpacing(false);
        addClassName("abstract-grid-view");
        getStyle().set("position", "relative");
        getStyle().set("display", "flex");
        getStyle().set("flex-direction", "column");

        H1 titleComponent = new H1(title);
        titleComponent.getStyle()
            .set("font-size", "24px")
            .set("margin", "10px 0 5px 0")
            .set("padding", "0");
        add(titleComponent);

        grid = new Grid<>((Class<T>) getEntityClass(), false);
        grid.getElement().getClassList().add("grid-container");
        grid.setHeight("100%");
        grid.setWidth("100%");

        grid.addItemDoubleClickListener(this::handleItemDoubleClick);

        initializeLoadingOverlay();
    }

    @SuppressWarnings("unchecked")
    private void handleItemDoubleClick(ItemDoubleClickEvent<T> event) {
        T item = event.getItem();
        if (item == null) {
            logger.warn("Item selecionado é nulo. Não é possível abrir o diálogo de edição.");
            return;
        }

        logger.info("Item selecionado para edição: {}", item);

        Class<T> entityClass = (Class<T>) getEntityClass();
        Class<? extends GenericaCadastro<?>> cadastroClass = CADASTRO_CLASSES.get(entityClass);

        if (cadastroClass == null) {
            logger.warn("Nenhuma classe de cadastro registrada para a entidade {}.", entityClass.getSimpleName());
            return;
        }

        try {
            Object repository = getRepository();
            if (repository == null) {
                logger.warn("Repositório não disponível para a entidade {}. Não será possível abrir o diálogo de edição.", entityClass.getSimpleName());
                return;
            }

            GenericaCadastro<T> cadastro = (GenericaCadastro<T>) applicationContext.getBean(cadastroClass, repository);
            cadastro.initialize(item, savedItem -> carregarDados());
            cadastro.open();
            logger.info("Diálogo de cadastro/edição aberto para a entidade: {}.", entityClass.getSimpleName());
        } catch (Exception e) {
            logger.error("Erro ao abrir diálogo de cadastro/edição para a entidade {}: {}", entityClass.getSimpleName(), e.getMessage(), e);
            if (e instanceof com.vaadin.flow.data.binder.BindingException) {
                logger.error("Detalhes do BindingException: {}", e.getCause() != null ? e.getCause().getMessage() : "Causa desconhecida");
            }
        }
    }

    protected abstract Object getRepository();

    protected void initializeLoadingOverlay() {
        loadingOverlay = new VerticalLayout();
        loadingOverlay.setSizeFull();
        loadingOverlay.setJustifyContentMode(FlexComponent.JustifyContentMode.CENTER);
        loadingOverlay.setAlignItems(FlexComponent.Alignment.CENTER);
        loadingOverlay.getStyle().set("background-color", "rgba(255, 255, 255, 0.7)");
        loadingOverlay.getStyle().set("position", "absolute");
        loadingOverlay.getStyle().set("top", "0");
        loadingOverlay.getStyle().set("left", "0");
        loadingOverlay.getStyle().set("z-index", "999");

        loadingBar = new ProgressBar();
        loadingBar.setIndeterminate(true);
        loadingMessage = new Span("Carregando...");
        loadingOverlay.add(loadingBar, loadingMessage);
        loadingOverlay.setVisible(false);
        add(loadingOverlay);
    }

    @Override
    protected void onAttach(AttachEvent attachEvent) {
        super.onAttach(attachEvent);
        logger.info("onAttach chamado para {} com gridId={}", title, gridId);
        if (gridColumnConfigService == null) {
            logger.error("gridColumnConfigService é nulo para {}. Verifique a configuração do Spring.", title);
            return;
        }
        showLoadingOverlay(true);
        logger.debug("Verificando UI para {}", title);
        getUI().ifPresentOrElse(ui -> {
            logger.debug("UI presente. Iniciando configuração do grid para {}", title);
            ui.access(() -> {
                try {
                    logger.debug("Chamando configureColumns para {}", title);
                    this.columnConfigs = configureColumns();
                    logger.info("ColumnConfigs gerados: {}", columnConfigs != null ? columnConfigs.size() : 0);
                    if (columnConfigs == null || columnConfigs.isEmpty()) {
                        logger.error("Nenhuma coluna configurada para {}. GridFilterUtil não será inicializado.", title);
                        return;
                    }
                    logger.debug("Inicializando GridFilterUtil para gridId={}", gridId);
                    gridUtil = new GridFilterUtil<>(gridId, grid, columnConfigs, getUsuarioId(), getCdEmpresaUsuario());
                    logger.info("GridFilterUtil inicializado com gridId={}, usuarioId={}, cdEmpresa={}", gridId, getUsuarioId(), getCdEmpresaUsuario());
                    Component filterLayout = gridUtil.getLayout();
                    if (filterLayout == null) {
                        logger.error("Layout do GridFilterUtil é nulo para {}.", title);
                    } else {
                        add(filterLayout);
                        logger.debug("Layout do GridFilterUtil adicionado à view.");
                    }
                    logger.debug("Chamando carregarDados para {}", title);
                    carregarDados();
                } catch (Exception e) {
                    logger.error("Erro ao configurar o grid para {}: {}", title, e.getMessage(), e);
                    e.printStackTrace();
                } finally {
                    showLoadingOverlay(false);
                    logger.debug("Configuração do grid concluída para {}.", title);
                }
            });
        }, () -> {
            logger.error("UI não presente para {}. Não é possível configurar o grid.", title);
            showLoadingOverlay(false);
        });
    }

    @Override
    protected void onDetach(DetachEvent detachEvent) {
        super.onDetach(detachEvent);
        logger.info("onDetach chamado para {} com gridId={}", title, gridId);
        grid.removeAllColumns();
        gridUtil = null;
        columnConfigs = null;
    }

    protected void carregarDados() {
        try {
            showLoadingOverlay(true);
            logger.debug("Carregando dados para {} com gridId={}", title, gridId);
            this.items = dataSupplier.get();
            logger.info("Itens carregados para {}: {}", title, items != null ? items.size() : 0);
            if (items != null) {
                items.forEach(item -> logger.debug("Item: {}", item));
            } else {
                logger.warn("Itens nulos para {}.", title);
            }
            grid.setItems(items);
            if (gridUtil != null) {
                gridUtil.updateItems(items);
            }
        } catch (Exception e) {
            logger.error("Erro ao carregar dados para {}: {}", title, e.getMessage(), e);
            e.printStackTrace();
        } finally {
            showLoadingOverlay(false);
            logger.debug("Carregamento de dados concluído para {}.", title);
        }
    }

    protected void showLoadingOverlay(boolean visible) {
        loadingOverlay.setVisible(visible);
    }

    protected String getUsuarioId() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String usuarioId = auth != null && auth.getName() != null ? auth.getName() : "anonymousUser";
        logger.debug("UsuarioId obtido: {}", usuarioId);
        return usuarioId;
    }

    protected Integer getCdEmpresaUsuario() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null && auth.getPrincipal() instanceof CustomUserDetails) {
            Short cd = ((CustomUserDetails) auth.getPrincipal()).getCdEmpresa();
            Integer cdEmpresa = cd != null ? cd.intValue() : null;
            logger.debug("CdEmpresa obtido: {}", cdEmpresa);
            return cdEmpresa;
        }
        logger.warn("Principal não é CustomUserDetails ou autenticação nula. Retornando null para cdEmpresa. Principal: {}", 
            auth != null && auth.getPrincipal() != null ? auth.getPrincipal().getClass().getName() : "null");
        return null;
    }

    public List<GridFilterUtil.ColumnConfig<T>> configureColumns() {
        logger.info("Configurando colunas para {} com gridId={}", title, gridId);
        List<GridFilterUtil.ColumnConfig<T>> configs = new ArrayList<>();
        List<GridColumnConfig> configList;
        try {
            logger.debug("Chamando gridColumnConfigService.listar()");
            configList = gridColumnConfigService.listar();
            logger.info("Total de configurações carregadas: {}", configList != null ? configList.size() : 0);
        } catch (Exception e) {
            logger.error("Erro ao carregar configurações de column_config: {}", e.getMessage(), e);
            e.printStackTrace();
            return configs;
        }

        if (configList == null || configList.isEmpty()) {
            logger.warn("Nenhuma configuração encontrada em column_config para {}.", title);
            return configs;
        }

        configList.forEach(c -> logger.debug("Configuração: field={}, header={}, visible={}", 
            c.getField(), c.getHeader(), c.isVisible()));

        List<String> validFields = new ArrayList<>();
        if (getEntityClass() == Marca.class) {
            validFields.addAll(Arrays.asList("cdMarca", "dsMarca", "comissao", "prDescontoVendedor", 
                "prDescontoGerente", "alteraPreco", "situacao", "gtinUnico"));
        } else if (getEntityClass() == Cliente.class) {
            validFields.addAll(Arrays.asList("cdEmpresa", "cdCliente", "nmCliente", "tipo", 
                "endereco", "bairro", "fone", "celular", "cpf"));
        } else if (getEntityClass() == Fornecedor.class) {
            validFields.addAll(Arrays.asList("cdFornecedor", "nmFornecedor", "nmFantasia", "nmRepresentante", 
                "cdCidade", "cep", "endereco", "bairro", "fone", "fax", "email", "tipo", "contatoFinanceiro", 
                "foneFinanceiro", "faxFinanceiro", "celularFinanceiro", "ramalFinanceiro", "contatoComercial", 
                "foneComercial", "faxComercial", "celularComercial", "ramalComercial", "representante", 
                "foneRepresentante", "faxRepresentante", "celularRepresentante", "ramalRepresentante", 
                "contaCorrente", "cdBanco", "agencia", "cgc", "inscricaoEstadual", "freteNoIpi", "obs", 
                "contaContabil", "diasEntrega", "alteraPreco", "situacao", "cooperado", "tpPessoa", 
                "nroEndereco", "emailFinanceiro", "emailComercial", "emailRepresentante", "emailCotacao", 
                "celular", "infNegociacao", "obsComoHistoricoContabil", "tipoContribuinte", "cdPais", 
                "emailNfe", "contatoEmailNfe"));
        } else if (getEntityClass() == Produto.class) {
            validFields.addAll(Arrays.asList("cdProduto", "nrDigito", "dsProduto", "dsAbreviacao", 
                "cdSubgrupo", "cdGrupo", "cdMarca", "cdCor", "voltagem", "cdFornecedor", "situacao", 
                "reducaoIcms", "icms", "ipi", "classificacaoFiscal", "origemSituacaoTributaria", 
                "situacaoTributaria", "vlContabil", "vlCompra", "vlVenda", "vlCusto", "comissao", 
                "lucro", "estoqueMinimo", "estoqueMaximo", "cdUnidade", "vlCustoMedio", 
                "prDescontoVendedor", "prDescontoGerente", "saldoNegativo", "cdBarra", "nrComponentes", 
                "referencia", "dtCadastro", "alteraPreco", "prateleira", "peso", "cubagem", "cdFabrica", 
                "capacidade", "combustivel", "renavam", "chassi", "motor", "potencia", "anoFabricacao", 
                "anoModelo", "cilindrada", "cdPerfil", "cdAcabamento", "gravura", "sombra", "ncm", 
                "vlIpi", "vlSubstituicao", "cdMontadora", "tamanho", "prProteina", "tpProduto", 
                "dsModelo", "comissao2", "comissao3", "numero", "capacidadeVolumetrica", "cdProdutoDnf", 
                "kgMilheiro", "nmUsuario", "diasEntrega", "classificacao", "qtPecasUmVolume", 
                "obsOrcamento", "obsNf", "nrMesesGarantia", "prDescontoGerente2", "prDescontoVendedor2", 
                "pesoBruto", "caminhoFoto", "vlDec", "montadora", "ipiVenda", "anoFabricabao", 
                "prioridade", "pisCofins", "dtVencimentoNota", "cdReceita", "cdDespesa", "cdTipo", 
                "vlMaoObra", "modalidadeBcIcms", "modalidadeBcIcmsSt", "enquadramentoIpi", 
                "situacaoTributariaIpi", "situacaoTributariaPis", "prAliquotaPis", 
                "situacaoTributariaCofins", "prAliquotaCofins", "prAdicionadoSubstituicao", 
                "prSubstituicao", "cdTipoEntrada", "dsAplicacao", "conversao", "prIcmsCompra", 
                "somenteCotacaoCompra", "cdGrupoServicoClassificacao", "cdServicoClassificacao", 
                "cdTributacaoIss", "cdTipoItemSped", "cdExcecaoNcmSped", "cdGeneroSped", 
                "prReducaoIcmsSt", "prFatorReducaoSnSt", "indiceAjusteMva", "movtoSped", 
                "prioridadeOrdem", "alteraDescricaoCompra", "liberaLocacao", "criptografia", "cdAnp", 
                "largura", "profundidade", "altura", "sazonal", "nrEspecificacaoIcms", 
                "nrEspecificacaoPisCofins", "nrEspecificacaoIpi", "situacaoTributariaCompra", 
                "prIcmsAjusteMva", "prReducaoIcmsCompra", "nrEspecificacaoCompras", "nmUsuarioAlteracao", 
                "dtAlteracao", "cest", "prDescontoDemander", "fci", "cdFabricante", 
                "pisCofinsMonofasico", "vlBcIcmsStRet", "prStRet", "vlIcmsRet", "vlIcmsStRet", 
                "cdSimilaridade", "verificadoAutokm", "dsFabricanteAutokm", "qtFracionada", 
                "cdUnidadeFracionada", "cdAliquota", "cdProdutoAgrupador", "obsLojaVirtual", 
                "icmsStRetidoAnteriormente"));
        } else {
            logger.warn("Classe de entidade desconhecida: {}. Nenhuma coluna será configurada.", getEntityClass().getSimpleName());
            return configs;
        }

        grid.removeAllColumns();
        logger.debug("Colunas existentes removidas do grid para evitar duplicatas.");

        Set<String> addedKeys = new HashSet<>();
        int columnIndex = 0;

        for (GridColumnConfig c : configList) {
            if (!c.isVisible()) {
                logger.debug("Coluna {} ignorada por não ser visível", c.getField());
                continue;
            }

            String field = c.getField();
            if (!validFields.contains(field)) {
                logger.debug("Coluna {} ignorada por não ser válida para {}", field, getEntityClass().getSimpleName());
                continue;
            }

            String alias = c.getAlias();
            String columnName = (alias != null && !alias.isEmpty()) ? alias : field;

            String uniqueKey = field + "_" + columnIndex;
            columnIndex++;

            if (addedKeys.contains(field)) {
                logger.warn("Chave duplicada detectada para coluna {}. Usando chave única: {}", field, uniqueKey);
            } else {
                addedKeys.add(field);
            }

            try {
                ValueProvider<T, Object> extractor;
                if (getEntityClass() == Cliente.class && field.equals("cdEmpresa")) {
                    extractor = new ValueProvider<T, Object>() {
                        @Override
                        public Object apply(T item) {
                            return ((Cliente) item).getId().getCdEmpresa();
                        }
                    };
                } else if (getEntityClass() == Cliente.class && field.equals("cdCliente")) {
                    extractor = new ValueProvider<T, Object>() {
                        @Override
                        public Object apply(T item) {
                            return ((Cliente) item).getId().getCdCliente();
                        }
                    };
                } else {
                    java.lang.reflect.Method method = getEntityClass().getMethod("get" + capitalize(field));
                    extractor = item -> {
                        try {
                            return method.invoke(item);
                        } catch (Exception e) {
                            logger.error("Erro ao extrair valor do campo '{}': {}", field, e.getMessage());
                            return null;
                        }
                    };
                }

                Grid.Column<T> column = grid.addColumn(extractor)
                                           .setHeader(columnName)
                                           .setKey(uniqueKey);
                GridFilterUtil.ColumnConfig<T> config = new GridFilterUtil.ColumnConfig<>(column, columnName, extractor::apply, c);
                configs.add(config);
                logger.debug("Coluna configurada: field={}, header={}, key={}", field, columnName, uniqueKey);
            } catch (NoSuchMethodException e) {
                logger.warn("Método get{} não encontrado em {}. Ignorando coluna.", 
                    capitalize(field), getEntityClass().getSimpleName());
            } catch (Exception e) {
                logger.error("Erro ao configurar coluna {}: {}", field, e.getMessage(), e);
                e.printStackTrace();
            }
        }

        logger.info("Total de colunas configuradas: {}", configs.size());
        return configs;
    }

    private String capitalize(String field) {
        if (field == null || field.isEmpty()) return field;
        return field.substring(0, 1).toUpperCase() + field.substring(1);
    }

    public abstract Class<T> getEntityClass();

    @Override
    public void beforeEnter(BeforeEnterEvent event) {
        logger.debug("beforeEnter chamado para {} com gridId={}", title, gridId);
    }

    public void addFilters(Component filtrosLayout) {
        logger.debug("Adicionando layout de filtros para {}", title);
        add(filtrosLayout);
    }

    public void updateData(List<T> novaLista) {
        logger.info("Atualizando dados para {}: {}", title, novaLista != null ? novaLista.size() : 0);
        this.items = new ArrayList<>(novaLista != null ? novaLista : new ArrayList<>()); // Garantir que seja mutável
        if (gridUtil != null) {
            gridUtil.updateItems(this.items);
        } else {
            grid.setItems(this.items);
        }
    }
}