package com.exemplo;

import java.util.Map;

public class GridColumnConfig {

    private Integer id;
    private String className;
    private String field;
    private String header;
    private String type;
    private boolean visible;
    private Integer numericWidth;
    private String width;
    private String style;
    private String filterType;  // Novo campo para o tipo de filtro
    private String dropdownValues;
    private Map<String, String> dropdownValueMap;
    private String alias;

    // Getters e Setters
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public String getField() {
        return field;
    }

    public void setField(String field) {
        this.field = field;
    }

    public String getHeader() {
        return header;
    }

    public void setHeader(String header) {
        this.header = header;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public boolean isVisible() {
        return visible;
    }

    public void setVisible(boolean visible) {
        this.visible = visible;
    }

    public Integer getNumericWidth() {
        return numericWidth;
    }

    public void setNumericWidth(Integer numericWidth) {
        this.numericWidth = numericWidth;
    }

    public String getWidth() {
        return width;
    }

    public void setWidth(String width) {
        this.width = width;
    }

    public String getStyle() {
        return style;
    }

    public void setStyle(String style) {
        this.style = style;
    }

    public String getFilterType() {
        return filterType;
    }

    public void setFilterType(String filterType) {
        this.filterType = filterType;
    }

    public String getDropdownValues() {
        return dropdownValues;
    }

    public void setDropdownValues(String dropdownValues) {
        this.dropdownValues = dropdownValues;
    }

    public Map<String, String> getDropdownValueMap() {
        return dropdownValueMap;
    }

    public void setDropdownValueMap(Map<String, String> dropdownValueMap) {
        this.dropdownValueMap = dropdownValueMap;
    }

    public String getAlias() {
        return alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }
}