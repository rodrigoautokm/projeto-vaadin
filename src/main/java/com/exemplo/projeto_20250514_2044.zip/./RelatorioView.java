package com.exemplo;

import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.html.H1;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.router.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.*;

@Route(value = "rel_vendas", layout = MainLayout.class)
@RouteAlias(value = "rel_dre", layout = MainLayout.class)
@RouteAlias(value = "rel_listagem", layout = MainLayout.class)
@RouteAlias(value = "rel_ordens_servico", layout = MainLayout.class)
@PageTitle("Relatório Dinâmico")
public class RelatorioView extends AbstractGridView<RelatorioDinamicoResult> implements BeforeEnterObserver {

    private static final Logger logger = LoggerFactory.getLogger(RelatorioView.class);

    private final RelatorioService relatorioService;
    private final ParametroRelatorioService parametroService;
    private final GridColumnConfigRelatorioService gridColumnConfigRelatorioService;
    private final SystemParameterService systemParameterService;

    private String procedureName;
    private String tituloPagina;
    private Map<String, Object> parametrosSelecionados;
    private HorizontalLayout topBar;

    @Autowired
    public RelatorioView(RelatorioService relatorioService,
                         ParametroRelatorioService parametroService,
                         GridColumnConfigRelatorioService gridColumnConfigRelatorioService,
                         SystemParameterService systemParameterService) {
        super("Relatório", "relatorio", () -> List.of());
        this.relatorioService = relatorioService;
        this.parametroService = parametroService;
        this.gridColumnConfigRelatorioService = gridColumnConfigRelatorioService;
        this.systemParameterService = systemParameterService;

        H1 titulo = new H1("Relatório");
        Button parametrosBtn = new Button("Parâmetros", VaadinIcon.COG.create(), e -> abrirDialogParametros());
        topBar = new HorizontalLayout(titulo, parametrosBtn);
        topBar.setWidthFull();
        topBar.setSpacing(true);
        add(topBar);
    }

    @Override
    public void beforeEnter(BeforeEnterEvent event) {
        String path = event.getLocation().getPath();
        switch (path) {
            case "rel_vendas":
                procedureName = "pr_rel_vendas_r04";
                tituloPagina = "Relatório de Vendas";
                break;
            case "rel_dre":
                procedureName = "pr_rel_demonstrativo_resultado_arvore";
                tituloPagina = "Relatório DRE";
                break;
            case "rel_listagem":
                procedureName = "pr_listagem_pedidos";
                tituloPagina = "Listagem de Pedidos";
                break;
            case "rel_ordens_servico":
                procedureName = "pr_rel_ordens_servico_periodo";
                tituloPagina = "Relatório Ordem de Serviço";
                break;
            default:
                Notification.show("Rota inválida.");
                return;
        }

        topBar.removeAll();
        H1 titulo = new H1(tituloPagina);
        Button parametrosBtn = new Button("Parâmetros", VaadinIcon.COG.create(), e -> abrirDialogParametros());
        topBar.add(titulo, parametrosBtn);
        topBar.setWidthFull();
        topBar.setSpacing(true);
    }

    private void abrirDialogParametros() {
        // Carregar os parâmetros da tabela config_parametro_procedure
        List<ParametroRelatorio> parametros = parametroService.getParametros(procedureName);
        if (parametros == null || parametros.isEmpty()) {
            logger.warn("Tabela config_parametro_procedure vazia para {}. Configure os parâmetros manualmente.", procedureName);
            Notification.show("Nenhum parâmetro configurado para esta procedure. Configure a tabela config_parametro_procedure.", 5000, Notification.Position.MIDDLE);
            return;
        }

        logger.info("Parâmetros carregados: {}", parametros.size());
        for (ParametroRelatorio p : parametros) {
            logger.debug("Parametro: field={}, tipo={}, header={}", p.getField(), p.getTipo(), p.getHeader());
        }

        // Verificar se a tabela config_procedure_campos_retorno tem colunas configuradas
        List<GridColumnConfig> configs = gridColumnConfigRelatorioService.getColumnConfigs(procedureName);
        boolean camposRetornoConfigurados = configs != null && !configs.isEmpty();
        if (!camposRetornoConfigurados) {
            logger.warn("Tabela config_procedure_campos_retorno vazia para {}. Configure as colunas manualmente.", procedureName);
            Notification.show("Nenhuma coluna configurada para esta procedure. Configure a tabela config_procedure_campos_retorno.", 5000, Notification.Position.MIDDLE);
        }

        new ParametroDialogBuilder("Parâmetros", parametros, this::processarParametrosSelecionados, camposRetornoConfigurados).abrir();
    }

    private void processarParametrosSelecionados(Map<String, Object> valores) {
        this.parametrosSelecionados = valores;
        logger.info("Parâmetros selecionados: {}", valores);

        Map<String, Object> paramsValidados = new HashMap<>();
        for (Map.Entry<String, Object> entry : valores.entrySet()) {
            String key = entry.getKey();
            Object value = entry.getValue();
            if (value instanceof Double && "NUMBER".equals(getParamType(parametrosSelecionados, key))) {
                paramsValidados.put(key, ((Double) value).intValue());
            } else if (value instanceof String && ((String) value).isEmpty() && !"DATE".equals(getParamType(parametrosSelecionados, key))) {
                paramsValidados.put(key, null);
            } else {
                paramsValidados.put(key, value);
            }
        }

        try {
            List<RelatorioDinamicoResult> dados = relatorioService.executarProcedure(procedureName, paramsValidados);
            if (dados == null || dados.isEmpty()) {
                Notification.show("Nenhum dado retornado pela procedure.", 5000, Notification.Position.MIDDLE);
            } else {
                List<RelatorioDinamicoResult> mutableDados = new ArrayList<>(dados);
                updateData(mutableDados);
                Notification.show("Relatório carregado com " + dados.size() + " registros.");
            }
        } catch (Exception ex) {
            logger.error("Erro ao executar relatório: {}", ex.getMessage(), ex);
            String errorMessage = ex.getMessage() != null ? ex.getMessage() : "Erro desconhecido ao executar o relatório. Verifique os logs para mais detalhes.";
            Notification.show("Erro ao executar relatório: " + errorMessage, 5000, Notification.Position.MIDDLE);
        }
    }

    private String fieldNameToHeader(String fieldName) {
        // Converter fieldName (ex.: cd_empresa) para um header amigável (ex.: Código Empresa)
        String[] words = fieldName.split("_");
        StringBuilder header = new StringBuilder();
        for (String word : words) {
            if (word.length() > 0) {
                header.append(Character.toUpperCase(word.charAt(0)))
                      .append(word.substring(1).toLowerCase())
                      .append(" ");
            }
        }
        return header.toString().trim();
    }

    private boolean isDateFormat(String value) {
        // Verificar se o valor está no formato de data (ex.: '2025-05-12 00:00:00.000')
        return value.matches("\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}\\.\\d{3}");
    }

    private String getParamType(Map<String, Object> params, String field) {
        List<ParametroRelatorio> parametros = parametroService.getParametros(procedureName);
        return parametros.stream()
                .filter(p -> p.getField().equals(field))
                .map(ParametroRelatorio::getTipo)
                .findFirst()
                .orElse("UNKNOWN");
    }

    @Override
    public Class<RelatorioDinamicoResult> getEntityClass() {
        return RelatorioDinamicoResult.class;
    }

    protected List<RelatorioDinamicoResult> getData() {
        return new ArrayList<>();
    }

    @Override
    protected GenericRepository<RelatorioDinamicoResult, ?> getRepository() {
        return null;
    }

    @Override
    public List<GridFilterUtil.ColumnConfig<RelatorioDinamicoResult>> configureColumns() {
        List<GridFilterUtil.ColumnConfig<RelatorioDinamicoResult>> columnConfigs = new ArrayList<>();
        List<GridColumnConfig> configs = gridColumnConfigRelatorioService.getColumnConfigs(procedureName);

        logger.info("Configurando colunas para {}: total = {}", procedureName, configs.size());

        Set<String> chavesUsadas = new HashSet<>();

        for (GridColumnConfig config : configs) {
            if (!config.isVisible()) continue;
            if (chavesUsadas.contains(config.getField())) continue;

            Grid.Column<RelatorioDinamicoResult> column = grid.addColumn(item -> {
                Object value = item.getValores().get(config.getField());
                return value != null ? value.toString() : "";
            }).setKey(config.getField());

            column.setHeader(config.getHeader() != null ? config.getHeader() : config.getField());
            column.setSortable(true);
            column.setAutoWidth(true);

            if (config.getWidth() != null) {
                column.setWidth(config.getWidth());
            }

            if (config.getStyle() != null) {
                Arrays.stream(config.getStyle().split(";"))
                        .filter(rule -> rule.contains(":"))
                        .forEach(rule -> {
                            String[] parts = rule.split(":");
                            column.getElement().getStyle().set(parts[0].trim(), parts[1].trim());
                        });
            }

            chavesUsadas.add(config.getField());

            columnConfigs.add(new GridFilterUtil.ColumnConfig<>(
                    column,
                    config.getHeader(),
                    item -> {
                        Object v = item.getValores().get(config.getField());
                        return v != null ? v.toString() : null;
                    },
                    config
            ));
        }

        logger.info("Total de colunas configuradas: {}", columnConfigs.size());
        return columnConfigs;
    }
}