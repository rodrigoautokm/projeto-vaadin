package com.exemplo;

public class ParametroRelatorio {
    private String field;
    private String tipo;
    private String header;
    private boolean obrigatorio;
    private String valorDefault;
    private String dropdownValues; // Novo campo para valores de dropdown

    public ParametroRelatorio(String field, String tipo, boolean obrigatorio) {
        this.field = field;
        this.tipo = tipo;
        this.obrigatorio = obrigatorio;
    }

    public ParametroRelatorio(String field, String tipo, String dropdownValues, boolean obrigatorio) {
        this.field = field;
        this.tipo = tipo;
        this.dropdownValues = dropdownValues; // Armazenar no campo correto
        this.obrigatorio = obrigatorio;
    }

    public String getField() {
        return field;
    }

    public String getTipo() {
        return tipo;
    }

    public String getHeader() {
        return header;
    }

    public boolean isObrigatorio() {
        return obrigatorio;
    }

    public String getValorDefault() {
        return valorDefault;
    }

    public String getDropdownValues() {
        return dropdownValues;
    }

    public void setField(String field) {
        this.field = field;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public void setHeader(String header) {
        this.header = header;
    }

    public void setObrigatorio(boolean obrigatorio) {
        this.obrigatorio = obrigatorio;
    }

    public void setValorDefault(String valorDefault) {
        this.valorDefault = valorDefault;
    }

    public void setDropdownValues(String dropdownValues) {
        this.dropdownValues = dropdownValues;
    }
}