package com.exemplo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ParametroRelatorioService {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public List<ParametroRelatorio> getParametros(String procedureName) {
        String sql = "SELECT parametro_nome, tipo, header, valor_default, dropdown_values " +
                     "FROM vw_procedure_parametros WHERE procedure_name = ? ORDER BY ordem";
        return jdbcTemplate.query(sql, new Object[]{procedureName}, (rs, rowNum) -> {
            String field = rs.getString("parametro_nome");
            String tipo = rs.getString("tipo");
            String header = rs.getString("header");
            String valorDefault = rs.getString("valor_default");
            String dropdownValues = rs.getString("dropdown_values");

            ParametroRelatorio parametro = new ParametroRelatorio(field, tipo, dropdownValues, false);
            parametro.setHeader(header);
            parametro.setValorDefault(valorDefault);
            return parametro;
        });
    }
}