package com.exemplo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.*;

@Service
public class RelatorioService {

    private static final Logger logger = LoggerFactory.getLogger(RelatorioService.class);

    private final JdbcTemplate jdbcTemplate;
    private final ParametroRelatorioService parametroService;

    public RelatorioService(JdbcTemplate jdbcTemplate, ParametroRelatorioService parametroService) {
        this.jdbcTemplate = jdbcTemplate;
        this.parametroService = parametroService;
    }

    public List<RelatorioDinamicoResult> executarProcedure(String procedureName, Map<String, Object> parametros) {
        logger.info("Executando procedure: {}", procedureName);
        List<RelatorioDinamicoResult> resultados = new ArrayList<>();

        List<ParametroRelatorio> parametroDefs = parametroService.getParametros(procedureName);
        if (parametroDefs.size() != 20 && "pr_rel_vendas_r04".equals(procedureName)) {
            logger.error("Número incorreto de parâmetros para {}: esperado 20, encontrado {}", procedureName, parametroDefs.size());
            throw new IllegalStateException("Número incorreto de parâmetros para " + procedureName);
        }

        String sql = construirSqlChamada(procedureName, parametroDefs.size());
        logger.debug("SQL gerado: {}", sql);

        Connection connection = null;
        CallableStatement stmt = null;
        ResultSet rs = null;
        try {
            connection = jdbcTemplate.getDataSource().getConnection();
            stmt = connection.prepareCall(sql);

            int index = 1;
            for (ParametroRelatorio paramDef : parametroDefs) {
                String paramName = paramDef.getField();
                Object valor = parametros.get(paramName);
                String tipo = paramDef.getTipo();

                logger.debug("Parâmetro {}: valor={}, tipo={}", paramName, valor, tipo);

                if (valor == null) {
                    stmt.setNull(index, getSqlType(tipo));
                } else if ("NUMBER".equals(tipo)) {
                    if (valor instanceof Double) {
                        stmt.setInt(index, ((Double) valor).intValue());
                    } else if (valor instanceof Integer) {
                        stmt.setInt(index, (Integer) valor);
                    } else if (valor instanceof String) {
                        try {
                            stmt.setInt(index, Integer.parseInt((String) valor));
                        } catch (NumberFormatException e) {
                            stmt.setInt(index, 0);
                            logger.warn("Valor inválido para NUMBER em {}: {}. Usando 0.", paramName, valor);
                        }
                    } else {
                        stmt.setNull(index, Types.INTEGER);
                        logger.warn("Valor inválido para NUMBER em {}: {}. Usando NULL.", paramName, valor);
                    }
                } else if ("STRING".equals(tipo)) {
                    stmt.setString(index, valor.toString());
                } else if ("DATE".equals(tipo)) {
                    if (valor instanceof java.time.LocalDate) {
                        stmt.setDate(index, Date.valueOf((java.time.LocalDate) valor));
                    } else if (valor instanceof String && !((String) valor).isEmpty()) {
                        stmt.setString(index, (String) valor);
                    } else {
                        stmt.setNull(index, Types.DATE);
                        logger.warn("Valor inválido para DATE em {}: {}. Usando NULL.", paramName, valor);
                    }
                } else {
                    stmt.setObject(index, valor);
                    logger.warn("Tipo desconhecido para {}: {}. Usando setObject.", paramName, tipo);
                }
                index++;
            }

            boolean hasResults = stmt.execute();
            while (hasResults) {
                rs = stmt.getResultSet();
                while (rs.next()) {
                    Map<String, Object> linha = new HashMap<>();
                    int columnCount = rs.getMetaData().getColumnCount();
                    for (int i = 1; i <= columnCount; i++) {
                        String coluna = rs.getMetaData().getColumnLabel(i);
                        Object valor = rs.getObject(i);
                        linha.put(coluna, valor);
                        logger.debug("Coluna {}: valor={}", coluna, valor);
                    }
                    resultados.add(new RelatorioDinamicoResult(linha));
                }
                rs.close();
                rs = null;
                hasResults = stmt.getMoreResults();
            }

        } catch (Exception e) {
            logger.error("Erro ao executar procedure {}: {}", procedureName, e.getMessage(), e);
            throw new RuntimeException("Erro ao executar procedure: " + e.getMessage(), e);
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (Exception e) {
                    logger.error("Erro ao fechar ResultSet: {}", e.getMessage(), e);
                }
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (Exception e) {
                    logger.error("Erro ao fechar CallableStatement: {}", e.getMessage(), e);
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (Exception e) {
                    logger.error("Erro ao fechar Connection: {}", e.getMessage(), e);
                }
            }
        }

        logger.info("Procedure {} executada com sucesso. Total de registros: {}", procedureName, resultados.size());
        return new ArrayList<>(resultados);
    }

    private String construirSqlChamada(String procedureName, int qtdParametros) {
        StringJoiner joiner = new StringJoiner(",", "CALL " + procedureName + "(", ")");
        for (int i = 0; i < qtdParametros; i++) {
            joiner.add("?");
        }
        return joiner.toString();
    }

    private int getSqlType(String tipo) {
        switch (tipo) {
            case "NUMBER": return Types.INTEGER;
            case "STRING": return Types.VARCHAR;
            case "DATE": return Types.DATE;
            default: return Types.NULL;
        }
    }
}