package com.exemplo;

import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.checkbox.Checkbox;
import com.vaadin.flow.component.combobox.MultiSelectComboBox;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.grid.GridSortOrder;
import com.vaadin.flow.component.grid.HeaderRow;
import com.vaadin.flow.component.html.Span;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.data.provider.SortDirection;
import com.vaadin.flow.data.renderer.ComponentRenderer;
import com.vaadin.flow.shared.Registration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import javax.sql.DataSource;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import com.exemplo.CustomUserDetails;

public class GridFilterUtil<T> {

    private static final Logger logger = LoggerFactory.getLogger(GridFilterUtil.class);

    private Grid<T> grid;
    private List<T> items;
    private String gridId;
    private String usuarioId;
    private Consumer<Map<String, String>> filterChangeListener;
    private Map<String, Set<String>> activeFilters = new HashMap<>();
    private List<ColumnConfig<T>> columnConfigs;
    private GridAggregationUtil<T> aggregationUtil;
    private final HorizontalLayout activeFiltersLayout;
    private boolean filtersChanged = false;
    private boolean columnOrderChanged = false;
    private boolean visibilityChanged = false;
    private List<String> initialColumnOrder;
    private Registration sortOrderListener;
    private String sortColumn;
    private String sortDirection;
    private boolean sortChanged = false;
    private boolean isProcessingReorder = false;
    private final GridColumnConfigService gridColumnConfigService;
    private VerticalLayout layoutRaiz;

    public GridFilterUtil(String gridId, Grid<T> grid, List<ColumnConfig<T>> columnConfigs, String usuarioId, Integer cdEmpresa) {
        logger.info("Inicializando GridFilterUtil para gridId: {}", gridId);
        this.gridId = gridId;
        this.grid = grid;
        this.columnConfigs = columnConfigs;
        this.usuarioId = usuarioId;
        this.activeFiltersLayout = new HorizontalLayout();
        this.activeFiltersLayout.setAlignItems(VerticalLayout.Alignment.CENTER);
        this.activeFiltersLayout.setSpacing(true);
        this.activeFiltersLayout.setMinWidth("300px");
        this.activeFiltersLayout.getStyle()
                .set("margin-left", "10px")
                .set("white-space", "nowrap")
                .set("flex-shrink", "0");

        this.gridColumnConfigService = AppContext.getBean(GridColumnConfigService.class);
        this.items = new ArrayList<>(); // Inicializar como mutável

        this.layoutRaiz = new VerticalLayout();
        this.layoutRaiz.setSizeFull();
        this.layoutRaiz.add(grid);

        initialize(gridId, grid, columnConfigs, () -> null);
    }

    public GridFilterUtil(Grid<T> grid, List<T> items, String gridId, String usuarioId, GridColumnConfigService gridColumnConfigService) {
        logger.info("Inicializando GridFilterUtil para gridId: {}", gridId);
        this.grid = grid;
        this.items = new ArrayList<>(items != null ? items : new ArrayList<>()); // Garantir que seja mutável
        this.gridId = gridId;
        this.usuarioId = usuarioId;
        this.gridColumnConfigService = gridColumnConfigService;
        this.activeFiltersLayout = new HorizontalLayout();
        this.activeFiltersLayout.setAlignItems(VerticalLayout.Alignment.CENTER);
        this.activeFiltersLayout.setSpacing(true);
        this.activeFiltersLayout.setMinWidth("300px");
        this.activeFiltersLayout.getStyle()
                .set("margin-left", "10px")
                .set("white-space", "nowrap")
                .set("flex-shrink", "0");

        this.layoutRaiz = new VerticalLayout();
        this.layoutRaiz.setSizeFull();
        this.layoutRaiz.add(grid);
    }

    public void initialize(String gridId, Grid<T> grid, List<ColumnConfig<T>> columnConfigs, Supplier<T> itemSupplier) {
        logger.info("Inicializando GridFilterUtil para gridId: {}. Colunas fornecidas: {}", gridId, columnConfigs.size());
        this.gridId = gridId;
        this.grid = grid;
        this.columnConfigs = new ArrayList<>(columnConfigs); // Garantir que seja mutável
        this.aggregationUtil = new GridAggregationUtil<>(this.items, this.columnConfigs);

        grid.setItems(this.items);
        grid.setColumnReorderingAllowed(true);
        logger.debug("Reordenação de colunas habilitada: {}", grid.isColumnReorderingAllowed());
        grid.getElement().setProperty("resizable", true);

        sortOrderListener = grid.addSortListener(event -> {
            logger.debug("Evento de ordenação disparado para gridId: {}", gridId);
            List<GridSortOrder<T>> sortOrders = event.getSortOrder();
            if (!sortOrders.isEmpty()) {
                GridSortOrder<T> sortOrder = sortOrders.get(0);
                sortColumn = sortOrder.getSorted().getKey();
                sortDirection = sortOrder.getDirection() == SortDirection.ASCENDING ? "ASC" : "DESC";
                logger.debug("Ordenação alterada para gridId: {}. Coluna: {}, Direção: {}", gridId, sortColumn, sortDirection);
                sortChanged = true;
            } else {
                sortColumn = null;
                sortDirection = null;
                logger.debug("Ordenação removida para gridId: {}", gridId);
                sortChanged = true;
            }
            salvarSortConfig();
        });

        grid.addColumnReorderListener(event -> {
            if (isProcessingReorder) {
                logger.debug("Evento de reordenação ignorado para evitar loop para gridId: {}", gridId);
                return;
            }

            try {
                isProcessingReorder = true;
                logger.debug("Evento de reordenação de colunas disparado para gridId: {}", gridId);
                List<Grid.Column<T>> newOrder = event.getColumns();
                String newColumnOrder = newOrder.stream()
                        .map(Grid.Column::getKey)
                        .filter(Objects::nonNull)
                        .collect(Collectors.joining("-"));
                logger.debug("Nova ordem das colunas capturada: {}", newColumnOrder);
                salvarOrdemColunas(newColumnOrder);
            } finally {
                isProcessingReorder = false;
            }
        });

        logger.debug("GridFilterUtil inicializado com {} itens iniciais", this.items.size());
        adicionarFiltrosNoCabecalho(columnConfigs);
    }

    public void saveChanges() {
        logger.debug("Verificando mudanças para salvar no gridId: {}", gridId);

        logger.debug("visibilityChanged: {}, filtersChanged: {}, columnOrderChanged: {}", 
                visibilityChanged, filtersChanged, columnOrderChanged);
        if (visibilityChanged) {
            salvarPreferencias();
            visibilityChanged = false;
        }
        if (filtersChanged) {
            salvarFiltros();
            filtersChanged = false;
        }
        if (columnOrderChanged) {
            String ordemColunas = grid.getColumns().stream()
                    .map(Grid.Column::getKey)
                    .filter(Objects::nonNull)
                    .collect(Collectors.joining("-"));
            salvarOrdemColunas(ordemColunas);
            columnOrderChanged = false;
        }

        if (sortOrderListener != null) {
            sortOrderListener.remove();
            sortOrderListener = null;
        }
    }

    private void carregarPreferencias() {
        logger.debug("Carregando preferências para gridId: {} e usuario: {}", gridId, usuarioId);
        VisibilidadeColunaService service = AppContext.getBean(VisibilidadeColunaService.class);
        
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        Integer cdEmpresa = null;
        if (auth != null && auth.getPrincipal() instanceof CustomUserDetails) {
            Short cdEmpresaShort = ((CustomUserDetails) auth.getPrincipal()).getCdEmpresa();
            cdEmpresa = cdEmpresaShort != null ? cdEmpresaShort.intValue() : null;
        }

        if (cdEmpresa == null || cdEmpresa <= 0) {
            logger.warn("cdEmpresa ausente ou inválido ({}), ignorando carregamento de preferências para gridId: {}", cdEmpresa, gridId);
            return;
        }

        DataSource ds = AppContext.getBean(EmpresaConnectionManager.class)
            .getDataSourceForEmpresa(cdEmpresa);

        Map<String, Boolean> preferencias = service.carregarPreferencias(usuarioId, gridId, ds);
    
        if (preferencias != null && !preferencias.isEmpty()) {
            grid.getColumns().forEach(column -> {
                String columnKey = column.getKey();
                if (columnKey != null && preferencias.containsKey(columnKey)) {
                    column.setVisible(preferencias.get(columnKey));
                    logger.debug("Coluna {} visibilidade definida como {} via preferências do banco de dados", columnKey, preferencias.get(columnKey));
                }
            });
        } else {
            logger.debug("Nenhuma preferência encontrada para gridId: {} e usuario: {}", gridId, usuarioId);
        }
    }

    private void salvarPreferencias() {
        logger.debug("Salvando preferências para gridId: {} e usuario: {}", gridId, usuarioId);
        try {
            VisibilidadeColunaService service = AppContext.getBean(VisibilidadeColunaService.class);
            Map<String, Boolean> preferencias = grid.getColumns().stream()
                    .filter(col -> col.getKey() != null)
                    .collect(Collectors.toMap(
                            Grid.Column::getKey,
                            Grid.Column::isVisible
                    ));
            
            Authentication auth = SecurityContextHolder.getContext().getAuthentication();
            Integer cdEmpresa = null;
            if (auth != null && auth.getPrincipal() instanceof CustomUserDetails) {
                Short cdEmpresaShort = ((CustomUserDetails) auth.getPrincipal()).getCdEmpresa();
                cdEmpresa = cdEmpresaShort != null ? cdEmpresaShort.intValue() : null;
            }
            DataSource ds = AppContext.getBean(EmpresaConnectionManager.class)
                .getDataSourceForEmpresa(cdEmpresa != null ? cdEmpresa : -1);
            service.salvar(usuarioId, gridId, preferencias, ds);
    
            logger.info("Preferências de visibilidade salvas no banco de dados para gridId={} e usuario={}", gridId, usuarioId);
        } catch (Exception e) {
            logger.error("Erro ao salvar preferências de visibilidade para gridId: {} e usuario: {}", gridId, usuarioId, e);
        }
    }

    private void salvarFiltros() {
        logger.debug("Salvando filtros para gridId: {} e usuario: {}", gridId, usuarioId);
        try {
            FiltroUsuarioService service = AppContext.getBean(FiltroUsuarioService.class);
            Map<String, String> filtros = activeFilters.entrySet().stream()
                    .collect(Collectors.toMap(
                            Map.Entry::getKey,
                            entry -> String.join("-", entry.getValue())
                    ));
            service.salvarFiltros(usuarioId, gridId, filtros);
            logger.info("Filtros salvos no banco de dados para gridId={} e usuario={}", gridId, usuarioId);
        } catch (Exception e) {
            logger.error("Erro ao salvar filtros para gridId: {} e usuario: {}", gridId, usuarioId, e);
        }
    }

    private Map<String, String> carregarFiltros() {
        logger.debug("Carregando filtros para gridId: {} e usuario: {}", gridId, usuarioId);
        try {
            FiltroUsuarioService service = AppContext.getBean(FiltroUsuarioService.class);
            Map<String, String> filtros = service.carregarFiltros(usuarioId, gridId);
            logger.debug("Filtros carregados: {}", filtros);
            return filtros;
        } catch (Exception e) {
            logger.error("Erro ao carregar filtros para gridId: {} e usuario: {}", gridId, usuarioId, e);
            return new HashMap<>();
        }
    }

    private void salvarOrdemColunas(String ordemColunas) {
        logger.debug("Salvando ordem das colunas para gridId: {} e usuario: {}", gridId, usuarioId);
        try {
            OrdemColunaService service = AppContext.getBean(OrdemColunaService.class);
            logger.debug("Ordem das colunas a ser salva: {}", ordemColunas);
            service.salvarOrdemColunas(usuarioId, gridId, ordemColunas);
            logger.info("Ordem das colunas salva no banco de dados para gridId={} e usuario={}", gridId, usuarioId);
        } catch (Exception e) {
            logger.error("Erro ao salvar ordem das colunas para gridId: {} e usuario: {}. Detalhes: {}", gridId, usuarioId, e.getMessage(), e);
        }
    }

    private String carregarOrdemColunas() {
        logger.debug("Carregando ordem das colunas para gridId: {} e usuario: {}", gridId, usuarioId);
        try {
            OrdemColunaService service = AppContext.getBean(OrdemColunaService.class);
            String ordemColunas = service.carregarOrdemColunas(usuarioId, gridId);
            logger.debug("Ordem das colunas carregada: {}", ordemColunas);
            return ordemColunas;
        } catch (Exception e) {
            logger.error("Erro ao carregar ordem das colunas para gridId: {} e usuario: {}", gridId, usuarioId, e);
            return null;
        }
    }

    private void salvarSortConfig() {
        logger.debug("Salvando sort_config para gridId={} e usuario={}", gridId, usuarioId);
        try {
            SortConfigService service = AppContext.getBean(SortConfigService.class);
            SortConfig config = new SortConfig();
            config.setId(new SortConfigId(usuarioId, gridId));
            config.setSortColumn(sortColumn);
            config.setSortDirection(sortDirection);
            service.salvarSortConfig(usuarioId, gridId, sortColumn, sortDirection);
            logger.info("Sort_config salvo: {}", config);
        } catch (Exception e) {
            logger.error("Erro ao salvar sort_config para gridId={} e usuario={}", gridId, usuarioId, e);
        }
    }

    private void carregarSortConfig() {
        logger.debug("Carregando configuração de sort para gridId={} e usuario={}", gridId, usuarioId);
        try {
            SortConfigService service = AppContext.getBean(SortConfigService.class);
            SortConfig config = service.obterConfig(usuarioId, gridId);
            if (config != null && config.getSortColumn() != null && config.getSortDirection() != null) {
                sortColumn = config.getSortColumn();
                sortDirection = config.getSortDirection();
                grid.getColumns().stream()
                        .filter(c -> sortColumn.equals(c.getKey()))
                        .findFirst()
                        .ifPresent(column -> {
                            SortDirection dir = "ASC".equalsIgnoreCase(sortDirection) ? SortDirection.ASCENDING : SortDirection.DESCENDING;
                            grid.sort(Collections.singletonList(new GridSortOrder<>(column, dir)));
                            logger.info("Ordenação aplicada: coluna={}, direção={}", sortColumn, sortDirection);
                        });
            } else {
                logger.debug("Nenhuma configuração de sort encontrada para gridId={} e usuario={}", gridId, usuarioId);
            }
        } catch (Exception e) {
            logger.error("Erro ao carregar sort_config para gridId={} e usuario={}", gridId, usuarioId, e);
        }
    }

    public void setFilterChangeListener(Consumer<Map<String, String>> listener) {
        logger.debug("Configurando listener de mudança de filtro para gridId: {}", gridId);
        this.filterChangeListener = listener;
        notifyFilterChange();
    }

    public void updateItems(List<T> newItems) {
        logger.info("Atualizando itens no gridId: {}. Novos itens: {}", gridId, newItems != null ? newItems.size() : 0);
        this.items = new ArrayList<>(newItems != null ? newItems : new ArrayList<>()); // Garantir que seja mutável
        grid.setItems(this.items);
        clearAllFilters();
        if (aggregationUtil != null) {
            logger.debug("Atualizando itens no GridAggregationUtil para gridId: {}", gridId);
            aggregationUtil.updateItems(this.items);
        }
        if (columnConfigs != null) {
            logger.debug("Recarregando filtros com base nos novos itens");
            adicionarFiltrosNoCabecalho(columnConfigs);
        }
        logger.debug("Itens atualizados com sucesso, total: {}", this.items.size());
    }

    public void clearAllFilters() {
        logger.info("Limpando todos os filtros para gridId: {}", gridId);
        activeFilters.clear();
        grid.setItems(items);
        filtersChanged = true;
        notifyFilterChange();
        updateFilterRowHighlight();
        logger.debug("Filtros limpos com sucesso");
    }

    @SuppressWarnings("unchecked")
    public void adicionarFiltrosNoCabecalho(List<ColumnConfig<T>> columnConfigs) {
        logger.info("Adicionando filtros no cabeçalho para gridId: {}. Colunas fornecidas: {}", gridId, columnConfigs.size());
        this.columnConfigs = new ArrayList<>(columnConfigs); // Garantir que seja mutável
        this.aggregationUtil = new GridAggregationUtil<>(this.items, this.columnConfigs);

        if (items.isEmpty()) {
            logger.warn("Lista de itens vazia. Filtros não serão configurados até que os itens sejam atualizados.");
            return;
        }

        carregarPreferencias();

        String ordemColunas = carregarOrdemColunas();
        if (ordemColunas != null && !ordemColunas.isEmpty()) {
            List<String> orderedKeys = Arrays.asList(ordemColunas.split("-"));
            List<Grid.Column<T>> columns = grid.getColumns();
            List<Grid.Column<T>> reorderedColumns = orderedKeys.stream()
                    .map(key -> columns.stream().filter(col -> key.equals(col.getKey())).findFirst().orElse(null))
                    .filter(col -> col != null)
                    .collect(Collectors.toList());
            columns.stream()
                    .filter(col -> !reorderedColumns.contains(col))
                    .forEach(reorderedColumns::add);
            grid.setColumnOrder(reorderedColumns);
            logger.debug("Ordem das colunas aplicada: {}", ordemColunas);
        }

        initialColumnOrder = grid.getColumns().stream()
                .map(Grid.Column::getKey)
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
        logger.debug("Ordem inicial das colunas: {}", initialColumnOrder);

        carregarSortConfig();

        List<String> currentColumnKeys = columnConfigs.stream()
                .map(config -> config.column.getKey())
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
        logger.debug("Chaves das colunas: {}", currentColumnKeys);

        activeFilters.keySet().removeIf(columnKey -> {
            if (!currentColumnKeys.contains(columnKey)) {
                logger.warn("Removendo filtro ativo para coluna desconhecida {} em gridId: {}", columnKey, gridId);
                return true;
            }
            return false;
        });

        Button configButton = new Button(new Icon(VaadinIcon.COG));
        configButton.getElement().setAttribute("title", "Configurar colunas");
        configButton.addClickListener(event -> {
            logger.debug("Botão de configuração de colunas clicado para gridId: {}", gridId);
            abrirDialogoConfiguracaoColunas(columnConfigs);
        });

        Button saveOrderButton = new Button("Salvar Ordenação", event -> {
            logger.debug("Botão 'Salvar Ordenação' clicado para gridId: {}", gridId);
            columnOrderChanged = true;
            saveChanges();
        });

        Button agruparButton = aggregationUtil.createAggregationButton();

        HorizontalLayout configLayout = new HorizontalLayout(configButton, saveOrderButton, agruparButton);
        configLayout.setDefaultVerticalComponentAlignment(VerticalLayout.Alignment.CENTER);
        configLayout.getStyle().set("flex-shrink", "0");

        HorizontalLayout combinedLayout = new HorizontalLayout(configLayout);
        combinedLayout.setDefaultVerticalComponentAlignment(VerticalLayout.Alignment.CENTER);
        combinedLayout.setWidthFull();
        combinedLayout.getStyle()
                .set("flex-wrap", "nowrap")
                .set("overflow", "visible")
                .set("position", "sticky")
                .set("top", "0")
                .set("z-index", "100")
                .set("background-color", "var(--lumo-base-color)")
                .set("padding", "var(--lumo-space-s)")
                .set("box-shadow", "0 2px 4px rgba(0,0,0,0.1)");
        combinedLayout.addClassName("grid-filter-header-cell");

        HeaderRow configRow = grid.prependHeaderRow();
        configRow.getCells().forEach(cell -> cell.setText(""));
        configRow.join(configRow.getCells().toArray(new HeaderRow.HeaderCell[0])).setComponent(combinedLayout);

        HeaderRow filterRow = grid.appendHeaderRow();

        int processedColumns = 0;
        for (ColumnConfig<T> config : columnConfigs) {
            Grid.Column<T> column = config.column;
            String columnKey = column.getKey();
            if (columnKey == null) {
                logger.warn("Coluna sem chave definida, ignorando para evitar erro.");
                continue;
            }

            column.setResizable(true);
            column.setAutoWidth(false);
            column.setSortable(true);

            // Carregar configurações adicionais, mas sem sobrescrever o header
            GridColumnConfig gridColumnConfig = gridColumnConfigService.getColumnConfig(gridId, usuarioId, columnKey);
            if (gridColumnConfig == null) {
                gridColumnConfig = config.getGridColumnConfig();
            }
            if (gridColumnConfig != null) {
                logger.debug("Coluna {}: largura definida: {}", columnKey, gridColumnConfig.getWidth());
                logger.debug("Coluna {}: dropdownValueMap: {}", columnKey, gridColumnConfig.getDropdownValueMap());
            }

            // Aplicar o mapeamento do dropdownValueMap na exibição da coluna
            if (gridColumnConfig != null && gridColumnConfig.getDropdownValueMap() != null && !gridColumnConfig.getDropdownValueMap().isEmpty()) {
                Map<String, String> valueMap = gridColumnConfig.getDropdownValueMap();
                grid.removeColumn(column);
                column = grid.addColumn(item -> {
                    Object rawValue = config.getValueExtractor().apply(item);
                    return rawValue != null ? valueMap.getOrDefault(rawValue.toString(), rawValue.toString()) : "";
                });
                column.setKey(columnKey);
                column.setResizable(true);
                column.setAutoWidth(false);
                column.setSortable(true);
                // Definir o header corretamente após recriar a coluna
                column.setHeader(config.getHeader());
                config.setColumn(column);
            }

            final String finalColumnKey = columnKey;

            HorizontalLayout headerLayout = new HorizontalLayout();
            headerLayout.setDefaultVerticalComponentAlignment(VerticalLayout.Alignment.CENTER);
            headerLayout.setWidth(gridColumnConfig != null ? gridColumnConfig.getWidth() : "120px");
            headerLayout.getStyle()
                    .set("display", "flex")
                    .set("justify-content", "space-between")
                    .set("align-items", "center")
                    .set("padding", "0 8px")
                    .set("margin", "0")
                    .set("box-sizing", "border-box")
                    .set("overflow", "hidden");

            if (gridColumnConfig != null) {
                StringBuilder tooltip = new StringBuilder("Configurações da Coluna:\n");
                tooltip.append("Field: ").append(gridColumnConfig.getField()).append("\n");
                tooltip.append("Header: ").append(gridColumnConfig.getHeader()).append("\n");
                tooltip.append("Type: ").append(gridColumnConfig.getType()).append("\n");
                tooltip.append("Width: ").append(gridColumnConfig.getWidth()).append("\n");
                tooltip.append("Style: ").append(gridColumnConfig.getStyle()).append("\n");
                tooltip.append("Filter Type: ").append(gridColumnConfig.getFilterType()).append("\n");
                tooltip.append("Visible: ").append(gridColumnConfig.isVisible());
                headerLayout.getElement().setAttribute("title", tooltip.toString());
            }

            // Usar o header configurado no ColumnConfig (vindo do RelatorioView)
            Span headerSpan = new Span(config.header);
            headerSpan.getStyle()
                    .set("flex-grow", "1")
                    .set("overflow", "hidden")
                    .set("text-overflow", "ellipsis")
                    .set("white-space", "nowrap");
            headerLayout.add(headerSpan);
            column.setHeader(headerLayout);

            final MultiSelectComboBox<String> multiSelectComboBox = new MultiSelectComboBox<>();
            multiSelectComboBox.setClearButtonVisible(true);
            multiSelectComboBox.setPlaceholder("Selecionar...");
            multiSelectComboBox.getStyle().set("font-size", "12px");

            Map<String, Long> contagemPorValor = items.stream()
                    .map(item -> {
                        Object value = config.valueExtractor.apply(item);
                        return value != null ? String.valueOf(value) : "";
                    })
                    .filter(v -> !v.isEmpty())
                    .collect(Collectors.groupingBy(v -> v, Collectors.counting()));

            List<String> valoresUnicos = contagemPorValor.entrySet().stream()
                    .sorted(Map.Entry.<String, Long>comparingByValue(Comparator.reverseOrder())
                            .thenComparing(Map.Entry.comparingByKey()))
                    .map(Map.Entry::getKey)
                    .collect(Collectors.toList());
            logger.debug("Valores únicos para coluna {}: {}", finalColumnKey, valoresUnicos);

            if (gridColumnConfig != null && gridColumnConfig.getDropdownValueMap() != null && !gridColumnConfig.getDropdownValueMap().isEmpty()) {
                Map<String, String> valueMap = gridColumnConfig.getDropdownValueMap();
                valoresUnicos = valoresUnicos.stream()
                        .map(rawValue -> valueMap.getOrDefault(rawValue, rawValue))
                        .distinct()
                        .collect(Collectors.toList());
                logger.debug("Valores exibidos ajustados para filtro da coluna {}: {}", finalColumnKey, valoresUnicos);
            }

            if (valoresUnicos.isEmpty()) {
                logger.warn("Nenhum valor único encontrado para coluna {}. Filtro não será configurado.", finalColumnKey);
                continue;
            }

            multiSelectComboBox.setItems(valoresUnicos);
            multiSelectComboBox.setRenderer(new ComponentRenderer<>(item -> {
                String texto = item + " (" + contagemPorValor.getOrDefault(item, 0L) + ")";
                return new Span(texto);
            }));

            int maxLength = valoresUnicos.stream()
                    .mapToInt(item -> (item + " (" + contagemPorValor.get(item) + ")").length())
                    .max()
                    .orElse(10);
            int widthPx = Math.min(Math.max(maxLength * 8, 100), 200);
            multiSelectComboBox.setWidth(widthPx + "px");

            multiSelectComboBox.addValueChangeListener(event -> {
                logger.debug("Filtro alterado para coluna {} em gridId: {}. Valores selecionados: {}", finalColumnKey, gridId, event.getValue());
                Set<String> selectedValues = event.getValue();
                if (selectedValues == null || selectedValues.isEmpty()) {
                    activeFilters.remove(finalColumnKey);
                } else {
                    activeFilters.put(finalColumnKey, selectedValues);
                }
                applyFilters();
                updateFilterRowHighlight();
            });

            if (column.isVisible()) {
                HeaderRow.HeaderCell filterCell = filterRow.getCell(column);
                filterCell.setComponent(multiSelectComboBox);
                if (activeFilters.containsKey(finalColumnKey) && !activeFilters.get(finalColumnKey).isEmpty()) {
                    multiSelectComboBox.getStyle()
                            .set("background-color", "var(--lumo-primary-color-10pct)")
                            .set("border", "1px solid var(--lumo-primary-color)");
                }
            }

            Map<String, String> savedFilters = carregarFiltros();
            if (savedFilters != null && savedFilters.containsKey(finalColumnKey)) {
                String savedFilterValue = savedFilters.get(finalColumnKey);
                logger.info("Aplicando filtro salvo para coluna {} em gridId: {}. Valores: {}", finalColumnKey, gridId, savedFilterValue);
                Set<String> selectedValues = new HashSet<>(Arrays.asList(savedFilterValue.split("-"))); // Garantir que seja mutável
                if (selectedValues.stream().allMatch(valoresUnicos::contains)) {
                    activeFilters.put(finalColumnKey, selectedValues);
                    multiSelectComboBox.setValue(selectedValues);
                    applyFilters();
                    updateFilterRowHighlight();
                } else {
                    logger.warn("Valores de filtro salvos inválidos para coluna {} em gridId: {}. Limpando filtro.", finalColumnKey, gridId);
                    activeFilters.remove(finalColumnKey);
                }
            }

            processedColumns++;
        }

        logger.info("Total de colunas processadas para gridId {}: {}", gridId, processedColumns);
        List<String> visibleColumns = grid.getColumns().stream()
                .filter(Grid.Column::isVisible)
                .map(Grid.Column::getKey)
                .collect(Collectors.toList());
        logger.info("Colunas visíveis após configuração para gridId {}: {}", gridId, visibleColumns);
        logger.debug("Filtros adicionados ao cabeçalho com sucesso para gridId: {}", gridId);
        grid.getDataProvider().refreshAll();
    }

    private void applyFilters() {
        List<T> filteredItems = items.stream()
                .filter(item -> {
                    for (Map.Entry<String, Set<String>> filter : activeFilters.entrySet()) {
                        String filterKey = filter.getKey();
                        Set<String> filterValues = filter.getValue();
                        if (filterValues == null || filterValues.isEmpty()) {
                            continue;
                        }
                        ColumnConfig<T> cfg = columnConfigs.stream()
                                .filter(c -> c.column.getKey().equals(filterKey))
                                .findFirst()
                                .orElse(null);
                        if (cfg == null) continue;
                        Object value = cfg.valueExtractor.apply(item);
                        if (value == null || !filterValues.contains(String.valueOf(value))) {
                            return false;
                        }
                    }
                    return true;
                })
                .collect(Collectors.toList());

        logger.info("Itens após aplicar filtros para gridId {}: {}", gridId, filteredItems.size());
        if (filteredItems.isEmpty() && !activeFilters.isEmpty()) {
            logger.warn("Nenhum item corresponde aos filtros aplicados para gridId {}. Filtros: {}", gridId, activeFilters);
        }

        grid.setItems(filteredItems);
        filtersChanged = true;
        notifyFilterChange();
    }

    private String mapTextAlignToJustifyContent(String textAlign) {
        switch (textAlign.toLowerCase()) {
            case "left":
                return "flex-start";
            case "right":
                return "flex-end";
            case "center":
                return "center";
            default:
                return "flex-start";
        }
    }

    private void updateFilterRowHighlight() {
        logger.debug("Atualizando destaque na linha de filtro para gridId: {}", gridId);
        HeaderRow filterRow = grid.getHeaderRows().stream()
                .filter(row -> row.getCells().stream().anyMatch(cell -> cell.getComponent() instanceof MultiSelectComboBox))
                .findFirst()
                .orElse(null);

        if (filterRow == null) {
            logger.warn("Linha de filtro não encontrada para gridId: {}", gridId);
            return;
        }

        for (ColumnConfig<T> config : columnConfigs) {
            Grid.Column<T> column = config.column;
            String columnKey = column.getKey();
            HeaderRow.HeaderCell filterCell = filterRow.getCell(column);
            if (filterCell != null && filterCell.getComponent() != null) {
                Component component = filterCell.getComponent();
                if (component instanceof MultiSelectComboBox) {
                    @SuppressWarnings("unchecked")
                    MultiSelectComboBox<String> comboBox = (MultiSelectComboBox<String>) component;
                    boolean hasFilter = activeFilters.containsKey(columnKey) && activeFilters.get(columnKey) != null && !activeFilters.get(columnKey).isEmpty();
                    if (hasFilter) {
                        comboBox.getStyle()
                                .set("background-color", "var(--lumo-primary-color-10pct)")
                                .set("border", "1px solid var(--lumo-primary-color)");
                    } else {
                        comboBox.getStyle()
                                .remove("background-color")
                                .remove("border");
                    }
                }
            }
        }
    }

    private void abrirDialogoConfiguracaoColunas(List<ColumnConfig<T>> columnConfigs) {
        logger.info("Abrindo diálogo de configuração de colunas para gridId: {}", gridId);
        Dialog dialog = new Dialog();
        dialog.setModal(true);
        dialog.setWidth("300px");

        VerticalLayout layout = new VerticalLayout();
        layout.setPadding(false);
        layout.setSpacing(true);

        List<Checkbox> columnCheckboxes = new ArrayList<>();
        for (ColumnConfig<T> config : columnConfigs) {
            Grid.Column<T> column = config.column;
            Checkbox checkbox = new Checkbox(config.header, column.isVisible());
            checkbox.addValueChangeListener(event -> {
                logger.debug("Visibilidade da coluna {} alterada para {} em gridId: {}", config.header, event.getValue(), gridId);
                column.setVisible(event.getValue());
                visibilityChanged = true;
                grid.getDataProvider().refreshAll();
                saveChanges();
            });
            columnCheckboxes.add(checkbox);
            layout.add(checkbox);
        }

        Button selectAllButton = new Button("Selecionar Todos", event -> {
            logger.debug("Botão 'Selecionar Todos' clicado para gridId: {}", gridId);
            for (Checkbox checkbox : columnCheckboxes) {
                checkbox.setValue(true);
                Grid.Column<T> column = columnConfigs.get(columnCheckboxes.indexOf(checkbox)).column;
                column.setVisible(true);
            }
            visibilityChanged = true;
            grid.getDataProvider().refreshAll();
            saveChanges();
        });
        layout.add(selectAllButton);

        Button fecharButton = new Button("Fechar", event -> dialog.close());
        layout.add(fecharButton);

        dialog.add(layout);
        dialog.open();
    }

    private void notifyFilterChange() {
        logger.debug("Notificando mudança de filtros para gridId: {}", gridId);
        if (filterChangeListener != null) {
            Map<String, String> filterMap = activeFilters.entrySet().stream()
                    .filter(entry -> entry.getValue() != null && !entry.getValue().isEmpty())
                    .collect(Collectors.toMap(
                            Map.Entry::getKey,
                            entry -> String.join("-", entry.getValue())
                    ));
            filterChangeListener.accept(filterMap);
        }
    }

    public Component getLayout() {
        return layoutRaiz;
    }

    public static class ColumnConfig<T> {
        private Grid.Column<T> column;
        private final String header;
        private final Function<T, Object> valueExtractor;
        private final GridColumnConfig gridColumnConfig;

        public ColumnConfig(Grid.Column<T> column, String header, Function<T, Object> valueExtractor, GridColumnConfig gridColumnConfig) {
            this.column = column;
            this.header = header;
            this.valueExtractor = valueExtractor;
            this.gridColumnConfig = gridColumnConfig;
        }

        public Grid.Column<T> getColumn() {
            return column;
        }

        public String getHeader() {
            return header;
        }

        public Function<T, Object> getValueExtractor() {
            return valueExtractor;
        }

        public GridColumnConfig getGridColumnConfig() {
            return gridColumnConfig;
        }

        public void setColumn(Grid.Column<T> column) {
            this.column = column;
        }

        public void setProperty(String property) {
            // Método necessário para compatibilidade com AbstractGridView
        }

        public void setVisible(boolean visible) {
            column.setVisible(visible);
        }
    }
}