package com.exemplo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class GridColumnConfigService {

    private static final Logger logger = LoggerFactory.getLogger(GridColumnConfigService.class);

    // Mapa para armazenar configurações por class_name e usuario
    private final Map<String, Map<String, Map<String, GridColumnConfig>>> columnConfigsByClassNameAndUser = new HashMap<>();

    @Autowired
    private ColumnConfigRepository columnConfigRepository;

    public GridColumnConfigService() {
    }

    @PostConstruct
    public void init() {
        loadConfig();
    }

    private void loadConfig() {
        try {
            logger.info("Iniciando carregamento de configurações de colunas do banco de dados");
            List<ColumnConfigEntity> entities = columnConfigRepository.findAll();

            if (entities.isEmpty()) {
                logger.warn("Nenhuma coluna encontrada na tabela column_config. Verifique se a tabela contém dados e se o esquema/catálogo estão corretos.");
                return;
            }

            // Limpar o mapa antes de recarregar
            columnConfigsByClassNameAndUser.clear();

            logger.debug("Total de configurações encontradas na tabela column_config: {}", entities.size());
            for (ColumnConfigEntity entity : entities) {
                String className = entity.getClassName();
                String usuario = entity.getUsuario() != null ? entity.getUsuario() : "default";
                String key = entity.getFieldName().trim().toLowerCase();

                GridColumnConfig columnConfig = new GridColumnConfig();
                columnConfig.setField(entity.getFieldName());
                columnConfig.setHeader(entity.getHeader() != null ? entity.getHeader() : entity.getFieldName());
                columnConfig.setVisible("1".equals(entity.getVisible()));
                columnConfig.setWidth(entity.getWidth() != null ? entity.getWidth() : "100px");
                columnConfig.setType(entity.getDataType() != null ? entity.getDataType() : "STRING");
                columnConfig.setStyle(entity.getStyle() != null ? entity.getStyle() : "");
                columnConfig.setFilterType(entity.getFilterType() != null ? entity.getFilterType() : "EQUALS");

                columnConfigsByClassNameAndUser
                        .computeIfAbsent(className, k -> new HashMap<>())
                        .computeIfAbsent(usuario, k -> new HashMap<>())
                        .put(key, columnConfig);

                logger.debug("Configuração carregada: class_name={}, usuario={}, field={}, header={}, visible={}, width={}",
                        className, usuario, key, columnConfig.getHeader(), columnConfig.isVisible(), columnConfig.getWidth());
            }
            logger.info("Configurações carregadas com sucesso. Total de class_names: {}", columnConfigsByClassNameAndUser.size());
        } catch (Exception e) {
            logger.error("Erro ao carregar configurações de colunas do banco de dados: {}", e.getMessage(), e);
            throw new RuntimeException("Falha ao carregar configurações de colunas", e);
        }
    }

    public void reloadConfig() {
        logger.info("Recarregando configurações de colunas do banco de dados");
        loadConfig();
    }

    public GridColumnConfig getColumnConfig(String field) {
        return getColumnConfig(null, null, field);
    }

    public GridColumnConfig getColumnConfig(String className, String usuario, String field) {
        if (field == null) {
            return null;
        }
        String key = field.trim().toLowerCase();
        GridColumnConfig config = null;

        if (className != null && usuario != null) {
            Map<String, Map<String, GridColumnConfig>> classConfigs = columnConfigsByClassNameAndUser.get(className);
            if (classConfigs != null) {
                Map<String, GridColumnConfig> userConfigs = classConfigs.get(usuario);
                if (userConfigs != null) {
                    config = userConfigs.get(key);
                }
            }
        }

        if (config == null && className != null) {
            Map<String, Map<String, GridColumnConfig>> classConfigs = columnConfigsByClassNameAndUser.get(className);
            if (classConfigs != null) {
                Map<String, GridColumnConfig> userConfigs = classConfigs.get("default");
                if (userConfigs != null) {
                    config = userConfigs.get(key);
                }
            }
        }

        if (config == null && usuario != null) {
            Map<String, Map<String, GridColumnConfig>> defaultConfigs = columnConfigsByClassNameAndUser.get("default");
            if (defaultConfigs != null) {
                Map<String, GridColumnConfig> userConfigs = defaultConfigs.get(usuario);
                if (userConfigs != null) {
                    config = userConfigs.get(key);
                }
            }
        }

        if (config == null) {
            Map<String, Map<String, GridColumnConfig>> defaultConfigs = columnConfigsByClassNameAndUser.get("default");
            if (defaultConfigs != null) {
                Map<String, GridColumnConfig> userConfigs = defaultConfigs.get("default");
                if (userConfigs != null) {
                    config = userConfigs.get(key);
                }
            }
        }

        if (config == null) {
            logger.warn("Configuração não encontrada para o campo: {} (class_name: {}, usuario: {})",
                    field, className != null ? className : "default", usuario != null ? usuario : "default");
        } else {
            logger.debug("Configuração encontrada para o campo {} (class_name: {}, usuario: {}): header={}, visible={}, width={}",
                    field, className != null ? className : "default", usuario != null ? usuario : "default",
                    config.getHeader(), config.isVisible(), config.getWidth());
        }
        return config;
    }
}