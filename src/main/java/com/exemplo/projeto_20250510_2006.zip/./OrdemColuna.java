package com.exemplo;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Objects;

@Entity
@Table(name = "ordem_coluna")
@IdClass(OrdemColunaId.class)
public class OrdemColuna {

    @Id
    @Column(name = "usuario")
    private String usuario;

    @Id
    @Column(name = "view_id")
    private String viewId;

    @Column(name = "ordem_colunas")
    private String ordemColunas;

    public OrdemColuna() {}

    public OrdemColuna(String usuario, String viewId, String ordemColunas) {
        this.usuario = usuario;
        this.viewId = viewId;
        this.ordemColunas = ordemColunas;
    }

    public String getUsuario() { return usuario; }
    public void setUsuario(String usuario) { this.usuario = usuario; }

    public String getViewId() { return viewId; }
    public void setViewId(String viewId) { this.viewId = viewId; }

    public String getOrdemColunas() { return ordemColunas; }
    public void setOrdemColunas(String ordemColunas) { this.ordemColunas = ordemColunas; }
}

class OrdemColunaId implements Serializable {
    private String usuario;
    private String viewId;

    public OrdemColunaId() {}

    public OrdemColunaId(String usuario, String viewId) {
        this.usuario = usuario;
        this.viewId = viewId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof OrdemColunaId)) return false;
        OrdemColunaId that = (OrdemColunaId) o;
        return Objects.equals(usuario, that.usuario) &&
               Objects.equals(viewId, that.viewId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(usuario, viewId);
    }
}