package com.exemplo;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "empresa")
public class Empresa {
    @Id
    private Integer cd_empresa;
    private String server_name;
    private String database_name;
    private String ip_bd;
    private String porta_bd;
    private String usuario_bd;
    private String senha_bd;

    // Getters e Setters
    public Integer getCd_empresa() { return cd_empresa; }
    public void setCd_empresa(Integer cd_empresa) { this.cd_empresa = cd_empresa; }

    public String getServer_name() { return server_name; }
    public void setServer_name(String server_name) { this.server_name = server_name; }

    public String getDatabase_name() { return database_name; }
    public void setDatabase_name(String database_name) { this.database_name = database_name; }

    public String getIp_bd() { return ip_bd; }
    public void setIp_bd(String ip_bd) { this.ip_bd = ip_bd; }

    public String getPorta_bd() { return porta_bd; }
    public void setPorta_bd(String porta_bd) { this.porta_bd = porta_bd; }

    public String getUsuario_bd() { return usuario_bd; }
    public void setUsuario_bd(String usuario_bd) { this.usuario_bd = usuario_bd; }

    public String getSenha_bd() { return senha_bd; }
    public void setSenha_bd(String senha_bd) { this.senha_bd = senha_bd; }

    // Métodos usados no DynamicDataSourceSwitcher
    public String getServerName() { return server_name; }
    public String getNomeBanco() { return database_name; }
    public String getIpBd() { return ip_bd; }
    public String getPortaBd() { return porta_bd; }
    public String getUsuarioBd() { return usuario_bd; }
    public String getSenhaBd() { return senha_bd; }
    public Integer getCdEmpresa() { return cd_empresa; }
}