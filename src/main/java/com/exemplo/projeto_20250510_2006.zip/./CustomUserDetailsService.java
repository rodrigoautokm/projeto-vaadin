package com.exemplo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    @Autowired
    private UsuarioAcessoRepository usuarioAcessoRepository;

    @Autowired
    private EmpresaRepository empresaRepository;

    @Autowired
    private EmpresaAwareService empresaAwareService;

    @Autowired
    private ConfigurableApplicationContext context;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        // Buscar o usuário no banco de dados
        Optional<UsuarioAcesso> usuarioOptional = usuarioAcessoRepository.findByUsuario(username);
        if (usuarioOptional.isEmpty()) {
            throw new UsernameNotFoundException("Usuário não encontrado: " + username);
        }

        UsuarioAcesso usuario = usuarioOptional.get();

        // Obter o cdEmpresa do usuário
        Short cdEmpresa = usuario.getCdEmpresa();
        if (cdEmpresa == null) {
            throw new UsernameNotFoundException("Usuário não associado a uma empresa: " + username);
        }

        // Atualizar o cdEmpresa no EmpresaAwareService
        empresaAwareService.setCdEmpresa(cdEmpresa);

        // Buscar as informações da empresa no banco de dados
        Optional<Empresa> empresaOptional = empresaRepository.findByCd_empresa(cdEmpresa.intValue());
        if (empresaOptional.isEmpty()) {
            throw new UsernameNotFoundException("Empresa não encontrada para cdEmpresa: " + cdEmpresa);
        }

        Empresa empresa = empresaOptional.get();
        DynamicDataSourceSwitcher switcher = context.getBean(DynamicDataSourceSwitcher.class);
        switcher.switchTo(empresa);

        // Criar e retornar o UserDetails
        String[] roles = usuario.getAdmin() != null && "S".equalsIgnoreCase(usuario.getAdmin()) ? new String[]{"ADMIN"} : new String[]{"USER"};
        return User.withUsername(username)
                .password(usuario.getSenha()) // A senha já está codificada com BCrypt
                .roles(roles)
                .build();
    }
}