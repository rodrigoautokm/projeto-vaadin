package com.exemplo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class UsuarioAcessoService {
    private static final Logger logger = LoggerFactory.getLogger(UsuarioAcessoService.class);

    private final UsuarioAcessoRepository usuarioAcessoRepository;
    private final PasswordEncoder passwordEncoder;

    public UsuarioAcessoService(UsuarioAcessoRepository usuarioAcessoRepository, PasswordEncoder passwordEncoder) {
        this.usuarioAcessoRepository = usuarioAcessoRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @PostConstruct
    public void init() {
        logger.info("Inicializando UsuarioAcessoService...");
        try {
            logger.info("Verificando se o usuário 'admin' existe...");
            Optional<UsuarioAcesso> adminOpt = usuarioAcessoRepository.findByUsuario("admin");
            if (adminOpt.isEmpty()) {
                logger.info("Usuário 'admin' não encontrado. Criando...");
                createUsuarioAcesso("admin", "admin123", "S");
            } else {
                UsuarioAcesso admin = adminOpt.get();
                logger.info("Usuário 'admin' já existe. Username: '{}', Id: '{}'", admin.getUsuario(), admin.getId());
            }
            logAllUsers();
        } catch (Exception e) {
            logger.error("Erro ao inicializar UsuarioAcessoService: {}", e.getMessage(), e);
        }
    }

    @Transactional
    public void createUsuarioAcesso(String usuario, String senha, String admin) {
        logger.info("Criando usuário: '{}'", usuario);
        try {
            UsuarioAcesso user = new UsuarioAcesso();
            user.setUsuario(usuario);
            user.setSenha(passwordEncoder.encode(senha));
            user.setDataCriacao(Timestamp.valueOf(LocalDateTime.now()));
            user.setDataAtualizacao(Timestamp.valueOf(LocalDateTime.now()));
            user.setAdmin(admin);
            usuarioAcessoRepository.save(user);
            logger.info("Usuário criado com sucesso: '{}'", usuario);
        } catch (Exception e) {
            logger.error("Erro ao criar usuário '{}': {}", usuario, e.getMessage(), e);
            throw new RuntimeException("Falha ao criar usuário: " + e.getMessage(), e);
        }
    }

    @Transactional(readOnly = true)
    public void logAllUsers() {
        logger.info("Listando todos os usuários na tabela 'usuario_acesso':");
        try {
            Iterable<UsuarioAcesso> allUsers = usuarioAcessoRepository.findAll();
            if (!allUsers.iterator().hasNext()) {
                logger.warn("Nenhum usuário encontrado na tabela 'usuario_acesso'.");
            } else {
                allUsers.forEach(user -> logger.info(" - Username: '{}', Id: '{}', Admin: '{}'", 
                    user.getUsuario(), user.getId(), user.getAdmin()));
            }
        } catch (Exception e) {
            logger.error("Erro ao listar usuários existentes: {}", e.getMessage(), e);
        }
    }

@PostConstruct
public void testPassword() {
    logger.info("Testando senha para admin...");
    Optional<UsuarioAcesso> adminOpt = usuarioAcessoRepository.findByUsuario("admin");
    if (adminOpt.isPresent()) {
        String storedPassword = adminOpt.get().getSenha();
        boolean matches = passwordEncoder.matches("admin123", storedPassword);
        logger.info("Senha 'admin123' corresponde ao hash '{}'? {}", storedPassword, matches);
    } else {
        logger.warn("Usuário admin não encontrado para teste de senha.");
    }
}

    @Transactional(readOnly = true)
    public boolean authenticate(String usuario, String senha) {
        logger.info("Autenticando usuário: '{}', senha fornecida: '{}'", usuario, senha);
        try {
            Optional<UsuarioAcesso> userOpt = usuarioAcessoRepository.findByUsuario(usuario);
            logger.info("Resultado da busca: usuário encontrado? {}", userOpt.isPresent());
            if (userOpt.isPresent()) {
                UsuarioAcesso user = userOpt.get();
                logger.info("Senha armazenada: {}", user.getSenha());
                boolean matches = passwordEncoder.matches(senha, user.getSenha());
                logger.info("Senha corresponde? {}", matches);
                if (matches) {
                    logger.info("Autenticação bem-sucedida para o usuário: '{}'", usuario);
                    return true;
                } else {
                    logger.warn("Senha incorreta para o usuário: '{}'", usuario);
                    return false;
                }
            } else {
                logger.warn("Usuário não encontrado: '{}'", usuario);
                logAllUsers();
                return false;
            }
        } catch (Exception e) {
            logger.error("Erro ao autenticar usuário '{}': {}", usuario, e.getMessage(), e);
            return false;
        }
    }

    // Método necessário para o UserDetailsService
    public Optional<UsuarioAcesso> findByUsuario(String usuario) {
        return usuarioAcessoRepository.findByUsuario(usuario);
    }
}