package com.exemplo;

import com.exemplo.EmpresaAwareService;
import com.vaadin.flow.component.html.H1;
import com.vaadin.flow.component.html.Paragraph;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import org.springframework.beans.factory.annotation.Autowired;

import javax.annotation.PostConstruct;
import java.util.Optional;

@Route(value = "", layout = MainLayout.class)
@PageTitle("Página Inicial")
public class MainView extends VerticalLayout {

    @Autowired
    private EmpresaAwareService empresaAwareService;

    @Autowired
    private EmpresaRepository empresaRepository;

    public MainView() {
        setSpacing(true);
        setPadding(true);
        add(new H1("Bem-vindo à Minha Aplicação Vaadin!"));
    }

    @PostConstruct
    public void init() {
        try {
            Short cdEmpresa = getCdEmpresa();
            if (cdEmpresa != null) {
                Optional<Empresa> empresaOptional = empresaRepository.findByCd_empresa(cdEmpresa.intValue());
                if (empresaOptional.isEmpty()) {
                    add(new Paragraph("Empresa não encontrada para o código: " + cdEmpresa));
                    return;
                }

                Empresa empresa = empresaOptional.get();

                Paragraph info = new Paragraph("Conectado com sucesso usando:");
                Paragraph ip = new Paragraph("IP: " + empresa.getIpBd());
                Paragraph porta = new Paragraph("Porta: " + empresa.getPortaBd());
                Paragraph usuario = new Paragraph("Usuário: " + empresa.getUsuarioBd());
                Paragraph senha = new Paragraph("Senha: " + empresa.getSenhaBd());
                Paragraph servername = new Paragraph("ServerName: " + empresa.getServerName());
                Paragraph banco = new Paragraph("Banco: " + empresa.getNomeBanco());

                add(info, ip, porta, usuario, senha, servername, banco);
                Notification.show("Conexão obtida com sucesso!", 3000, Notification.Position.TOP_CENTER);
            } else {
                add(new Paragraph("Empresa não encontrada para o código: " + cdEmpresa));
            }

        } catch (Exception e) {
            add(new Paragraph("Erro ao obter dados de conexão: " + e.getMessage()));
            Notification.show("Erro ao conectar: " + e.getMessage(), 5000, Notification.Position.TOP_CENTER);
        }
    }

    private Short getCdEmpresa() {
        try {
            return empresaAwareService.getCdEmpresa();
        } catch (Exception e) {
            Notification.show("Erro ao identificar usuário logado.");
            return null;
        }
    }
}