package com.exemplo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.transaction.PlatformTransactionManager;

import javax.sql.DataSource;
import java.util.HashMap;
import java.util.Map;

@Configuration
@EnableJpaRepositories(
    basePackages = "com.exemplo",
    entityManagerFactoryRef = "entityManagerFactory",
    transactionManagerRef = "transactionManager"
)
public class DynamicDataSourceConfig {

    @Autowired
    private ConfigurableApplicationContext context;

    @Autowired
    private EmpresaConnectionManager empresaConnectionManager;

    @Bean
    @Primary
    public DataSource dataSource() {
        AbstractRoutingDataSource routingDataSource = new AbstractRoutingDataSource() {
            @Override
            protected Object determineCurrentLookupKey() {
                try {
                    CustomUserDetails userDetails = (CustomUserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
                    Short cdEmpresaShort = userDetails.getCdEmpresa();
                    Integer cdEmpresa = cdEmpresaShort != null ? cdEmpresaShort.intValue() : 1;
                    System.out.println("Determinando cdEmpresa para DataSource: " + cdEmpresa);
                    return cdEmpresa;
                } catch (Exception e) {
                    System.out.println("Erro ao determinar cdEmpresa: " + e.getMessage());
                    return 1; // Fallback para empresa padrão
                }
            }
        };

        Map<Object, Object> targetDataSources = new HashMap<>();
        Integer defaultCdEmpresa = 1;
        try {
            // Configurar um DataSource padrão inicial usando os valores do application.properties
            Empresa empresaPadrao = new Empresa();
            empresaPadrao.setCd_empresa(defaultCdEmpresa);
            empresaPadrao.setServer_name("autokm");
            empresaPadrao.setDatabase_name("autokm");
            empresaPadrao.setIp_bd("10.0.14.130");
            empresaPadrao.setPorta_bd("2688");
            empresaPadrao.setUsuario_bd("dbo");
            empresaPadrao.setSenha_bd("dircri17");

            // Configurar o DataSource inicial usando o EmpresaConnectionManager
            EmpresaConnectionManager.configure(empresaPadrao);

            DataSource defaultDataSource = empresaConnectionManager.getDataSourceForEmpresa(defaultCdEmpresa);
            if (defaultDataSource == null) {
                throw new IllegalStateException("DataSource para a empresa padrão (" + defaultCdEmpresa + ") é nulo!");
            }
            targetDataSources.put(defaultCdEmpresa, defaultDataSource);
            System.out.println("DataSources configurados: " + targetDataSources.keySet());
        } catch (Exception e) {
            System.out.println("Erro ao configurar DataSources: " + e.getMessage());
            throw new RuntimeException("Falha ao configurar DataSources", e);
        }

        routingDataSource.setTargetDataSources(targetDataSources);
        routingDataSource.setDefaultTargetDataSource(targetDataSources.get(defaultCdEmpresa));
        routingDataSource.afterPropertiesSet();

        return routingDataSource;
    }

    @Bean(name = "entityManagerFactory")
    public LocalContainerEntityManagerFactoryBean entityManagerFactory() {
        LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
        em.setDataSource(dataSource());
        em.setPackagesToScan("com.exemplo");
        em.setJpaVendorAdapter(new HibernateJpaVendorAdapter());

        Map<String, Object> properties = new HashMap<>();
        // Usar um dialeto compatível com Sybase SQL Anywhere
        properties.put("hibernate.dialect", "org.hibernate.dialect.SybaseDialect"); // Ajustado para um dialeto genérico Sybase
        properties.put("hibernate.hbm2ddl.auto", "none");
        properties.put("hibernate.show_sql", true);
        properties.put("hibernate.format_sql", true);
        properties.put("hibernate.connection.charSet", "ISO-8859-1");
        properties.put("hibernate.connection.characterEncoding", "ISO-8859-1");
        properties.put("hibernate.connection.useUnicode", "false");
        properties.put("hibernate.connection.catalog", "autokm");
        properties.put("hibernate.jdbc.batch_versioned_data", "false");
        properties.put("hibernate.physical_naming_strategy", "org.hibernate.boot.model.naming.PhysicalNamingStrategyStandardImpl");
        properties.put("hibernate.implicit_naming_strategy", "org.hibernate.boot.model.naming.ImplicitNamingStrategyComponentPathImpl");
        em.setJpaPropertyMap(properties);

        System.out.println("Configurando entityManagerFactory...");
        return em;
    }

    @Bean(name = "transactionManager")
    public PlatformTransactionManager transactionManager() {
        JpaTransactionManager transactionManager = new JpaTransactionManager();
        transactionManager.setEntityManagerFactory(entityManagerFactory().getObject());
        System.out.println("Configurando transactionManager...");
        return transactionManager;
    }

    @Bean
    public DynamicDataSourceSwitcher dynamicDataSourceSwitcher() {
        return new DynamicDataSourceSwitcher(context);
    }
}