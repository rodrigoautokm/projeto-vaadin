package com.exemplo;

import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import org.springframework.beans.factory.annotation.Autowired;


@PageTitle("Marcas")
@Route(value = "marcas", layout = MainLayout.class)
public class MarcaView extends AbstractGridView<Marca> {

    @Autowired
    public MarcaView(MarcaRepository marcaRepository) {
        super("Marcas", "marcas", marcaRepository::findAll);
    }

    @Override
    public Class<Marca> getEntityClass() {
        return Marca.class;
    }
}
