package com.exemplo;

import javax.persistence.*;

@Entity
@Table(name = "visibilidade_coluna") // Especifica o nome exato da tabela no banco
@IdClass(VisibilidadeColunaId.class)
public class VisibilidadeColuna {

    @Id
    @Column(name = "usuario")
    private String usuario;

    @Id
    @Column(name = "view_id")
    private String viewId;

    @Id
    @Column(name = "coluna")
    private String coluna;

    @Column(name = "visivel")
    private String visivel; // 'S' ou 'N'

    public VisibilidadeColuna() {}

    public VisibilidadeColuna(String usuario, String viewId, String coluna, boolean visivel) {
        this.usuario = usuario;
        this.viewId = viewId;
        this.coluna = coluna;
        this.visivel = visivel ? "S" : "N";
    }

    public String getUsuario() { return usuario; }
    public void setUsuario(String usuario) { this.usuario = usuario; }

    public String getViewId() { return viewId; }
    public void setViewId(String viewId) { this.viewId = viewId; }

    public String getColuna() { return coluna; }
    public void setColuna(String coluna) { this.coluna = coluna; }

    public String getVisivel() { return visivel; }
    public void setVisivel(String visivel) { this.visivel = visivel; }

    public boolean isVisivel() {
        return "S".equalsIgnoreCase(visivel);
    }
}