package com.exemplo;

import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;

public class GridColumnConfig {

    private String field;
    private String header;
    private String type;
    private String width;
    private String style;
	private String alias;	
    private String filterType;
    private boolean visible;

    private String dropdownValues; // <- carregado do banco (ex: J=Juridica;F=Fisica)
    private Map<String, String> dropdownValueMap;

    // Getters e Setters
    public String getField() {
        return field;
    }

 public String getAlias() {
        return alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }
	
    public void setField(String field) {
        this.field = field;
    }

    public String getHeader() {
        return header;
    }

    public void setHeader(String header) {
        this.header = header;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getWidth() {
        return width;
    }

    public void setWidth(String width) {
        this.width = width;
    }

    public String getStyle() {
        return style;
    }

    public void setStyle(String style) {
        this.style = style;
    }

    public String getFilterType() {
        return filterType;
    }

    public void setFilterType(String filterType) {
        this.filterType = filterType;
    }

    public boolean isVisible() {
        return visible;
    }

    public void setVisible(boolean visible) {
        this.visible = visible;
    }

    public String getDropdownValues() {
        return dropdownValues;
    }

    public void setDropdownValues(String dropdownValues) {
        this.dropdownValues = dropdownValues;

        // Gera o mapa ao definir o valor
        if (dropdownValues != null && !dropdownValues.isEmpty()) {
            this.dropdownValueMap = Arrays.stream(dropdownValues.split(";"))
                .map(s -> s.split("=", 2))
                .filter(arr -> arr.length == 2)
                .collect(Collectors.toMap(arr -> arr[0], arr -> arr[1]));
        }
    }

    public Map<String, String> getDropdownValueMap() {
        return dropdownValueMap;
    }

    public void setDropdownValueMap(Map<String, String> dropdownValueMap) {
        this.dropdownValueMap = dropdownValueMap;
    }
}
