package com.exemplo;

import java.util.Map;

public class GridColumnConfigCadastro {

    private String field;
    private String header;
    private String type;
    private boolean required;
    private boolean editable;
    private boolean visible;
    private String dropdownEntity;
    private String dropdownValues;
    private Map<String, String> dropdownValueMap;
    private Integer width;
    private Integer scale;
    private String nestedColumns;

    public String getField() {
        return field;
    }

    public void setField(String field) {
        this.field = field;
    }

    public String getHeader() {
        return header;
    }

    public void setHeader(String header) {
        this.header = header;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public boolean isRequired() {
        return required;
    }

    public void setRequired(boolean required) {
        this.required = required;
    }

    public boolean isEditable() {
        return editable;
    }

    public void setEditable(boolean editable) {
        this.editable = editable;
    }

    public boolean isVisible() {
        return visible;
    }

    public void setVisible(boolean visible) {
        this.visible = visible;
    }

    public String getDropdownEntity() {
        return dropdownEntity;
    }

    public void setDropdownEntity(String dropdownEntity) {
        this.dropdownEntity = dropdownEntity;
    }

    public String getDropdownValues() {
        return dropdownValues;
    }

    public void setDropdownValues(String dropdownValues) {
        this.dropdownValues = dropdownValues;
    }

    public Map<String, String> getDropdownValueMap() {
        return dropdownValueMap;
    }

    public void setDropdownValueMap(Map<String, String> dropdownValueMap) {
        this.dropdownValueMap = dropdownValueMap;
    }

    public Integer getWidth() {
        return width;
    }

    public void setWidth(Integer width) {
        this.width = width;
    }

    public Integer getScale() {
        return scale;
    }

    public void setScale(Integer scale) {
        this.scale = scale;
    }

    public String getNestedColumns() {
        return nestedColumns;
    }

    public void setNestedColumns(String nestedColumns) {
        this.nestedColumns = nestedColumns;
    }
}