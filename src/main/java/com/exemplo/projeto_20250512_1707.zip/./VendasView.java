package com.exemplo;

import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.datepicker.DatePicker;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.html.H1;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.router.BeforeEnterEvent;
import com.vaadin.flow.router.Route;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@Route(value = "vendas", layout = MainLayout.class)
public class VendasView extends AbstractGridView<VendasItem> {

    private static final Logger logger = LoggerFactory.getLogger(VendasView.class);

    private final VendasService vendasService;
    private final GridColumnConfigService columnConfigService;
    private DatePicker dataInicioPicker;
    private DatePicker dataFimPicker;

    @Autowired
    public VendasView(VendasService vendasService, GridColumnConfigService columnConfigService) {
        super("Relatório de Vendas", "vendas", () -> new ArrayList<>());
        this.vendasService = vendasService;
        this.columnConfigService = columnConfigService;
    }

    @Override
    public Class<VendasItem> getEntityClass() {
        return VendasItem.class;
    }

    @Override
    public List<GridFilterUtil.ColumnConfig<VendasItem>> configureColumns() {
        logger.info("Configurando colunas da grid para VendasView");

        String[] fields = {
            "nr_pedido", "nm_cliente", "ds_produto", "qt_produto", "vl_unitario",
            "vl_desconto", "vl_custo", "dt_emissao", "situacao", "ds_grupo", "vl_total"
        };

        List<GridFilterUtil.ColumnConfig<VendasItem>> columnConfigs = new ArrayList<>();
        for (String field : fields) {
            GridColumnConfig config = columnConfigService.getColumnConfig(field);
            if (config == null) {
                logger.warn("Configuração não encontrada para o campo: {}. Usando configuração padrão.", field);
                config = new GridColumnConfig();
                config.setField(field);
                config.setHeader(field);
                config.setWidth("100px");
                config.setVisible(true);
                config.setType("STRING");
            }

            logger.debug("Configuração para o campo {}: header={}, visible={}, width={}, type={}, style={}",
                field, config.getHeader(), config.isVisible(), config.getWidth(), config.getType(), config.getStyle());

            if (config.isVisible()) {
                logger.debug("Adicionando coluna: {}", field);
                Grid.Column<VendasItem> column = grid.addColumn(item -> {
                    try {
                        switch (field) {
                            case "nr_pedido":
                                return item.getNrPedido();
                            case "nm_cliente":
                                return item.getNmCliente();
                            case "ds_produto":
                                return item.getDsProduto();
                            case "qt_produto":
                                return item.getQtProduto();
                            case "vl_unitario":
                                return item.getVlUnitario();
                            case "vl_desconto":
                                return item.getVlDesconto();
                            case "vl_custo":
                                return item.getVlCusto();
                            case "dt_emissao":
                                return item.getDtEmissao();
                            case "situacao":
                                return item.getSituacao();
                            case "ds_grupo":
                                return item.getDsGrupo();
                            case "vl_total":
                                return item.getVlTotal();
                            default:
                                logger.warn("Campo não reconhecido: {}", field);
                                return null;
                        }
                    } catch (Exception e) {
                        logger.error("Erro ao acessar o campo {} para o item de vendas: {}", field, item, e);
                        return null;
                    }
                }).setKey(field);

                column.setHeader(config.getHeader());
                column.setWidth(config.getWidth());
                column.setSortable(true);
                column.setVisible(true);
                column.setAutoWidth(false);

                logger.debug("Coluna {} configurada com largura: {}, visível: {}", field, config.getWidth(), column.isVisible());

                if (config.getStyle() != null && !config.getStyle().isEmpty()) {
                    String[] styleRules = config.getStyle().split(";");
                    for (String rule : styleRules) {
                        if (rule.trim().isEmpty()) continue;
                        String[] parts = rule.split(":");
                        if (parts.length == 2) {
                            String property = parts[0].trim();
                            String value = parts[1].trim();
                            column.getElement().getStyle().set(property, value);
                            logger.debug("Estilo aplicado à coluna {}: {}: {}", field, property, value);
                        }
                    }
                }

                GridFilterUtil.ColumnConfig<VendasItem> columnConfig = new GridFilterUtil.ColumnConfig<>(
                    column,
                    config.getHeader(),
                    item -> {
                        switch (field) {
                            case "nr_pedido":
                                return item.getNrPedido();
                            case "nm_cliente":
                                return item.getNmCliente();
                            case "ds_produto":
                                return item.getDsProduto();
                            case "qt_produto":
                                return item.getQtProduto() != null ? String.valueOf(item.getQtProduto()) : null;
                            case "vl_unitario":
                                return item.getVlUnitario() != null ? String.valueOf(item.getVlUnitario()) : null;
                            case "vl_desconto":
                                return item.getVlDesconto() != null ? String.valueOf(item.getVlDesconto()) : null;
                            case "vl_custo":
                                return item.getVlCusto() != null ? String.valueOf(item.getVlCusto()) : null;
                            case "dt_emissao":
                                return item.getDtEmissao();
                            case "situacao":
                                return item.getSituacao();
                            case "ds_grupo":
                                return item.getDsGrupo();
                            case "vl_total":
                                return item.getVlTotal() != null ? String.valueOf(item.getVlTotal()) : null;
                            default:
                                return null;
                        }
                    },
                    config
                );

                columnConfigs.add(columnConfig);
            } else {
                logger.debug("Coluna {} não adicionada (visível: false no XML)", field);
            }
        }

        logger.info("Total de colunas configuradas para columnConfigs: {}", columnConfigs.size());
        return columnConfigs;
    }

    @Override
    public void beforeEnter(BeforeEnterEvent event) {
        super.beforeEnter(event);
        configurarFiltros();
        atualizarGrid();
    }

    private void configurarFiltros() {
        logger.debug("Configurando filtros da VendasView");

        LocalDateTime inicio = LocalDateTime.now().minusMonths(1);
        LocalDateTime fim = LocalDateTime.now();
        dataInicioPicker = new DatePicker("Data Início");
        dataInicioPicker.setValue(inicio.toLocalDate());
        dataInicioPicker.getStyle()
            .set("margin-right", "10px");

        dataFimPicker = new DatePicker("Data Fim");
        dataFimPicker.setValue(fim.toLocalDate());
        dataFimPicker.getStyle()
            .set("margin-right", "10px");

        Button gerarButton = new Button("Gerar");
        gerarButton.getStyle()
            .set("margin", "0");
        logger.debug("Configurando botão 'Gerar'");
        gerarButton.addClickListener(event -> {
            logger.info("Botão 'Gerar' foi clicado!");
            Notification.show("Botão 'Gerar' clicado!", 2000, Notification.Position.TOP_CENTER);
            atualizarGrid();
        });

        HorizontalLayout filtroLayout = new HorizontalLayout(dataInicioPicker, dataFimPicker, gerarButton);
        filtroLayout.setAlignItems(Alignment.BASELINE);
        filtroLayout.setSpacing(false);
        filtroLayout.addClassName("filtro-layout");
        filtroLayout.getStyle()
            .set("margin", "0 0 10px 0")
            .set("padding", "0");
        logger.debug("Adicionando layout de filtros à VendasView");
        addFilters(filtroLayout);
    }

    private void atualizarGrid() {
        logger.info("Método atualizarGrid() chamado");
        LocalDate dataInicio = dataInicioPicker.getValue();
        LocalDate dataFim = dataFimPicker.getValue();

        if (dataInicio == null || dataFim == null) {
            logger.warn("Datas de início ou fim não selecionadas");
            Notification.show("Selecione as datas de início e fim.", 3000, Notification.Position.MIDDLE);
            return;
        }

        LocalDateTime inicio = dataInicio.atStartOfDay();
        LocalDateTime fim = dataFim.atTime(23, 59, 59, 999000000);

        logger.info("Executando consulta para o período: {} a {}", inicio, fim);
        List<VendasItem> novosItens = vendasService.executarRelVendas(
                1, formatarData(inicio), formatarData(fim), 0, 0, 0, 0, 0, 0, 0, 0, 0, null, 0, "N", "", 0, "S", "E", 0
        );

        if (novosItens == null || novosItens.isEmpty()) {
            logger.warn("Nenhum dado retornado para o período selecionado");
            novosItens = new ArrayList<>();
            Notification.show("Nenhum dado encontrado para o período selecionado.", 3000, Notification.Position.MIDDLE);
            novosItens.add(new VendasItem("123", "Cliente Teste", "Produto Teste", 10.0, 100.0, 5.0, 80.0, "2023-10-01", "Aprovado", "Grupo Teste"));
            logger.info("Adicionados dados de teste ao grid após consulta vazia");
        } else {
            logger.info("Dados carregados: {} itens", novosItens.size());
            for (int i = 0; i < Math.min(5, novosItens.size()); i++) {
                VendasItem item = novosItens.get(i);
                logger.debug("Item {}: nr_pedido={}, nm_cliente={}, ds_produto={}, qt_produto={}, vl_unitario={}, vl_desconto={}, vl_custo={}, dt_emissao={}, situacao={}, ds_grupo={}, vl_total={}",
                    i, item.getNrPedido(), item.getNmCliente(), item.getDsProduto(), item.getQtProduto(),
                    item.getVlUnitario(), item.getVlDesconto(), item.getVlCusto(), item.getDtEmissao(),
                    item.getSituacao(), item.getDsGrupo(), item.getVlTotal());
            }
        }

        logger.debug("Atualizando itens no GridFilterUtil");
        updateData(novosItens);
        logger.info("Grid atualizado com sucesso");
    }

    private String formatarData(LocalDateTime data) {
        return data.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS"));
    }
}