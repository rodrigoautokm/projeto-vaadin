package com.exemplo;

import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.datepicker.DatePicker;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.router.BeforeEnterEvent;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.server.auth.AnonymousAllowed;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import javax.annotation.PostConstruct;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Route(value = "listagem-pedidos", layout = MainLayout.class)
@PageTitle("Listagem de Pedidos")
@AnonymousAllowed
public class ListagemPedidoView extends AbstractGridView<ListagemPedidoResult> {

    private static final Logger logger = LoggerFactory.getLogger(ListagemPedidoView.class);

    private final ListagemPedidoService listagemPedidoService;
    private final GridColumnConfigService columnConfigService;
    private DatePicker dataInicioPicker;
    private DatePicker dataFimPicker;
    private Button consultarButton;

    @Autowired
    public ListagemPedidoView(ListagemPedidoService listagemPedidoService, GridColumnConfigService columnConfigService) {
        super("Listagem de Pedidos", "listagem-pedidos", () -> new ArrayList<>());
        logger.info("Inicializando ListagemPedidoView");
        this.listagemPedidoService = listagemPedidoService;
        this.columnConfigService = columnConfigService;
    }

    @PostConstruct
    public void init() {
        dataInicioPicker = new DatePicker("Data Início");
        dataInicioPicker.setValue(LocalDate.now().withDayOfMonth(1));
        dataInicioPicker.getStyle()
            .set("margin-right", "10px");

        dataFimPicker = new DatePicker("Data Fim");
        dataFimPicker.setValue(LocalDate.now());
        dataFimPicker.getStyle()
            .set("margin-right", "10px");

        consultarButton = new Button("Consultar", event -> consultarPedidos());
        consultarButton.getStyle()
            .set("margin", "0");

        HorizontalLayout filtrosLayout = new HorizontalLayout(dataInicioPicker, dataFimPicker, consultarButton);
        addFilters(filtrosLayout);
    }

    @Override
    public void beforeEnter(BeforeEnterEvent event) {
        super.beforeEnter(event);
        items = new ArrayList<>();
        gridUtil.updateItems(items);
        consultarPedidos(); // Mover a chamada para afterNavigation
    }

    @Override
    public Class<ListagemPedidoResult> getEntityClass() {
        return ListagemPedidoResult.class;
    }

    @Override
    public List<GridFilterUtil.ColumnConfig<ListagemPedidoResult>> configureColumns() {
        logger.info("Configurando grid com GridFilterUtil");

        String[] fields = {
            "cd_empresa", "nr_pedido", "serie", "cd_empresa_venda", "dt_emissao", "cd_cliente", "nm_cliente",
            "vl_total", "vl_desconto_total", "situacao", "cd_funcionario", "nm_funcionario", "vl_frete",
            "vl_acrescimo_total", "nr_pedido_anterior", "cheque", "nm_usuario", "nr_nota", "serie_nota", "dt_faturamento"
        };

        List<GridFilterUtil.ColumnConfig<ListagemPedidoResult>> columnConfigs = new ArrayList<>();
        for (String field : fields) {
            GridColumnConfig config = columnConfigService.getColumnConfig(field);
            if (config == null) {
                logger.warn("Configuração não encontrada para o campo: {}. Usando configuração padrão.", field);
                config = new GridColumnConfig();
                config.setField(field);
                config.setHeader(field);
                config.setWidth("100px");
                config.setVisible(true);
                config.setType("STRING");
            }

            logger.debug("Configuração para o campo {}: header={}, visible={}, width={}, type={}, style={}",
                field, config.getHeader(), config.isVisible(), config.getWidth(), config.getType(), config.getStyle());

            if (config.isVisible()) {
                logger.debug("Adicionando coluna: {}", field);
                Grid.Column<ListagemPedidoResult> column = grid.addColumn(pedido -> {
                    try {
                        switch (field) {
                            case "cd_empresa":
                                return pedido.getCdEmpresa();
                            case "nr_pedido":
                                return pedido.getNrPedido();
                            case "serie":
                                return pedido.getSerie();
                            case "cd_empresa_venda":
                                return pedido.getCdEmpresaVenda();
                            case "dt_emissao":
                                return pedido.getDtEmissao();
                            case "cd_cliente":
                                return pedido.getCdCliente();
                            case "nm_cliente":
                                return pedido.getNmCliente();
                            case "vl_total":
                                return pedido.getVlTotal();
                            case "vl_desconto_total":
                                return pedido.getVlDescontoTotal();
                            case "situacao":
                                return pedido.getSituacao();
                            case "cd_funcionario":
                                return pedido.getCdFuncionario();
                            case "nm_funcionario":
                                return pedido.getNmFuncionario();
                            case "vl_frete":
                                return pedido.getVlFrete();
                            case "vl_acrescimo_total":
                                return pedido.getVlAcrescimoTotal();
                            case "nr_pedido_anterior":
                                return pedido.getNrPedidoAnterior();
                            case "cheque":
                                return pedido.getCheque();
                            case "nm_usuario":
                                return pedido.getNmUsuario();
                            case "nr_nota":
                                return pedido.getNrNota();
                            case "serie_nota":
                                return pedido.getSerieNota();
                            case "dt_faturamento":
                                return pedido.getDtFaturamento();
                            default:
                                logger.warn("Campo não reconhecido: {}", field);
                                return null;
                        }
                    } catch (Exception e) {
                        logger.error("Erro ao acessar o campo {} para o pedido: {}", field, pedido, e);
                        return null;
                    }
                }).setKey(field);

                column.setHeader(config.getHeader());
                column.setWidth(config.getWidth());
                column.setSortable(true);
                column.setVisible(true);
                column.setAutoWidth(false);

                if (config.getStyle() != null && !config.getStyle().isEmpty()) {
                    String[] styleRules = config.getStyle().split(";");
                    for (String rule : styleRules) {
                        if (rule.trim().isEmpty()) continue;
                        String[] parts = rule.split(":");
                        if (parts.length == 2) {
                            String property = parts[0].trim();
                            String value = parts[1].trim();
                            column.getElement().getStyle().set(property, value);
                            logger.debug("Estilo aplicado à coluna {}: {}: {}", field, property, value);
                        }
                    }
                }

                GridFilterUtil.ColumnConfig<ListagemPedidoResult> columnConfig = new GridFilterUtil.ColumnConfig<>(
                    column,
                    config.getHeader(),
                    pedido -> {
                        switch (field) {
                            case "cd_empresa":
                                return String.valueOf(pedido.getCdEmpresa());
                            case "nr_pedido":
                                return String.valueOf(pedido.getNrPedido());
                            case "serie":
                                return pedido.getSerie();
                            case "cd_empresa_venda":
                                return String.valueOf(pedido.getCdEmpresaVenda());
                            case "dt_emissao":
                                return pedido.getDtEmissao() != null ? pedido.getDtEmissao().toString() : null;
                            case "cd_cliente":
                                return String.valueOf(pedido.getCdCliente());
                            case "nm_cliente":
                                return pedido.getNmCliente();
                            case "vl_total":
                                return pedido.getVlTotal() != null ? pedido.getVlTotal().toString() : null;
                            case "vl_desconto_total":
                                return pedido.getVlDescontoTotal() != null ? pedido.getVlDescontoTotal().toString() : null;
                            case "situacao":
                                return pedido.getSituacao();
                            case "cd_funcionario":
                                return String.valueOf(pedido.getCdFuncionario());
                            case "nm_funcionario":
                                return pedido.getNmFuncionario();
                            case "vl_frete":
                                return pedido.getVlFrete() != null ? pedido.getVlFrete().toString() : null;
                            case "vl_acrescimo_total":
                                return pedido.getVlAcrescimoTotal() != null ? pedido.getVlAcrescimoTotal().toString() : null;
                            case "nr_pedido_anterior":
                                return String.valueOf(pedido.getNrPedidoAnterior());
                            case "cheque":
                                return pedido.getCheque();
                            case "nm_usuario":
                                return pedido.getNmUsuario();
                            case "nr_nota":
                                return String.valueOf(pedido.getNrNota());
                            case "serie_nota":
                                return pedido.getSerieNota();
                            case "dt_faturamento":
                                return pedido.getDtFaturamento() != null ? pedido.getDtFaturamento().toString() : null;
                            default:
                                return null;
                        }
                    },
                    config
                );

                columnConfigs.add(columnConfig);
            }
        }

        logger.info("Total de colunas configuradas: {}", grid.getColumns().size());

        if (grid.getColumns().size() < 2) {
            logger.warn("Número de colunas insuficiente para mesclagem. Adicionando colunas fictícias.");
            grid.addColumn(pedido -> "").setKey("dummy1").setHeader("").setVisible(false);
            grid.addColumn(pedido -> "").setKey("dummy2").setHeader("").setVisible(false);
        }

        grid.setPageSize(50);
        return columnConfigs;
    }

    private void consultarPedidos() {
        try {
            LocalDate dataInicio = dataInicioPicker.getValue();
            LocalDate dataFim = dataFimPicker.getValue();

            if (dataInicio == null || dataFim == null) {
                logger.warn("Datas de início ou fim não selecionadas");
                Notification.show("Preencha as datas corretamente.", 3000, Notification.Position.MIDDLE);
                return;
            }

            List<ListagemPedidoResult> pedidos = listagemPedidoService.consultar(
                Timestamp.valueOf(dataInicio.atStartOfDay()),
                Timestamp.valueOf(dataFim.atTime(23, 59, 59))
            );
            items = pedidos != null ? pedidos : new ArrayList<>();
            if (items.isEmpty()) {
                logger.warn("Nenhum pedido encontrado para o período selecionado");
                Notification.show("Nenhum pedido encontrado.", 3000, Notification.Position.MIDDLE);
            }
            updateData(items);
        } catch (Exception ex) {
            logger.error("Erro ao consultar pedidos", ex);
            Notification.show("Erro ao consultar pedidos: " + ex.getMessage(), 5000, Notification.Position.MIDDLE);
            updateData(new ArrayList<>());
        }
    }
}