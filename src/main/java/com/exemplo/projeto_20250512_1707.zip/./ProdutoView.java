package com.exemplo;

import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import org.springframework.beans.factory.annotation.Autowired;


@PageTitle("Produtos")
@Route(value = "produtos", layout = MainLayout.class)
public class ProdutoView extends AbstractGridView<Produto> {

    @Autowired
    public ProdutoView(ProdutoRepository produtoRepository) {
        super("Produtos", "produtos", produtoRepository::findAll);
    }

    @Override
    public Class<Produto> getEntityClass() {
        return Produto.class;
    }
}
