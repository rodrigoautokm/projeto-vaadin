package com.exemplo;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;
import java.util.Objects;

@Embeddable
public class SortConfigId implements Serializable {

    @Column(name = "usuario")
    private String usuario;

    @Column(name = "view_id")
    private String viewId;

    public SortConfigId() {}

    public SortConfigId(String usuario, String viewId) {
        this.usuario = usuario;
        this.viewId = viewId;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getViewId() {
        return viewId;
    }

    public void setViewId(String viewId) {
        this.viewId = viewId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof SortConfigId)) return false;
        SortConfigId that = (SortConfigId) o;
        return Objects.equals(usuario, that.usuario) &&
               Objects.equals(viewId, that.viewId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(usuario, viewId);
    }
}