package com.exemplo;

import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.spring.annotation.SpringComponent;
import com.vaadin.flow.spring.annotation.UIScope;
import org.springframework.beans.factory.annotation.Autowired;

@PageTitle("Clientes")
@Route(value = "clientes", layout = MainLayout.class)
@SpringComponent
@UIScope
public class ClienteView extends AbstractGridView<Cliente> {

    @Autowired
    public ClienteView(ClienteRepository clienteRepository) {
        super("Clientes", "clientes", clienteRepository::findAll);
    }

    @Override
    public Class<Cliente> getEntityClass() {
        return Cliente.class;
    }
}
