package com.exemplo;

import org.springframework.data.jpa.repository.JpaRepository;

public interface SortConfigRepository extends JpaRepository<SortConfig, SortConfigId> {
}