package com.exemplo;

import com.vaadin.flow.component.AttachEvent;
import com.vaadin.flow.component.DetachEvent;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.html.H1;
import com.vaadin.flow.component.html.Span;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.progressbar.ProgressBar;
import com.vaadin.flow.router.BeforeEnterEvent;
import com.vaadin.flow.router.BeforeEnterObserver;
import com.vaadin.flow.component.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import com.vaadin.flow.function.ValueProvider;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import java.util.function.Supplier;

public abstract class AbstractGridView<T> extends VerticalLayout implements BeforeEnterObserver {

    private static final Logger logger = LoggerFactory.getLogger(AbstractGridView.class);

    protected final String title;
    protected final String gridId;
    protected final Supplier<List<T>> dataSupplier;
    protected Grid<T> grid;
    protected GridFilterUtil<T> gridUtil;
    protected List<T> items;
    protected List<GridFilterUtil.ColumnConfig<T>> columnConfigs;

    private VerticalLayout loadingOverlay;
    private ProgressBar loadingBar;
    private Span loadingMessage;

    @Autowired
    protected GridColumnConfigService gridColumnConfigService;

    @Autowired
    protected GridColumnConfigCadastroService gridColumnConfigCadastroService;

    public AbstractGridView(String title, String gridId, Supplier<List<T>> dataSupplier) {
        this.title = title;
        this.gridId = gridId;
        this.dataSupplier = dataSupplier;

        setSizeFull();
        setPadding(false);
        setMargin(false);
        setSpacing(false);
        addClassName("abstract-grid-view");
        getStyle().set("position", "relative");

        H1 titleComponent = new H1(title);
        titleComponent.getStyle()
            .set("font-size", "24px")
            .set("margin", "10px 0 5px 0")
            .set("padding", "0");
        add(titleComponent);

        grid = new Grid<>((Class<T>) getEntityClass(), false);
        grid.getElement().getClassList().add("grid-container");
        grid.setHeight("100%");
        grid.setWidth("100%");

        initializeLoadingOverlay();
    }

    protected void initializeLoadingOverlay() {
        loadingOverlay = new VerticalLayout();
        loadingOverlay.setSizeFull();
        loadingOverlay.setJustifyContentMode(FlexComponent.JustifyContentMode.CENTER);
        loadingOverlay.setAlignItems(FlexComponent.Alignment.CENTER);
        loadingOverlay.getStyle().set("background-color", "rgba(255, 255, 255, 0.7)");
        loadingOverlay.getStyle().set("position", "absolute");
        loadingOverlay.getStyle().set("top", "0");
        loadingOverlay.getStyle().set("left", "0");
        loadingOverlay.getStyle().set("z-index", "999");

        loadingBar = new ProgressBar();
        loadingBar.setIndeterminate(true);
        loadingMessage = new Span("Carregando...");
        loadingOverlay.add(loadingBar, loadingMessage);
        loadingOverlay.setVisible(false);
        add(loadingOverlay);
    }

    @Override
    protected void onAttach(AttachEvent attachEvent) {
        super.onAttach(attachEvent);
        showLoadingOverlay(true);
        getUI().ifPresent(ui -> ui.access(() -> {
            try {
                this.columnConfigs = configureColumns();
                gridUtil = new GridFilterUtil<>(gridId, grid, columnConfigs, getUsuarioId(), getCdEmpresaUsuario());
                add(gridUtil.getLayout());
                carregarDados();
            } finally {
                showLoadingOverlay(false);
            }
        }));
    }

    @Override
    protected void onDetach(DetachEvent detachEvent) {
        super.onDetach(detachEvent);
    }

    protected void carregarDados() {
        try {
            showLoadingOverlay(true);
            this.items = dataSupplier.get();
            grid.setItems(items);
        } catch (Exception e) {
            logger.error("Erro ao carregar dados para " + title, e);
        } finally {
            showLoadingOverlay(false);
        }
    }

    protected void showLoadingOverlay(boolean visible) {
        loadingOverlay.setVisible(visible);
    }

    protected String getUsuarioId() {
        return SecurityContextHolder.getContext().getAuthentication().getName();
    }

    protected Integer getCdEmpresaUsuario() {
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if (principal instanceof CustomUserDetails) {
            Short cd = ((CustomUserDetails) principal).getCdEmpresa();
            return cd != null ? cd.intValue() : null;
        }
        return null;
    }

    /**
     * Constrói dinamicamente as colunas do grid com base nas configurações da tabela column_config.
     */
    

public List<GridFilterUtil.ColumnConfig<T>> configureColumns() {
    logger.info("Configurando colunas para {} com gridId={}", title, gridId);
    List<GridFilterUtil.ColumnConfig<T>> configs = new ArrayList<>();
    List<GridColumnConfig> configList = gridColumnConfigService.listar(gridId, getUsuarioId(), getCdEmpresaUsuario());

    for (GridColumnConfig c : configList) {
        if (!c.isVisible()) continue;
        String field = c.getField();
        String alias = c.getAlias();  // Agora você tem acesso ao alias

        try {
            // Usar alias se disponível, caso contrário, use o nome do campo
            String columnName = (alias != null && !alias.isEmpty()) ? alias : capitalize(field);

            // Obter o método getXxx da entidade
            java.lang.reflect.Method method = getEntityClass().getMethod("get" + capitalize(field));
            
            // Corrigido para ValueProvider
            ValueProvider<T, Object> extractor = item -> {
                try {
                    return method.invoke(item);
                } catch (Exception e) {
                    logger.error("Erro ao extrair valor do campo '{}': {}", field, e.getMessage());
                    return null;
                }
            };

            Grid.Column<T> column = grid.addColumn(extractor)
                                       .setHeader(columnName)  // Usando alias ou nome formatado
                                       .setKey(field);
            GridFilterUtil.ColumnConfig<T> config = new GridFilterUtil.ColumnConfig<>(column, columnName, extractor, c);
            configs.add(config);
        } catch (NoSuchMethodException e) {
            logger.warn("Método get{} não encontrado em {}", capitalize(field), getEntityClass().getSimpleName());
        }
    }

    return configs;
}

	
	
    private String capitalize(String field) {
        if (field == null || field.isEmpty()) return field;
        return field.substring(0, 1).toUpperCase() + field.substring(1);
    }

    public abstract Class<T> getEntityClass();

    @Override
    public void beforeEnter(BeforeEnterEvent event) {
        // Pode ser usado para lógica futura
    }

    public void addFilters(Component filtrosLayout) {
        add(filtrosLayout);
    }

    public void updateData(List<T> novaLista) {
        this.items = novaLista;
        if (gridUtil != null) {
            gridUtil.updateItems(novaLista);
        } else {
            grid.setItems(novaLista);
        }
    }
}
