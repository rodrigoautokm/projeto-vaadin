package com.exemplo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ColumnConfigRepository extends JpaRepository<ColumnConfigEntity, Integer> {

    List<ColumnConfigEntity> findAll();
}