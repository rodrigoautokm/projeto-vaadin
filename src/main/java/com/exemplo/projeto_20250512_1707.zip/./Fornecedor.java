package com.exemplo;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "fornecedor")
public class Fornecedor implements Serializable {

    @Id
    @Column(name = "cd_fornecedor")
    private Integer cdFornecedor;

    @Column(name = "nm_fornecedor")
    private String nmFornecedor;

    @Column(name = "nm_fantasia")
    private String nmFantasia;

    @Column(name = "nm_representante")
    private String nmRepresentante;

    @Column(name = "cd_cidade")
    private Short cdCidade;

    @Column(name = "endereco")
    private String endereco;

    @Column(name = "bairro")
    private String bairro;

    @Column(name = "fone")
    private String fone;

    @Column(name = "email")
    private String email;

    @Column(name = "tipo")
    private String tipo;

    @Column(name = "situacao")
    private String situacao;

    // Getters e Setters (parciais para exibição)

    public Integer getCdFornecedor() {
        return cdFornecedor;
    }

    public void setCdFornecedor(Integer cdFornecedor) {
        this.cdFornecedor = cdFornecedor;
    }

    public String getNmFornecedor() {
        return nmFornecedor;
    }

    public void setNmFornecedor(String nmFornecedor) {
        this.nmFornecedor = nmFornecedor;
    }

    public String getNmFantasia() {
        return nmFantasia;
    }

    public void setNmFantasia(String nmFantasia) {
        this.nmFantasia = nmFantasia;
    }

    public String getNmRepresentante() {
        return nmRepresentante;
    }

    public void setNmRepresentante(String nmRepresentante) {
        this.nmRepresentante = nmRepresentante;
    }

    public Short getCdCidade() {
        return cdCidade;
    }

    public void setCdCidade(Short cdCidade) {
        this.cdCidade = cdCidade;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getFone() {
        return fone;
    }

    public void setFone(String fone) {
        this.fone = fone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getSituacao() {
        return situacao;
    }

    public void setSituacao(String situacao) {
        this.situacao = situacao;
    }
}