package com.exemplo;

import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import org.springframework.beans.factory.annotation.Autowired;

@PageTitle("Fornecedores")
@Route(value = "fornecedores", layout = MainLayout.class)
public class FornecedorView extends AbstractGridView<Fornecedor> {

    @Autowired
    public FornecedorView(FornecedorRepository fornecedorRepository) {
        super("Fornecedores", "fornecedores", fornecedorRepository::findAll);
    }

    @Override
    public Class<Fornecedor> getEntityClass() {
        return Fornecedor.class;
    }
}
