package com.exemplo;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface VisibilidadeColunaRepository extends JpaRepository<VisibilidadeColuna, VisibilidadeColunaId> {
    List<VisibilidadeColuna> findByUsuarioAndViewId(String usuario, String viewId);
}