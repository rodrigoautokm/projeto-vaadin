package com.exemplo;

import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.formlayout.FormLayout;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.data.binder.Binder;

import java.util.function.Consumer;
import java.util.List;

public abstract class GenericaCadastro<T> {

    protected Dialog dialog;
    protected Binder<T> binder;
    protected T entity;
    protected Consumer<T> callback;
    protected GenericRepository<T, ?> repository;
    private final Class<T> entityClass;

    public GenericaCadastro(Class<T> entityClass) {
        this.entityClass = entityClass;
        this.dialog = new Dialog();
    }

    public GenericaCadastro(GenericRepository<T, ?> repository, T entity, Consumer<T> callback) {
        this.entityClass = (Class<T>) entity.getClass();
        this.repository = repository;
        this.entity = entity;
        this.callback = callback;
        this.dialog = new Dialog();
    }

    public void initialize(T entity, Consumer<T> onSaveCallback) {
        this.entity = entity;
        this.callback = onSaveCallback;
        this.dialog = new Dialog();
        this.binder = new Binder<>(entityClass);

        dialog.setHeaderTitle(getTitle());

        FormLayout form = new FormLayout();
        buildForm(form);

        Button saveButton = new Button("Salvar", e -> {
            if (binder.validate().isOk()) {
                beforeSave(entity);
                repository.save(entity);
                Notification.show(getSuccessMessage(), 3000, Notification.Position.TOP_CENTER);
                if (callback != null) {
                    callback.accept(entity);
                }
                dialog.close();
            }
        });

        Button cancelButton = new Button("Cancelar", e -> dialog.close());
        form.add(saveButton, cancelButton);

        binder.setBean(entity);
        dialog.add(form);
        dialog.setModal(true);
    }

    protected abstract String getTitle();

    protected abstract void buildForm(FormLayout form);

    protected abstract String getSuccessMessage();

    protected void beforeSave(T entity) {
        // Implementação padrão
    }

    public void open() {
        dialog.open();
    }

    protected abstract List<String> getCamposFixos();

    protected Long getCdEmpresaUsuario() {
        return 1L; // Substitua pela lógica real
    }
}