
package com.exemplo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class MarcaService {

    @Autowired
    private MarcaRepository marcaRepository;

    public List<Marca> listar() {
        return marcaRepository.findAll();
    }

    public void salvarMarca(Marca marca) {
        marcaRepository.save(marca);
    }

    public Optional<Marca> buscar(Integer id) {
        return marcaRepository.findById(id);
    }

    public void excluir(Marca marca) {
        marcaRepository.delete(marca);
    }
}
