package com.exemplo;

/**
 * This class is used to configure the generated html host page used by the app
 */
public class AppShell {
    
}