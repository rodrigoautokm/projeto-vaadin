package com.exemplo;

import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.router.Route;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.List;

@Route(value = "marcas", layout = MainLayout.class)
public class MarcaView extends AbstractGridView<Marca> {

    private static final Logger logger = LoggerFactory.getLogger(MarcaView.class);

    private final GridColumnConfigService columnConfigService;

    @Autowired
    public MarcaView(MarcaService marcaService, GridColumnConfigService columnConfigService) {
        super("Marcas", "marcas", marcaService::listar);
        logger.info("Inicializando MarcaView");
        this.columnConfigService = columnConfigService;
    }

    @Override
    protected Class<Marca> getEntityClass() {
        return Marca.class;
    }

    @Override
    protected List<GridFilterUtil.ColumnConfig<Marca>> configureColumns() {
        logger.info("Configurando colunas da grid para MarcaView");

        String[] fields = {
            "cd_marca", "ds_marca", "comissao", "pr_desconto_vendedor", "pr_desconto_gerente",
            "altera_preco", "situacao", "gtin_unico"
        };

        List<GridFilterUtil.ColumnConfig<Marca>> columnConfigs = new ArrayList<>();
        for (String field : fields) {
            GridColumnConfig config = columnConfigService.getColumnConfig(field);
            if (config == null) {
                logger.warn("Configuração não encontrada para o campo: {}. Usando configuração padrão.", field);
                config = new GridColumnConfig();
                config.setField(field);
                config.setHeader(field);
                config.setWidth("100px");
                config.setVisible(true);
                config.setType("STRING");
            }

            logger.debug("Configuração para o campo {}: header={}, visible={}, width={}, type={}, style={}",
                field, config.getHeader(), config.isVisible(), config.getWidth(), config.getType(), config.getStyle());

            if (config.isVisible()) {
                logger.debug("Adicionando coluna: {}", field);
                Grid.Column<Marca> column = grid.addColumn(marca -> {
                    try {
                        switch (field) {
                            case "cd_marca":
                                return marca.getCdMarca();
                            case "ds_marca":
                                return marca.getDsMarca();
                            case "comissao":
                                return marca.getComissao();
                            case "pr_desconto_vendedor":
                                return marca.getPrDescontoVendedor();
                            case "pr_desconto_gerente":
                                return marca.getPrDescontoGerente();
                            case "altera_preco":
                                return marca.getAlteraPreco();
                            case "situacao":
                                return marca.getSituacao();
                            case "gtin_unico":
                                return marca.getGtinUnico();
                            default:
                                logger.warn("Campo não reconhecido: {}", field);
                                return null;
                        }
                    } catch (Exception e) {
                        logger.error("Erro ao acessar o campo {} para a marca: {}", field, marca, e);
                        return null;
                    }
                }).setKey(field);

                column.setHeader(config.getHeader());
                column.setWidth(config.getWidth());
                column.setSortable(true);
                column.setVisible(true);
                column.setAutoWidth(false);

                logger.debug("Coluna {} configurada com largura: {}, visível: {}", field, config.getWidth(), column.isVisible());

                if (config.getStyle() != null && !config.getStyle().isEmpty()) {
                    String[] styleRules = config.getStyle().split(";");
                    for (String rule : styleRules) {
                        if (rule.trim().isEmpty()) continue;
                        String[] parts = rule.split(":");
                        if (parts.length == 2) {
                            String property = parts[0].trim();
                            String value = parts[1].trim();
                            column.getElement().getStyle().set(property, value);
                            logger.debug("Estilo aplicado à coluna {}: {}: {}", field, property, value);
                        }
                    }
                }

                GridFilterUtil.ColumnConfig<Marca> columnConfig = new GridFilterUtil.ColumnConfig<>(
                    column,
                    config.getHeader(),
                    marca -> {
                        switch (field) {
                            case "cd_marca":
                                return String.valueOf(marca.getCdMarca());
                            case "ds_marca":
                                return marca.getDsMarca();
                            case "comissao":
                                return marca.getComissao() != null ? String.valueOf(marca.getComissao()) : null;
                            case "pr_desconto_vendedor":
                                return marca.getPrDescontoVendedor() != null ? String.valueOf(marca.getPrDescontoVendedor()) : null;
                            case "pr_desconto_gerente":
                                return marca.getPrDescontoGerente() != null ? String.valueOf(marca.getPrDescontoGerente()) : null;
                            case "altera_preco":
                                return marca.getAlteraPreco();
                            case "situacao":
                                return marca.getSituacao();
                            case "gtin_unico":
                                return String.valueOf(marca.getGtinUnico());
                            default:
                                return null;
                        }
                    },
                    config
                );

                columnConfigs.add(columnConfig);
            }
        }

        logger.info("Total de colunas configuradas: {}", grid.getColumns().size());
        return columnConfigs;
    }
}