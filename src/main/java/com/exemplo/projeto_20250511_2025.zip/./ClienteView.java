package com.exemplo;

import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.Objects;

@Route(value = "clientes", layout = MainLayout.class)
public class ClienteView extends AbstractGridView<Cliente> {

    private static final Logger logger = LoggerFactory.getLogger(ClienteView.class);

    private final GridColumnConfigService columnConfigService;
    private final ClienteService clienteService;
    private final ClienteCadastro clienteCadastro;

    @Autowired
    public ClienteView(ClienteService clienteService, GridColumnConfigService columnConfigService, ClienteCadastro clienteCadastro) {
        super("Clientes", "clientes", clienteService::listar);
        this.columnConfigService = columnConfigService;
        this.clienteService = clienteService;
        this.clienteCadastro = clienteCadastro;
        logger.info("Inicializando ClienteView");

        grid.setSelectionMode(Grid.SelectionMode.SINGLE);

        Button newClienteButton = new Button("Novo Cliente", new Icon(VaadinIcon.PLUS));
        newClienteButton.addClickListener(event -> {
            logger.info("Botão 'Novo Cliente' clicado");
            Cliente novoCliente = new Cliente();
            ClienteId clienteId = new ClienteId(1L, getNextCdCliente());
            novoCliente.setId(clienteId);
            openCadastroDialog(novoCliente);
        });

        Button editClienteButton = new Button("Editar Cliente", new Icon(VaadinIcon.EDIT));
        editClienteButton.addClickListener(event -> {
            logger.info("Botão 'Editar Cliente' clicado");
            Set<Cliente> selectedItems = grid.getSelectedItems();
            if (selectedItems.isEmpty()) {
                logger.warn("Nenhum cliente selecionado para edição");
                Notification.show("Por favor, selecione um cliente para editar.", 3000, Notification.Position.TOP_CENTER);
                return;
            }
            Cliente cliente = selectedItems.iterator().next();
            openCadastroDialog(cliente);
        });

        HorizontalLayout buttonLayout = new HorizontalLayout(newClienteButton, editClienteButton);
        buttonLayout.setWidthFull();
        add(buttonLayout);

        grid.addItemDoubleClickListener(event -> {
            logger.info("Duplo clique detectado no grid");
            Cliente cliente = event.getItem();
            if (cliente != null) {
                logger.info("Cliente selecionado para edição: {}", cliente.getId().getCdCliente());
                openCadastroDialog(cliente);
            } else {
                logger.warn("Nenhum cliente selecionado ao dar duplo clique");
                Notification.show("Nenhum cliente selecionado.", 3000, Notification.Position.TOP_CENTER);
            }
        });
    }

    @Override
    protected Class<Cliente> getEntityClass() {
        return Cliente.class;
    }

    @Override
    protected List<GridFilterUtil.ColumnConfig<Cliente>> configureColumns() {
        logger.info("Configurando colunas da grid para ClienteView");

        String[] fields = {
            "cd_cliente", "nm_cliente", "tipo", "endereco", "bairro", "fone", "celular", "cpf"
        };

        List<GridFilterUtil.ColumnConfig<Cliente>> columnConfigs = new ArrayList<>();
        for (String field : fields) {
            GridColumnConfig config = columnConfigService.getColumnConfig(field);
            if (config == null) {
                logger.warn("Configuração não encontrada para o campo: {}. Usando configuração padrão.", field);
                config = new GridColumnConfig();
                config.setField(field);
                config.setHeader(field);
                config.setWidth("100px");
                config.setVisible(true);
                config.setType("STRING");
            }

            if (config.isVisible()) {
                Grid.Column<Cliente> column = grid.addColumn(cliente -> {
                    try {
                        switch (field) {
                            case "cd_cliente":
                                return cliente.getId().getCdCliente();
                            case "nm_cliente":
                                return cliente.getNmCliente();
                            case "tipo":
                                return cliente.getTipo();
                            case "endereco":
                                return cliente.getEndereco();
                            case "bairro":
                                return cliente.getBairro();
                            case "fone":
                                return cliente.getFone();
                            case "celular":
                                return cliente.getCelular();
                            case "cpf":
                                return cliente.getCpf();
                            default:
                                logger.warn("Campo não reconhecido: {}", field);
                                return null;
                        }
                    } catch (Exception e) {
                        logger.error("Erro ao acessar o campo {} para o cliente: {}", field, cliente, e);
                        return null;
                    }
                }).setKey(field);

                column.setHeader(config.getHeader());
                column.setWidth(config.getWidth());
                column.setSortable(true);
                column.setVisible(true);

                GridFilterUtil.ColumnConfig<Cliente> columnConfig = new GridFilterUtil.ColumnConfig<>(
                    column,
                    config.getHeader(),
                    cliente -> {
                        switch (field) {
                            case "cd_cliente":
                                return cliente.getId().getCdCliente() != null ? cliente.getId().getCdCliente().toString() : "";
                            case "nm_cliente":
                                return cliente.getNmCliente();
                            case "tipo":
                                return cliente.getTipo();
                            case "endereco":
                                return cliente.getEndereco();
                            case "bairro":
                                return cliente.getBairro();
                            case "fone":
                                return cliente.getFone();
                            case "celular":
                                return cliente.getCelular();
                            case "cpf":
                                return cliente.getCpf();
                            default:
                                return null;
                        }
                    },
                    config
                );

                columnConfigs.add(columnConfig);
            }
        }

        logger.info("Total de colunas configuradas: {}", grid.getColumns().size());
        return columnConfigs;
    }

    private void openCadastroDialog(Cliente cliente) {
        logger.info("Abrindo diálogo de edição para cliente: {}", cliente.getId().getCdCliente());
        try {
            clienteCadastro.initialize(cliente, updatedCliente -> {
                logger.info("Cliente atualizado: {}", updatedCliente.getId().getCdCliente());
                grid.getDataProvider().refreshAll();
            });
            clienteCadastro.open();
        } catch (Exception e) {
            logger.error("Erro ao abrir diálogo de edição: {}", e.getMessage(), e);
            Notification.show("Erro ao abrir a tela de edição: " + e.getMessage(), 3000, Notification.Position.TOP_CENTER);
        }
    }

    private Integer getNextCdCliente() {
        logger.info("Calculando próximo cd_cliente");
        List<Cliente> clientes = clienteService.listar();
        return clientes.stream()
                .map(cliente -> cliente.getId().getCdCliente())
                .filter(Objects::nonNull)
                .max(Integer::compareTo)
                .map(max -> max + 1)
                .orElse(1);
    }
}