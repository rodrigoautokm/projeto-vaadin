package com.exemplo;

import com.vaadin.flow.component.formlayout.FormLayout;
import com.vaadin.flow.component.textfield.TextField;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;

@Component
public class ClienteCadastro extends GenericaCadastro<Cliente> {

    @Autowired
    public ClienteCadastro(ClienteRepository clienteRepository) {
        super(clienteRepository, new Cliente(), null);
    }

    @Override
    protected String getTitle() {
        return entity != null && entity.getId() != null ? "Editar Cliente" : "Novo Cliente";
    }

    @Override
    protected List<String> getCamposFixos() {
        return Arrays.asList("cd_cliente", "nm_cliente", "tipo", "endereco", "bairro", "fone", "celular", "cpf");
    }

    @Override
    protected String getSuccessMessage() {
        return "Cliente salvo com sucesso!";
    }

    @Override
    protected void beforeSave(Cliente cliente) {
        if (cliente.getId() == null) {
            cliente.setId(new ClienteId());
        }
        if (cliente.getId().getCdEmpresa() == null) {
            cliente.getId().setCdEmpresa(getCdEmpresaUsuario());
        }
    }

    @Override
    protected void buildForm(FormLayout form) {
        TextField cdClienteField = new TextField("Código Cliente");
        TextField nmClienteField = new TextField("Nome");
        TextField tipoField = new TextField("Tipo");
        TextField enderecoField = new TextField("Endereço");
        TextField bairroField = new TextField("Bairro");
        TextField foneField = new TextField("Telefone");
        TextField celularField = new TextField("Celular");
        TextField cpfField = new TextField("CPF");
        form.add(cdClienteField, nmClienteField, tipoField, enderecoField, bairroField, foneField, celularField, cpfField);
        binder.bind(cdClienteField, 
            c -> c.getId().getCdCliente() != null ? c.getId().getCdCliente().toString() : "", 
            (c, v) -> c.getId().setCdCliente(v != null && !v.isEmpty() ? Integer.valueOf(v) : null));
        binder.bind(nmClienteField, Cliente::getNmCliente, Cliente::setNmCliente);
        binder.bind(tipoField, Cliente::getTipo, Cliente::setTipo);
        binder.bind(enderecoField, Cliente::getEndereco, Cliente::setEndereco);
        binder.bind(bairroField, Cliente::getBairro, Cliente::setBairro);
        binder.bind(foneField, Cliente::getFone, Cliente::setFone);
        binder.bind(celularField, Cliente::getCelular, Cliente::setCelular);
        binder.bind(cpfField, Cliente::getCpf, Cliente::setCpf);
    }
}