package com.exemplo;

import javax.persistence.*;

@Entity
@Table(name = "sort_config")
public class SortConfig {

    @EmbeddedId
    private SortConfigId id;

    @Column(name = "sort_column")
    private String sortColumn;

    @Column(name = "sort_direction")
    private String sortDirection;

    public SortConfig() {}

    public SortConfig(SortConfigId id, String sortColumn, String sortDirection) {
        this.id = id;
        this.sortColumn = sortColumn;
        this.sortDirection = sortDirection;
    }

    public SortConfigId getId() {
        return id;
    }

    public void setId(SortConfigId id) {
        this.id = id;
    }

    public String getSortColumn() {
        return sortColumn;
    }

    public void setSortColumn(String sortColumn) {
        this.sortColumn = sortColumn;
    }

    public String getSortDirection() {
        return sortDirection;
    }

    public void setSortDirection(String sortDirection) {
        this.sortDirection = sortDirection;
    }
}