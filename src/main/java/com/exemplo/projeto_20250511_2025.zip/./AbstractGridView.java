package com.exemplo;

import com.vaadin.flow.component.AttachEvent;
import com.vaadin.flow.component.DetachEvent;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.html.H1;
import com.vaadin.flow.component.html.Span;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.progressbar.ProgressBar;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.router.BeforeEnterEvent;
import com.vaadin.flow.router.BeforeEnterObserver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

public abstract class AbstractGridView<T> extends VerticalLayout implements BeforeEnterObserver {

    private static final Logger logger = LoggerFactory.getLogger(AbstractGridView.class);

    protected final String title;
    protected final String gridId;
    protected final Supplier<List<T>> dataSupplier;
    protected Grid<T> grid;
    protected GridFilterUtil<T> gridUtil;
    protected List<T> items;
    protected List<GridFilterUtil.ColumnConfig<T>> columnConfigs;

    private VerticalLayout loadingOverlay;
    private ProgressBar loadingBar;
    private Span loadingMessage;
    private boolean isLoading = false;

    @Autowired
    protected GridColumnConfigService gridColumnConfigService;

    public AbstractGridView(String title, String gridId, Supplier<List<T>> dataSupplier) {
        this.title = title;
        this.gridId = gridId;
        this.dataSupplier = dataSupplier;

        setSizeFull();
        setPadding(false);
        setMargin(false);
        setSpacing(false);
        addClassName("abstract-grid-view");
        getStyle().set("position", "relative");

        H1 titleComponent = new H1(title);
        titleComponent.getStyle()
            .set("font-size", "24px")
            .set("margin", "10px 0 5px 0")
            .set("padding", "0");
        add(titleComponent);

        grid = new Grid<>((Class<T>) getEntityClass(), false);
        grid.getElement().getClassList().add("grid-container");
        grid.setHeight("100%");
        grid.setWidth("100%");

        grid.getElement().executeJs(
            "this.addEventListener('data-provider-changed', () => { console.log('Dados da grade atualizados:', this.items); });"
        );

        initializeLoadingOverlay();
    }

    private void initializeLoadingOverlay() {
        loadingOverlay = new VerticalLayout();
        loadingOverlay.setSizeFull();
        loadingOverlay.setJustifyContentMode(FlexComponent.JustifyContentMode.CENTER);
        loadingOverlay.setAlignItems(FlexComponent.Alignment.CENTER);
        loadingOverlay.getStyle()
                .set("position", "absolute")
                .set("top", "0")
                .set("left", "0")
                .set("background", "rgba(255, 255, 255, 0.8)")
                .set("z-index", "100")
                .set("display", "none");

        loadingBar = new ProgressBar();
        loadingBar.setIndeterminate(true);
        loadingBar.setWidth("200px");

        loadingMessage = new Span("Carregando dados...");
        loadingMessage.getStyle().set("font-size", "16px");

        loadingOverlay.add(loadingBar, loadingMessage);
        add(loadingOverlay);
    }

    protected void showLoading() {
        isLoading = true;
        loadingOverlay.getStyle().set("display", "flex");
        grid.getStyle().set("opacity", "0.5");
        notifyLoadingStateChanged(true);
    }

    protected void hideLoading() {
        isLoading = false;
        loadingOverlay.getStyle().set("display", "none");
        grid.getStyle().set("opacity", "1");
        notifyLoadingStateChanged(false);
    }

    protected boolean isLoading() {
        return isLoading;
    }

    protected void notifyLoadingStateChanged(boolean loading) {
    }

    @Override
    public void beforeEnter(BeforeEnterEvent event) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !authentication.isAuthenticated() || authentication.getPrincipal() instanceof String) {
            logger.warn("Usuário não autenticado ou sessão inválida. Redirecionando para /login.");
            event.rerouteTo("login");
            return;
        }

        String usuarioId = getUsuarioId();
        if (usuarioId == null) {
            logger.warn("Não foi possível obter o usuarioId. Redirecionando para /login.");
            event.rerouteTo("login");
            return;
        }

        gridColumnConfigService.reloadConfig();

        this.items = dataSupplier.get();
        if (this.items == null) {
            this.items = new ArrayList<>();
        }

        grid.removeAllColumns();

        columnConfigs = configureColumns();
        if (columnConfigs == null) {
            columnConfigs = new ArrayList<>();
        }

        logger.debug("Usuário identificado para carregamento de preferências: {}", usuarioId);
        gridUtil = new GridFilterUtil<>(grid, items, gridId, usuarioId, gridColumnConfigService);
        gridUtil.adicionarFiltrosNoCabecalho(columnConfigs);

        setFlexGrow(1, grid);
        add(grid);

        grid.getDataProvider().refreshAll();
    }

    @Override
    protected void onAttach(AttachEvent attachEvent) {
        super.onAttach(attachEvent);
        logger.debug("AbstractGridView para gridId: {} anexado à UI", gridId);
    }

    @Override
    protected void onDetach(DetachEvent detachEvent) {
        super.onDetach(detachEvent);
        logger.debug("AbstractGridView para gridId: {} desanexado da UI", gridId);
        if (gridUtil != null) {
            gridUtil.saveChanges();
        }
    }

    public GridFilterUtil<T> getGridFilterUtil() {
        return gridUtil;
    }

    protected String getUsuarioId() {
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            if (authentication == null || !authentication.isAuthenticated()) {
                logger.warn("Autenticação não encontrada ou usuário não autenticado.");
                return null;
            }

            Object principal = authentication.getPrincipal();
            logger.debug("Principal obtido do SecurityContextHolder: {}", principal);

            if (principal instanceof UserDetails) {
                String username = ((UserDetails) principal).getUsername();
                logger.debug("Usuário logado: {}", username);
                return username;
            } else {
                logger.warn("Principal não é UserDetails: {}", principal);
                return null;
            }
        } catch (Exception e) {
            logger.error("Erro ao obter usuário logado: {}", e.getMessage(), e);
            return null;
        }
    }

    protected abstract Class<T> getEntityClass();

    protected abstract List<GridFilterUtil.ColumnConfig<T>> configureColumns();

    protected void updateData(List<T> newItems) {
        showLoading();
        try {
            this.items = newItems != null ? newItems : new ArrayList<>();
            gridUtil.updateItems(items);
        } finally {
            hideLoading();
        }
    }

    protected void addFilters(HorizontalLayout filtroLayout) {
        if (filtroLayout != null) {
            filtroLayout.setAlignItems(Alignment.BASELINE);
            filtroLayout.setSpacing(false);
            filtroLayout.addClassName("filtro-layout");
            filtroLayout.getStyle()
                .set("margin", "0 0 10px 0")
                .set("padding", "0");
            add(filtroLayout);
        }
    }
}