package com.exemplo;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@SqlResultSetMapping(
    name = "ListagemPedidoResultMapping",
    classes = @ConstructorResult(
        targetClass = ListagemPedidoResult.class,
        columns = {
            @ColumnResult(name = "nr_pedido", type = Integer.class),
            @ColumnResult(name = "cd_empresa", type = Integer.class),
            @ColumnResult(name = "serie", type = String.class),
            @ColumnResult(name = "cd_empresa_venda", type = Integer.class),
            @ColumnResult(name = "dt_emissao", type = Date.class),
            @ColumnResult(name = "cd_cliente", type = Integer.class),
            @ColumnResult(name = "nm_cliente", type = String.class),
            @ColumnResult(name = "vl_total", type = BigDecimal.class),
            @ColumnResult(name = "vl_desconto_total", type = BigDecimal.class),
            @ColumnResult(name = "situacao", type = String.class),
            @ColumnResult(name = "cd_funcionario", type = Integer.class),
            @ColumnResult(name = "nm_funcionario", type = String.class),
            @ColumnResult(name = "vl_frete", type = BigDecimal.class),
            @ColumnResult(name = "vl_acrescimo_total", type = BigDecimal.class),
            @ColumnResult(name = "nr_pedido_anterior", type = Integer.class),
            @ColumnResult(name = "cheque", type = String.class),
            @ColumnResult(name = "nm_usuario", type = String.class),
            @ColumnResult(name = "nr_nota", type = Integer.class),
            @ColumnResult(name = "serie_nota", type = String.class),
            @ColumnResult(name = "dt_faturamento", type = Date.class)
        }
    )
)
@Entity
public class ListagemPedidoResult implements Serializable {

    @Id
    private Integer nrPedido;
    private Integer cdEmpresa;
    private String serie;
    private Integer cdEmpresaVenda;
    private Date dtEmissao;
    private Integer cdCliente;
    private String nmCliente;
    private BigDecimal vlTotal;
    private BigDecimal vlDescontoTotal;
    private String situacao;
    private Integer cdFuncionario;
    private String nmFuncionario;
    private BigDecimal vlFrete;
    private BigDecimal vlAcrescimoTotal;
    private Integer nrPedidoAnterior;
    private String cheque;
    private String nmUsuario;
    private Integer nrNota;
    private String serieNota;
    private Date dtFaturamento;

    public ListagemPedidoResult() {
    }

    public ListagemPedidoResult(Integer nrPedido, Integer cdEmpresa, String serie, Integer cdEmpresaVenda,
                                Date dtEmissao, Integer cdCliente, String nmCliente, BigDecimal vlTotal,
                                BigDecimal vlDescontoTotal, String situacao, Integer cdFuncionario,
                                String nmFuncionario, BigDecimal vlFrete, BigDecimal vlAcrescimoTotal,
                                Integer nrPedidoAnterior, String cheque, String nmUsuario, Integer nrNota,
                                String serieNota, Date dtFaturamento) {
        this.nrPedido = nrPedido;
        this.cdEmpresa = cdEmpresa;
        this.serie = serie;
        this.cdEmpresaVenda = cdEmpresaVenda;
        this.dtEmissao = dtEmissao;
        this.cdCliente = cdCliente;
        this.nmCliente = nmCliente;
        this.vlTotal = vlTotal;
        this.vlDescontoTotal = vlDescontoTotal;
        this.situacao = situacao;
        this.cdFuncionario = cdFuncionario;
        this.nmFuncionario = nmFuncionario;
        this.vlFrete = vlFrete;
        this.vlAcrescimoTotal = vlAcrescimoTotal;
        this.nrPedidoAnterior = nrPedidoAnterior;
        this.cheque = cheque;
        this.nmUsuario = nmUsuario;
        this.nrNota = nrNota;
        this.serieNota = serieNota;
        this.dtFaturamento = dtFaturamento;
    }

    public Integer getNrPedido() {
        return nrPedido;
    }

    public Integer getCdEmpresa() {
        return cdEmpresa;
    }

    public String getSerie() {
        return serie;
    }

    public Integer getCdEmpresaVenda() {
        return cdEmpresaVenda;
    }

    public Date getDtEmissao() {
        return dtEmissao;
    }

    public Integer getCdCliente() {
        return cdCliente;
    }

    public String getNmCliente() {
        return nmCliente;
    }

    public BigDecimal getVlTotal() {
        return vlTotal;
    }

    public BigDecimal getVlDescontoTotal() {
        return vlDescontoTotal;
    }

    public String getSituacao() {
        return situacao;
    }

    public Integer getCdFuncionario() {
        return cdFuncionario;
    }

    public String getNmFuncionario() {
        return nmFuncionario;
    }

    public BigDecimal getVlFrete() {
        return vlFrete;
    }

    public BigDecimal getVlAcrescimoTotal() {
        return vlAcrescimoTotal;
    }

    public Integer getNrPedidoAnterior() {
        return nrPedidoAnterior;
    }

    public String getCheque() {
        return cheque;
    }

    public String getNmUsuario() {
        return nmUsuario;
    }

    public Integer getNrNota() {
        return nrNota;
    }

    public String getSerieNota() {
        return serieNota;
    }

    public Date getDtFaturamento() {
        return dtFaturamento;
    }
}