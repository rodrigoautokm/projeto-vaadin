package com.exemplo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.sql.DataSource;
import java.util.ArrayList;
import java.util.List;

@Service
public class DreService {

    private static final Logger logger = LoggerFactory.getLogger(DreService.class);

    @Autowired
    private EmpresaConnectionManager empresaConnectionManager;

    @SuppressWarnings("unchecked") // Suprimir o aviso de "unchecked"
    public List<DreItem> consultarDre(String dataInicio, String dataFim) {
        List<DreItem> resultados = new ArrayList<>();
        logger.info("Consultando DRE via JPA para o período: {} a {}", dataInicio, dataFim);

        CustomUserDetails userDetails = (CustomUserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Integer cdEmpresa = userDetails.getCdEmpresa().intValue();
        logger.info("Usuário autenticado com cdEmpresa: {}", cdEmpresa.intValue());

        DataSource dataSource = empresaConnectionManager.getDataSourceForEmpresa(cdEmpresa.intValue());
        if (dataSource == null) {
            logger.error("DataSource não configurado para a empresa: {}", cdEmpresa.intValue());
            return resultados;
        }

        EntityManager em = null;
        try {
            em = JpaUtil.getEntityManager(dataSource);
            logger.info("EntityManager criado com sucesso.");

            String sql = "CALL pr_rel_demonstrativo_resultado_arvore(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

            List<Object[]> rows = em.createNativeQuery(sql)
                    .setParameter(1, cdEmpresa.intValue())
                    .setParameter(2, dataInicio)
                    .setParameter(3, dataFim)
                    .setParameter(4, 0)
                    .setParameter(5, "DC")
                    .setParameter(6, "N")
                    .setParameter(7, "S")
                    .setParameter(8, "N")
                    .setParameter(9, "1506875,98")
                    .setParameter(10, "V")
                    .setParameter(11, "N")
                    .getResultList();

            logger.info("Consulta retornou {} linhas.", rows.size());

            for (Object[] row : rows) {
                String agrupa = safeString(row, 0);
                String descricao = safeString(row, 1);
                Double valor = safeDouble(row, 2);
                String fornecedor = safeString(row, 3);
                String situacao = safeString(row, 4);
                String dataEmissao = safeString(row, 5);
                String dataVencimento = safeString(row, 6);
                String dataPagamento = safeString(row, 7);
                String observacao = safeString(row, 8);
                String despesa1 = safeString(row, 9);

                DreItem item = new DreItem(agrupa, descricao, valor, fornecedor, situacao,
                        dataEmissao, dataVencimento, dataPagamento, observacao, despesa1);

                resultados.add(item);
            }

        } catch (Exception e) {
            logger.error("Erro ao consultar DRE via JPA: {}", e.getMessage(), e);
        } finally {
            if (em != null && em.isOpen()) {
                em.close();
            }
        }

        return resultados;
    }

    private String safeString(Object[] row, int index) {
        try {
            Object value = row[index];
            return value != null ? value.toString() : "N/A";
        } catch (Exception e) {
            return "N/A";
        }
    }

    private Double safeDouble(Object[] row, int index) {
        try {
            Object value = row[index];
            return value != null ? Double.parseDouble(value.toString().replace(",", ".")) : 0.0;
        } catch (Exception e) {
            return 0.0;
        }
    }
}