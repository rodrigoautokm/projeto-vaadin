package com.exemplo;

import com.vaadin.flow.component.formlayout.FormLayout;
import com.vaadin.flow.component.textfield.TextField;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;
import java.math.BigDecimal;

@Component
public class ProdutoCadastro extends GenericaCadastro<Produto> {

    @Autowired
    public ProdutoCadastro(ProdutoRepository produtoRepository) {
        super(produtoRepository, new Produto(), null);
    }

    @Override
    protected String getTitle() {
        return entity != null ? "Editar Produto" : "Novo Produto";
    }

    @Override
    protected List<String> getCamposFixos() {
        return Arrays.asList("nome", "preco");
    }

    @Override
    protected String getSuccessMessage() {
        return "Produto salvo com sucesso!";
    }

    @Override
    protected void beforeSave(Produto produto) {
        // Caso precise preencher algo automaticamente antes de salvar
    }

    @Override
    protected void buildForm(FormLayout form) {
        TextField nomeField = new TextField("Nome");
        TextField precoField = new TextField("Preço");
        form.add(nomeField, precoField);
        binder.bind(nomeField, Produto::getDsProduto, Produto::setDsProduto);
        binder.bind(precoField, 
            p -> p.getVlVenda() != null ? p.getVlVenda().toString() : "", 
            (p, v) -> p.setVlVenda(v != null && !v.isEmpty() ? new BigDecimal(v) : null));
    }
}