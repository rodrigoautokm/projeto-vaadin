package com.exemplo;

import com.vaadin.flow.router.BeforeEnterEvent;
import com.vaadin.flow.router.BeforeEnterObserver;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

@PageTitle("Produtos")
@Route(value = "produtos", layout = MainLayout.class)
public class ProdutoView extends AbstractGridView<Produto> implements BeforeEnterObserver {
    private static final Logger logger = LoggerFactory.getLogger(ProdutoView.class);
    private final ProdutoRepository produtoRepository;

    @Autowired
    private DataSourceHelper dataSourceHelper;

    @Autowired
    public ProdutoView(ProdutoRepository produtoRepository) {
        super("Produtos", "produto", produtoRepository::findAll);
        logger.info("Inicializando ProdutoView com gridId 'produto'");
        this.produtoRepository = produtoRepository;
    }

    @Override
    public Class<Produto> getEntityClass() {
        logger.info("Retornando classe de entidade Produto");
        return Produto.class;
    }

    @Override
    protected GenericRepository<Produto, ?> getRepository() {
        logger.info("Retornando repositório de Produto");
        return produtoRepository;
    }

    @Override
    public void beforeEnter(BeforeEnterEvent event) {
        if (dataSourceHelper != null) {
            dataSourceHelper.configurarDataSourceAtual();
            logger.info("DataSource configurado para ProdutoView");
        } else {
            logger.warn("DataSourceHelper é nulo para ProdutoView. Verifique a configuração do Spring.");
        }
    }
}