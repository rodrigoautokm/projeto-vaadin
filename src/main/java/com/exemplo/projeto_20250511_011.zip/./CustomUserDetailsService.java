package com.exemplo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    private static final Logger logger = LoggerFactory.getLogger(CustomUserDetailsService.class);

    @Autowired
    private UsuarioAcessoRepository usuarioAcessoRepository;

    @Autowired
    private EmpresaRepository empresaRepository;

    @Autowired
    private EmpresaAwareService empresaAwareService;

    @Autowired
    private ConfigurableApplicationContext context;

    @Override
    @Transactional(transactionManager = "primaryTransactionManager")
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        logger.info("Tentando autenticar usuário: '{}'", username);

        try {
            // Testar a conexão com o banco antes de prosseguir
            logger.info("Testando conexão com o banco principal (autokm) antes de buscar usuário...");
            Optional<UsuarioAcesso> testQuery = usuarioAcessoRepository.findByUsuario("test_connection");
            logger.info("Conexão com o banco principal testada com sucesso. Resultado da consulta de teste: {}", testQuery.isPresent());

            // Buscar o usuário no banco de dados principal (autokm)
            logger.info("Buscando usuário '{}' na tabela usuario_acesso (banco principal autokm)");
            Optional<UsuarioAcesso> usuarioOptional = usuarioAcessoRepository.findByUsuario(username);
            if (usuarioOptional.isEmpty()) {
                logger.warn("Usuário não encontrado: '{}'", username);
                throw new UsernameNotFoundException("Usuário não encontrado: " + username);
            }

            UsuarioAcesso usuario = usuarioOptional.get();
            logger.info("Usuário encontrado: '{}', cdEmpresa: '{}', senha: '{}'", username, usuario.getCdEmpresa(), usuario.getSenha());

            // Obter o cdEmpresa do usuário
            Short cdEmpresa = usuario.getCdEmpresa();
            if (cdEmpresa == null) {
                logger.warn("Usuário não associado a uma empresa: '{}'", username);
                throw new UsernameNotFoundException("Usuário não associado a uma empresa: " + username);
            }

            // Atualizar o cdEmpresa no EmpresaAwareService
            empresaAwareService.setCdEmpresa(cdEmpresa);
            logger.info("cdEmpresa atualizado no EmpresaAwareService: '{}'", cdEmpresa);

            // Buscar as informações da empresa no banco principal (autokm)
            logger.info("Buscando empresa para cdEmpresa: '{}'", cdEmpresa);
            Optional<Empresa> empresaOptional = empresaRepository.findByCd_empresa(cdEmpresa.intValue());
            if (empresaOptional.isEmpty()) {
                logger.warn("Empresa não encontrada para cdEmpresa: '{}'", cdEmpresa);
                throw new UsernameNotFoundException("Empresa não encontrada para cdEmpresa: " + cdEmpresa);
            }

            Empresa empresa = empresaOptional.get();
            logger.info("Empresa encontrada: cd_empresa: '{}', server_name: '{}', nome_banco: '{}'", 
                empresa.getCd_empresa(), empresa.getServerName(), empresa.getNomeBanco());

            // Configurar o DataSource dinâmico para a empresa do usuário (ex.: pratico9)
            try {
                logger.info("DataSource dinâmico alternado para empresa: '{}'", empresa.getCd_empresa());
            } catch (Exception e) {
                logger.error("Erro ao alternar DataSource dinâmico para empresa '{}': {}", empresa.getCd_empresa(), e.getMessage(), e);
                throw new UsernameNotFoundException("Erro ao configurar DataSource: " + e.getMessage(), e);
            }

            // Criar e retornar o UserDetails
            String[] roles = usuario.getAdmin() != null && "S".equalsIgnoreCase(usuario.getAdmin()) ? new String[]{"ADMIN"} : new String[]{"USER"};
            logger.info("Roles atribuídas ao usuário '{}': {}", username, roles);
            return User.withUsername(username)
                    .password(usuario.getSenha()) // A senha já está codificada com BCrypt
                    .roles(roles)
                    .build();
        } catch (Exception e) {
            logger.error("Erro durante a autenticação do usuário '{}': {}", username, e.getMessage(), e);
            throw new UsernameNotFoundException("Erro durante a autenticação: " + e.getMessage(), e);
        }
    }
}