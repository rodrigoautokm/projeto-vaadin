package com.exemplo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Service
public class OrdemColunaService {

    private static final Logger logger = LoggerFactory.getLogger(OrdemColunaService.class);

    @Autowired
    private OrdemColunaRepository repository;

    public String carregarOrdemColunas(String usuario, String viewId) {
        logger.debug("Carregando ordem das colunas para usuario: {} e viewId: {}", usuario, viewId);
        Optional<OrdemColuna> ordemColuna = repository.findByUsuarioAndViewId(usuario, viewId);
        return ordemColuna.map(OrdemColuna::getOrdemColunas).orElse(null);
    }

    @Transactional
    public void salvarOrdemColunas(String usuario, String viewId, String ordemColunas) {
        logger.debug("Salvando ordem das colunas para usuario: {} e viewId: {}", usuario, viewId);
        // Deletar ordem existente para o usuario e viewId
        repository.deleteByUsuarioAndViewId(usuario, viewId);

        // Salvar nova ordem
        if (ordemColunas != null && !ordemColunas.isEmpty()) {
            OrdemColuna ordem = new OrdemColuna(usuario, viewId, ordemColunas);
            repository.save(ordem);
            logger.debug("Ordem das colunas salva: {}", ordemColunas);
        }
    }
}