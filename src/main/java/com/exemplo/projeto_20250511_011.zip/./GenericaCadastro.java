package com.exemplo;

import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.formlayout.FormLayout;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.data.binder.Binder;

import java.util.function.Consumer;

public abstract class GenericaCadastro<T> {

    protected Dialog dialog;
    protected Binder<T> binder;
    protected T entity;
    protected Consumer<T> onSaveCallback;

    public GenericaCadastro() {
        this.dialog = new Dialog();
    }

    public void initialize(T entity, Consumer<T> onSaveCallback) {
        this.entity = entity;
        this.onSaveCallback = onSaveCallback;
        this.dialog = new Dialog();
        this.binder = new Binder<>((Class<T>) entity.getClass());

        dialog.setHeaderTitle(getTitle());

        FormLayout form = new FormLayout();
        buildForm(form);

        Button saveButton = new Button("Salvar", e -> {
            if (binder.validate().isOk()) {
                Notification.show(getSuccessMessage(), 3000, Notification.Position.TOP_CENTER);
                if (onSaveCallback != null) {
                    onSaveCallback.accept(entity);
                }
                dialog.close();
            }
        });

        Button cancelButton = new Button("Cancelar", e -> dialog.close());
        form.add(saveButton, cancelButton);

        binder.setBean(entity);
        dialog.add(form);
        dialog.setModal(true);
    }

    protected abstract String getTitle();

    protected abstract void buildForm(FormLayout form);

    protected abstract String getSuccessMessage();

    public void open() {
        dialog.open();
    }

    protected abstract java.util.List<String> getCamposFixos();
}
