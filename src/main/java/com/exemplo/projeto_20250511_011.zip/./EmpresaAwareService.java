package com.exemplo;

import org.springframework.stereotype.Component;

@Component
public class EmpresaAwareService {

    private Short cdEmpresa;

    public Short getCdEmpresa() {
        return cdEmpresa;
    }

    public void setCdEmpresa(Short cdEmpresa) {
        this.cdEmpresa = cdEmpresa;
    }
}
