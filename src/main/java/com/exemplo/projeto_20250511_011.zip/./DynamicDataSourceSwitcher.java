package com.exemplo;

import com.zaxxer.hikari.HikariDataSource;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;
import java.util.HashMap;
import java.util.Map;

public class DynamicDataSourceSwitcher {

    private final ConfigurableApplicationContext context;

    public DynamicDataSourceSwitcher(ConfigurableApplicationContext context) {
        this.context = context;
        System.out.println("Inicializando DynamicDataSourceSwitcher...");
    }

    public void switchTo(Empresa empresa) {
        try {
            System.out.println("Alternando DataSource para empresa: " + empresa.getCdEmpresa());
            // Criar novo DataSource
            HikariDataSource newDataSource = new HikariDataSource();
            String jdbcUrl = String.format("jdbc:sqlanywhere:ServerName=%s;DatabaseName=%s;Host=%s:%s",
                    empresa.getServerName(), empresa.getNomeBanco(), empresa.getIpBd(), empresa.getPortaBd());
            newDataSource.setJdbcUrl(jdbcUrl);
            newDataSource.setUsername(empresa.getUsuarioBd());
            newDataSource.setPassword(empresa.getSenhaBd());
            newDataSource.setDriverClassName("sap.jdbc4.sqlanywhere.IDriver");
            System.out.println("Novo DataSource criado: " + jdbcUrl);

            // Obter bean factory
            DefaultListableBeanFactory beanFactory = (DefaultListableBeanFactory) context.getBeanFactory();

            // Remover DataSource, EntityManagerFactory e TransactionManager antigos
            destroyIfExists(beanFactory, "dataSource");
            destroyIfExists(beanFactory, "entityManagerFactory");
            destroyIfExists(beanFactory, "transactionManager");

            // Registrar novo DataSource
            beanFactory.registerSingleton("dataSource", newDataSource);
            System.out.println("DataSource registrado no contexto.");

            // Criar e registrar novo EntityManagerFactory
            EntityManagerFactoryBuilder builder = context.getBean(EntityManagerFactoryBuilder.class);
            Map<String, Object> jpaProperties = new HashMap<>();
            jpaProperties.put("hibernate.hbm2ddl.auto", "none");
            jpaProperties.put("hibernate.dialect", "org.hibernate.dialect.SQLAnywhereDialect");
            jpaProperties.put("hibernate.show_sql", true);
            jpaProperties.put("hibernate.format_sql", true);
            jpaProperties.put("hibernate.physical_naming_strategy", "org.springframework.boot.orm.jpa.hibernate.SpringPhysicalNamingStrategy");

            LocalContainerEntityManagerFactoryBean emfBean = builder
                    .dataSource(newDataSource)
                    .packages("com.exemplo")
                    .persistenceUnit("default")
                    .properties(jpaProperties)
                    .build();
            emfBean.afterPropertiesSet();

            EntityManagerFactory emf = emfBean.getObject();
            beanFactory.registerSingleton("entityManagerFactory", emf);
            System.out.println("EntityManagerFactory registrado no contexto.");

            // Registrar novo TransactionManager
            JpaTransactionManager txManager = new JpaTransactionManager(emf);
            beanFactory.registerSingleton("transactionManager", txManager);
            System.out.println("TransactionManager registrado no contexto.");

            System.out.println("✅ Conexão alterada com sucesso para empresa: " + empresa.getNomeBanco());
        } catch (Exception e) {
            System.err.println("❌ Erro ao alternar DataSource: " + e.getMessage());
            e.printStackTrace();
            throw new RuntimeException("Falha ao alternar DataSource", e);
        }
    }

    private void destroyIfExists(DefaultListableBeanFactory factory, String beanName) {
        if (factory.containsSingleton(beanName)) {
            factory.destroySingleton(beanName);
            System.out.println("Bean destruído: " + beanName);
        }
    }
}