package com.exemplo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ColumnConfigRepository extends JpaRepository<ColumnConfigEntity, Integer> {
    // Busca configurações por class_name (visão específica)
    List<ColumnConfigEntity> findByClassName(String className);

    // Busca configuração por class_name e field_name (para priorizar específica ou genérica)
    ColumnConfigEntity findByClassNameAndFieldName(String className, String fieldName);

    // Busca configurações genéricas (class_name = 'default')
    @Query("SELECT c FROM ColumnConfigEntity c WHERE c.className = 'default'")
    List<ColumnConfigEntity> findByClassNameDefault();

    // Busca configurações por class_name e usuario
    List<ColumnConfigEntity> findByClassNameAndUsuario(String className, String usuario);

    // Busca configurações por class_name e usuario como 'default'
    @Query("SELECT c FROM ColumnConfigEntity c WHERE c.className = :className AND c.usuario = 'default'")
    List<ColumnConfigEntity> findByClassNameAndUsuarioIsDefault(String className);

    // Busca configuração por class_name, field_name e usuario
    ColumnConfigEntity findByClassNameAndFieldNameAndUsuario(String className, String fieldName, String usuario);

    // Busca configuração por class_name, field_name e usuario como 'default'
    @Query("SELECT c FROM ColumnConfigEntity c WHERE c.className = :className AND c.fieldName = :fieldName AND c.usuario = 'default'")
    ColumnConfigEntity findByClassNameAndFieldNameAndUsuarioIsDefault(String className, String fieldName);
}