package com.exemplo;

import com.vaadin.flow.component.formlayout.FormLayout;
import com.vaadin.flow.component.textfield.TextField;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;

@Component
public class ProdutoCadastro extends GenericaCadastro<Produto> {

    public ProdutoCadastro() {
        super();
    }

    @Override
    protected String getTitle() {
        return entity != null ? "Editar Produto" : "Novo Produto";
    }

    @Override
    protected List<String> getCamposFixos() {
        return Arrays.asList("cd_produto", "ds_produto", "cd_marca", "dt_cadastro");
    }

    @Override
    protected String getSuccessMessage() {
        return "Produto salvo com sucesso!";
    }

    @Override
    protected void buildForm(FormLayout form) {
        TextField desc = new TextField("Descrição");
        binder.bind(desc, "dsProduto");
        form.add(desc);
    }
}
