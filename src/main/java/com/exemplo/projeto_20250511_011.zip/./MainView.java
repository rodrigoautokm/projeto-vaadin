package com.exemplo;

import com.exemplo.EmpresaAwareService;
import com.vaadin.flow.component.html.H1;
import com.vaadin.flow.component.html.Paragraph;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import org.springframework.beans.factory.annotation.Autowired;

import javax.annotation.PostConstruct;
import java.util.Optional;
import com.exemplo.DynamicDataSourceSwitcher;
import com.exemplo.CustomUserDetails;
import org.springframework.security.core.context.SecurityContextHolder;
import com.exemplo.SpringContext;

@Route(value = "", layout = MainLayout.class)
@PageTitle("Página Inicial")
public class MainView extends VerticalLayout {
    @PostConstruct
    @PostConstruct
    @PostConstruct
    }
    }
    }
    @Autowired
    private EmpresaRepository empresaRepository;

    @PostConstruct
    private void initDataSourceSwitcher() {
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if (principal instanceof CustomUserDetails) {
            Short cdEmpresa = ((CustomUserDetails) principal).getCdEmpresa();
            Empresa empresa = empresaRepository.findByCdEmpresa(cdEmpresa).orElse(null);
            DynamicDataSourceSwitcher switcher = SpringContext.getBean(DynamicDataSourceSwitcher.class);
            switcher.switchTo(empresa);
        }
    }
    public MainView() {
        setSpacing(true);
        setPadding(true);
        add(new H1("Bem-vindo à Minha Aplicação Vaadin!"));
    }


    private Short getCdEmpresa() {
        try {
            return empresaAwareService.getCdEmpresa();
        } catch (Exception e) {
            Notification.show("Erro ao identificar usuário logado.");
            return null;
        }
    }
}