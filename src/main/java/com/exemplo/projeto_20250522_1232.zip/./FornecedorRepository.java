package com.exemplo;

public interface FornecedorRepository extends GenericRepository<Fornecedor, Integer> {
}