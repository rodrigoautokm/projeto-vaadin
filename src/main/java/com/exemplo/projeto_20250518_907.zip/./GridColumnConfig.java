package com.exemplo;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class GridColumnConfig implements Serializable {
    private String gridId;
    private String field;
    private String header;
    private boolean visible;
    private String width;
    private String className;
    private String type;
    private String style;
    private String filterType;
    private String dropdownValues;
    private String alias;

    // Getters e Setters
    public String getGridId() {
        return gridId;
    }

    public void setGridId(String gridId) {
        this.gridId = gridId;
    }

    public String getField() {
        return field;
    }

    public void setField(String field) {
        this.field = field;
    }

    public String getHeader() {
        return header;
    }

    public void setHeader(String header) {
        this.header = header;
    }

    public boolean isVisible() {
        return visible;
    }

    public void setVisible(boolean visible) {
        this.visible = visible;
    }

    public String getWidth() {
        return width;
    }

    public void setWidth(String width) {
        this.width = width;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getStyle() {
        return style;
    }

    public void setStyle(String style) {
        this.style = style;
    }

    public String getFilterType() {
        return filterType;
    }

    public void setFilterType(String filterType) {
        this.filterType = filterType;
    }

    public String getDropdownValues() {
        return dropdownValues;
    }

    public void setDropdownValues(String dropdownValues) {
        this.dropdownValues = dropdownValues;
    }

    public String getAlias() {
        return alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }

    public Map<String, String> getDropdownValueMap() {
        if (dropdownValues == null || dropdownValues.isEmpty()) {
            return null;
        }
        Map<String, String> valueMap = new HashMap<>();
        String[] pairs = dropdownValues.split(";");
        for (String pair : pairs) {
            String[] keyValue = pair.split(":");
            if (keyValue.length == 2) {
                valueMap.put(keyValue[0].trim(), keyValue[1].trim());
            }
        }
        return valueMap.isEmpty() ? null : valueMap;
    }

    @Override
    public String toString() {
        return "GridColumnConfig{" +
               "gridId='" + gridId + '\'' +
               ", field='" + field + '\'' +
               ", header='" + header + '\'' +
               ", visible=" + visible +
               ", width='" + width + '\'' +
               ", className='" + className + '\'' +
               ", type='" + type + '\'' +
               ", style='" + style + '\'' +
               ", filterType='" + filterType + '\'' +
               ", dropdownValues='" + dropdownValues + '\'' +
               ", alias='" + alias + '\'' +
               '}';
    }
}