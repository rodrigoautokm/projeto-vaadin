package com.exemplo;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.security.core.context.SecurityContextHolder;


import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

@Configuration
@EnableJpaRepositories(
        basePackages = "com.exemplo",
        excludeFilters = @org.springframework.context.annotation.ComponentScan.Filter(
                type = org.springframework.context.annotation.FilterType.ASSIGNABLE_TYPE,
                classes = {EmpresaRepository.class, UsuarioAcessoRepository.class}
        ),
        entityManagerFactoryRef = "entityManagerFactory",
        transactionManagerRef = "transactionManager"
)
public class DynamicDataSourceConfig {

    private static final Log logger = LogFactory.getLog(DynamicDataSourceConfig.class);

    @Autowired
    private ConfigurableApplicationContext context;

    @Autowired
    private EmpresaConnectionManager empresaConnectionManager;

    @Bean
    @Primary
    public DataSource dataSource() {
        logger.info("Configurando dataSource dinâmico...");

        AbstractRoutingDataSource routingDataSource = new AbstractRoutingDataSource() {
            @Override
            protected Object determineCurrentLookupKey() {
                try {
                    CustomUserDetails user = (CustomUserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
                    Integer cdEmpresa = user.getCdEmpresa();
                    logger.info("🔁 DataSource dinâmico para empresa: " + cdEmpresa);
                    return cdEmpresa;
                } catch (Exception e) {
                    logger.warn("🔁 Usuário não autenticado ainda, usando banco padrão autokm.");
                    return 0;
                }
            }
        };

        Map<Object, Object> targetDataSources = new HashMap<>();

        // Conexão padrão: autokm (apenas para login)
        Empresa empresaAutokm = new Empresa();
        empresaAutokm.setCd_empresa(0);
        empresaAutokm.setServer_name("autokm");
        empresaAutokm.setNomeBanco("autokm");
        empresaAutokm.setIp_bd("10.0.14.130");
        empresaAutokm.setPorta_bd("2688");
        empresaAutokm.setUsuario_bd("dbo");
        empresaAutokm.setSenha_bd("dircri17");

        EmpresaConnectionManager.configure(empresaAutokm);
        DataSource defaultDataSource = empresaConnectionManager.getDataSourceForEmpresa(0);

        if (defaultDataSource == null) {
            throw new IllegalStateException("DataSource padrão (autokm) não pôde ser configurado.");
        }

        targetDataSources.put(0, defaultDataSource);
        routingDataSource.setDefaultTargetDataSource(defaultDataSource);
        routingDataSource.setTargetDataSources(targetDataSources);
        routingDataSource.afterPropertiesSet();

        return routingDataSource;
    }

    @Bean(name = "entityManagerFactory")
    @Primary
    public LocalContainerEntityManagerFactoryBean entityManagerFactory() {
        logger.info("Configurando entityManagerFactory...");
        LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
        em.setDataSource(dataSource());
        em.setPackagesToScan("com.exemplo");
        em.setJpaVendorAdapter(new HibernateJpaVendorAdapter());

        Map<String, Object> properties = new HashMap<>();
        properties.put("hibernate.dialect", "com.exemplo.SQLAnywhere10Dialect");
        properties.put("hibernate.hbm2ddl.auto", "none");
        properties.put("hibernate.show_sql", true);
        properties.put("hibernate.format_sql", true);
        properties.put("hibernate.connection.charSet", "ISO-8859-1");
        properties.put("hibernate.connection.characterEncoding", "ISO-8859-1");
        properties.put("hibernate.connection.useUnicode", "false");
        em.setJpaPropertyMap(properties);

        return em;
    }

    @Bean(name = "transactionManager")
    @Primary
    public PlatformTransactionManager transactionManager() {
        JpaTransactionManager transactionManager = new JpaTransactionManager();
        transactionManager.setEntityManagerFactory(entityManagerFactory().getObject());
        return transactionManager;
    }

    @Bean
    public DynamicDataSourceSwitcher dynamicDataSourceSwitcher() {
        return new DynamicDataSourceSwitcher(context);
    }
}
