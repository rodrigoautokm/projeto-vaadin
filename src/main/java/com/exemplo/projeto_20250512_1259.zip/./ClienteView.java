package com.exemplo;

import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.grid.GridSortOrder;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.data.provider.SortDirection;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.List;

@PageTitle("Clientes")
@Route(value = "clientes", layout = MainLayout.class)
public class ClienteView extends AbstractGridView<Cliente> {

    private static final Logger logger = LoggerFactory.getLogger(ClienteView.class);

    private final ClienteRepository clienteRepository;
    private final ClienteCadastro clienteCadastro;

    @Autowired
    public ClienteView(ClienteRepository clienteRepository, ClienteCadastro clienteCadastro, GridColumnConfigService gridColumnConfigService) {
        super("Clientes", "clientes", clienteRepository::findAll);
        this.clienteRepository = clienteRepository;
        this.clienteCadastro = clienteCadastro;
        this.gridColumnConfigService = gridColumnConfigService;

        // Adicionar listener de duplo clique diretamente no Grid
        grid.addItemDoubleClickListener(event -> {
            Cliente cliente = event.getItem();
            if (cliente != null) {
                logger.info("Duplo clique detectado no grid");
                logger.info("Cliente selecionado para edição: {}", cliente.getId().getCdCliente());
                openCadastroDialog(cliente);
            }
        });
    }

    @Override
    protected Class<Cliente> getEntityClass() {
        return Cliente.class;
    }

    @Override
    protected List<GridFilterUtil.ColumnConfig<Cliente>> configureColumns() {
        logger.info("Configurando colunas da grid para ClienteView");

        List<GridFilterUtil.ColumnConfig<Cliente>> columnConfigs = new ArrayList<>();
        grid.removeAllColumns();

        List<String> columns = List.of("cd_cliente", "nm_cliente", "tipo", "endereco", "bairro", "fone", "celular", "cpf");
        for (String column : columns) {
            String propertyPath = resolvePropertyPath(column);

            // Criar a coluna no Grid
            Grid.Column<Cliente> gridColumn = grid.addColumn(propertyPath)
                    .setKey(column);

            // Configurar a coluna usando GridColumnConfigService
            String usuarioId = getUsuarioId();
            if (usuarioId == null) {
                usuarioId = "default";
            }
            GridColumnConfig config = gridColumnConfigService.getColumnConfig("clientes", usuarioId, column);
            if (config == null) {
                logger.warn("Configuração não encontrada para o campo: {}. Usando configuração padrão.", column);
                config = new GridColumnConfig();
                config.setField(column);
                config.setHeader(column);
                config.setVisible(true);
                config.setWidth("150px");
                config.setType("STRING");
                config.setStyle("");
                config.setFilterType("EQUALS");
            }

            gridColumn.setHeader(config.getHeader());
            gridColumn.setSortable(true);
            gridColumn.setResizable(true);
            if (config.getWidth() != null) {
                gridColumn.setWidth(config.getWidth());
            }
            gridColumn.setVisible(config.isVisible());

            // Aplicar estilo do XML
            if (config.getStyle() != null && !config.getStyle().isEmpty()) {
                String[] styleRules = config.getStyle().split(";");
                for (String rule : styleRules) {
                    if (rule.trim().isEmpty()) continue;
                    String[] parts = rule.split(":");
                    if (parts.length == 2) {
                        String property = parts[0].trim();
                        String value = parts[1].trim();
                        gridColumn.getElement().getStyle().set(property, value);
                    }
                }
            }

            // Adicionar configuração para GridFilterUtil
            GridFilterUtil.ColumnConfig<Cliente> columnConfig = new GridFilterUtil.ColumnConfig<>(
                gridColumn,
                config.getHeader(),
                item -> {
                    try {
                        String[] parts = propertyPath.split("\\.");
                        Object current = item;
                        for (String part : parts) {
                            java.lang.reflect.Field field = current.getClass().getDeclaredField(part);
                            field.setAccessible(true);
                            current = field.get(current);
                            if (current == null) {
                                return null;
                            }
                        }
                        return current;
                    } catch (Exception e) {
                        logger.error("Erro ao extrair valor para propriedade {}: {}", propertyPath, e.getMessage());
                        return null;
                    }
                },
                config
            );
            columnConfigs.add(columnConfig);
        }

        logger.info("Total de colunas configuradas: {}", grid.getColumns().size());

        // Inicializar filtros
        gridUtil.initialize(gridId, grid, columnConfigs, Cliente::new);

        grid.sort(List.of(new GridSortOrder<>(grid.getColumnByKey("nm_cliente"), SortDirection.ASCENDING)));

        return columnConfigs;
    }

    private String resolvePropertyPath(String fieldName) {
        if ("cd_cliente".equals(fieldName) || "cd_empresa".equals(fieldName)) {
            return "id." + toCamelCase(fieldName);
        }
        return toCamelCase(fieldName);
    }

    private String toCamelCase(String fieldName) {
        StringBuilder camelCase = new StringBuilder();
        boolean capitalizeNext = false;
        for (char c : fieldName.toCharArray()) {
            if (c == '_') {
                capitalizeNext = true;
            } else {
                camelCase.append(capitalizeNext ? Character.toUpperCase(c) : c);
                capitalizeNext = false;
            }
        }
        return camelCase.toString();
    }

    private void openCadastroDialog(Cliente cliente) {
        logger.info("Abrindo diálogo de edição para cliente: {}", cliente.getId().getCdCliente());
        try {
            clienteCadastro.initialize(cliente, updatedCliente -> {
                logger.info("Cliente atualizado: {}", updatedCliente.getId().getCdCliente());
                updateData(clienteRepository.findAll());
            });
            clienteCadastro.open();
        } catch (Exception e) {
            logger.error("Erro ao abrir diálogo de edição: {}", e.getMessage(), e);
            Notification.show("Erro ao abrir a tela de edição: " + e.getMessage(), 3000, Notification.Position.TOP_CENTER);
        }
    }
}