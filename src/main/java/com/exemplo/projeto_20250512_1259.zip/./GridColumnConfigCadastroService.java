package com.exemplo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class GridColumnConfigCadastroService {

    @Autowired
    private ColumnConfigCadastroFactory columnConfigFactory;

    private final Map<String, Map<String, GridColumnConfigCadastro>> cache = new HashMap<>();

    public GridColumnConfigCadastro getColumnConfig(String className, String field) {
        String key = className.toLowerCase();
        cache.computeIfAbsent(key, k -> {
            List<GridColumnConfigCadastro> configs = columnConfigFactory.getColumnConfigs(className, List.of(field));
            Map<String, GridColumnConfigCadastro> map = new HashMap<>();
            for (GridColumnConfigCadastro config : configs) {
                map.put(config.getField(), config);
            }
            return map;
        });
        return cache.get(key).get(field);
    }

    public void limparCache() {
        cache.clear();
    }
}