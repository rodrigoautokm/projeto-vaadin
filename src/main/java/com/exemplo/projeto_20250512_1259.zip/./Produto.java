package com.exemplo;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.sql.Timestamp;
import java.math.BigDecimal;

@Entity
@Table(name = "produto")
public class Produto {

    @Id
    private Integer cdProduto;

    private String nrDigito;
    private String dsProduto;
    private String dsAbreviacao;
    private Short cdSubgrupo;
    private Short cdGrupo;
    private Short cdMarca;
    private Short cdCor;
    private String voltagem;
    private Integer cdFornecedor;
    private String situacao;
    private BigDecimal reducaoIcms;
    private BigDecimal icms;
    private BigDecimal ipi;
    private String classificacaoFiscal;
    private String origemSituacaoTributaria;
    private String situacaoTributaria;
    private BigDecimal vlContabil;
    private BigDecimal vlCompra;
    private BigDecimal vlVenda;
    private BigDecimal vlCusto;
    private BigDecimal comissao;
    private BigDecimal lucro;
    private Integer estoqueMinimo;
    private Integer estoqueMaximo;
    private String cdUnidade;
    private BigDecimal vlCustoMedio;
    private BigDecimal prDescontoVendedor;
    private BigDecimal prDescontoGerente;
    private String saldoNegativo;
    private String cdBarra;
    private Integer nrComponentes;
    private String referencia;
    private Timestamp dtCadastro;
    private String alteraPreco;
    private String prateleira;
    private BigDecimal peso;
    private BigDecimal cubagem;
    private String cdFabrica;
    private Integer capacidade;
    private String combustivel;
    private String renavam;
    private String chassi;
    private String motor;
    private String potencia;
    private Integer anoFabricacao;
    private Integer anoModelo;
    private String cilindrada;
    private String cdPerfil;
    private String cdAcabamento;
    private String gravura;
    private String sombra;
    private String ncm;
    private BigDecimal vlIpi;
    private BigDecimal vlSubstituicao;
    private String cdMontadora;
    private String tamanho;
    private BigDecimal prProteina;
    private String tpProduto;
    private String dsModelo;
    private BigDecimal comissao2;
    private BigDecimal comissao3;
    private String numero;
    private Integer capacidadeVolumetrica;
    private String cdProdutoDnf;
    private BigDecimal kgMilheiro;
    private String nmUsuario;
    private Integer diasEntrega;
    private String classificacao;
    private Integer qtPecasUmVolume;
    private String obsOrcamento;
    private String obsNf;
    private Integer nrMesesGarantia;
    private BigDecimal prDescontoGerente2;
    private BigDecimal prDescontoVendedor2;
    private BigDecimal pesoBruto;
    private String caminhoFoto;
    private BigDecimal vlDec;
    private String montadora;
    private BigDecimal ipiVenda;
    private Integer anoFabricabao;
    private String prioridade;
    private String pisCofins;
    private Timestamp dtVencimentoNota;
    private String cdReceita;
    private Integer cdDespesa;
    private Integer cdTipo;
    private BigDecimal vlMaoObra;
    private String modalidadeBcIcms;
    private String modalidadeBcIcmsSt;
    private String enquadramentoIpi;
    private String situacaoTributariaIpi;
    private String situacaoTributariaPis;
    private BigDecimal prAliquotaPis;
    private String situacaoTributariaCofins;
    private BigDecimal prAliquotaCofins;
    private BigDecimal prAdicionadoSubstituicao;
    private BigDecimal prSubstituicao;
    private Integer cdTipoEntrada;
    private String dsAplicacao;
    private String conversao;
    private BigDecimal prIcmsCompra;
    private String somenteCotacaoCompra;
    private Integer cdGrupoServicoClassificacao;
    private Integer cdServicoClassificacao;
    private String cdTributacaoIss;
    private String cdTipoItemSped;
    private String cdExcecaoNcmSped;
    private String cdGeneroSped;
    private BigDecimal prReducaoIcmsSt;
    private BigDecimal prFatorReducaoSnSt;
    private BigDecimal indiceAjusteMva;
    private String movtoSped;
    private Integer prioridadeOrdem;
    private String alteraDescricaoCompra;
    private String liberaLocacao;
    private String criptografia;
    private String cdAnp;
    private BigDecimal largura;
    private BigDecimal profundidade;
    private BigDecimal altura;
    private String sazonal;
    private Integer nrEspecificacaoIcms;
    private Integer nrEspecificacaoPisCofins;
    private Integer nrEspecificacaoIpi;
    private String situacaoTributariaCompra;
    private BigDecimal prIcmsAjusteMva;
    private BigDecimal prReducaoIcmsCompra;
    private Integer nrEspecificacaoCompras;
    private String nmUsuarioAlteracao;
    private Timestamp dtAlteracao;
    private String cest;
    private BigDecimal prDescontoDemander;
    private String fci;
    private String cdFabricante;
    private String pisCofinsMonofasico;
    private BigDecimal vlBcIcmsStRet;
    private BigDecimal prStRet;
    private BigDecimal vlIcmsRet;
    private BigDecimal vlIcmsStRet;
    private Integer cdSimilaridade;
    private String verificadoAutokm;
    private String dsFabricanteAutokm;
    private BigDecimal qtFracionada;
    private String cdUnidadeFracionada;
    private String cdAliquota;
    private Integer cdProdutoAgrupador;
    private String obsLojaVirtual;
    private String icmsStRetidoAnteriormente;

    // Getters e Setters
    public Integer getCdProduto() {
        return cdProduto;
    }

    public void setCdProduto(Integer cdProduto) {
        this.cdProduto = cdProduto;
    }

    public String getNrDigito() {
        return nrDigito;
    }

    public void setNrDigito(String nrDigito) {
        this.nrDigito = nrDigito;
    }

    public String getDsProduto() {
        return dsProduto;
    }

    public void setDsProduto(String dsProduto) {
        this.dsProduto = dsProduto;
    }

    public String getDsAbreviacao() {
        return dsAbreviacao;
    }

    public void setDsAbreviacao(String dsAbreviacao) {
        this.dsAbreviacao = dsAbreviacao;
    }

    public Short getCdSubgrupo() {
        return cdSubgrupo;
    }

    public void setCdSubgrupo(Short cdSubgrupo) {
        this.cdSubgrupo = cdSubgrupo;
    }

    public Short getCdGrupo() {
        return cdGrupo;
    }

    public void setCdGrupo(Short cdGrupo) {
        this.cdGrupo = cdGrupo;
    }

    public Short getCdMarca() {
        return cdMarca;
    }

    public void setCdMarca(Short cdMarca) {
        this.cdMarca = cdMarca;
    }

    public Short getCdCor() {
        return cdCor;
    }

    public void setCdCor(Short cdCor) {
        this.cdCor = cdCor;
    }

    public String getVoltagem() {
        return voltagem;
    }

    public void setVoltagem(String voltagem) {
        this.voltagem = voltagem;
    }

    public Integer getCdFornecedor() {
        return cdFornecedor;
    }

    public void setCdFornecedor(Integer cdFornecedor) {
        this.cdFornecedor = cdFornecedor;
    }

    public String getSituacao() {
        return situacao;
    }

    public void setSituacao(String situacao) {
        this.situacao = situacao;
    }

    public BigDecimal getReducaoIcms() {
        return reducaoIcms;
    }

    public void setReducaoIcms(BigDecimal reducaoIcms) {
        this.reducaoIcms = reducaoIcms;
    }

    public BigDecimal getIcms() {
        return icms;
    }

    public void setIcms(BigDecimal icms) {
        this.icms = icms;
    }

    public BigDecimal getIpi() {
        return ipi;
    }

    public void setIpi(BigDecimal ipi) {
        this.ipi = ipi;
    }

    public String getClassificacaoFiscal() {
        return classificacaoFiscal;
    }

    public void setClassificacaoFiscal(String classificacaoFiscal) {
        this.classificacaoFiscal = classificacaoFiscal;
    }

    public String getOrigemSituacaoTributaria() {
        return origemSituacaoTributaria;
    }

    public void setOrigemSituacaoTributaria(String origemSituacaoTributaria) {
        this.origemSituacaoTributaria = origemSituacaoTributaria;
    }

    public String getSituacaoTributaria() {
        return situacaoTributaria;
    }

    public void setSituacaoTributaria(String situacaoTributaria) {
        this.situacaoTributaria = situacaoTributaria;
    }

    public BigDecimal getVlContabil() {
        return vlContabil;
    }

    public void setVlContabil(BigDecimal vlContabil) {
        this.vlContabil = vlContabil;
    }

    public BigDecimal getVlCompra() {
        return vlCompra;
    }

    public void setVlCompra(BigDecimal vlCompra) {
        this.vlCompra = vlCompra;
    }

    public BigDecimal getVlVenda() {
        return vlVenda;
    }

    public void setVlVenda(BigDecimal vlVenda) {
        this.vlVenda = vlVenda;
    }

    public BigDecimal getVlCusto() {
        return vlCusto;
    }

    public void setVlCusto(BigDecimal vlCusto) {
        this.vlCusto = vlCusto;
    }

    public BigDecimal getComissao() {
        return comissao;
    }

    public void setComissao(BigDecimal comissao) {
        this.comissao = comissao;
    }

    public BigDecimal getLucro() {
        return lucro;
    }

    public void setLucro(BigDecimal lucro) {
        this.lucro = lucro;
    }

    public Integer getEstoqueMinimo() {
        return estoqueMinimo;
    }

    public void setEstoqueMinimo(Integer estoqueMinimo) {
        this.estoqueMinimo = estoqueMinimo;
    }

    public Integer getEstoqueMaximo() {
        return estoqueMaximo;
    }

    public void setEstoqueMaximo(Integer estoqueMaximo) {
        this.estoqueMaximo = estoqueMaximo;
    }

    public String getCdUnidade() {
        return cdUnidade;
    }

    public void setCdUnidade(String cdUnidade) {
        this.cdUnidade = cdUnidade;
    }

    public BigDecimal getVlCustoMedio() {
        return vlCustoMedio;
    }

    public void setVlCustoMedio(BigDecimal vlCustoMedio) {
        this.vlCustoMedio = vlCustoMedio;
    }

    public BigDecimal getPrDescontoVendedor() {
        return prDescontoVendedor;
    }

    public void setPrDescontoVendedor(BigDecimal prDescontoVendedor) {
        this.prDescontoVendedor = prDescontoVendedor;
    }

    public BigDecimal getPrDescontoGerente() {
        return prDescontoGerente;
    }

    public void setPrDescontoGerente(BigDecimal prDescontoGerente) {
        this.prDescontoGerente = prDescontoGerente;
    }

    public String getSaldoNegativo() {
        return saldoNegativo;
    }

    public void setSaldoNegativo(String saldoNegativo) {
        this.saldoNegativo = saldoNegativo;
    }

    public String getCdBarra() {
        return cdBarra;
    }

    public void setCdBarra(String cdBarra) {
        this.cdBarra = cdBarra;
    }

    public Integer getNrComponentes() {
        return nrComponentes;
    }

    public void setNrComponentes(Integer nrComponentes) {
        this.nrComponentes = nrComponentes;
    }

    public String getReferencia() {
        return referencia;
    }

    public void setReferencia(String referencia) {
        this.referencia = referencia;
    }

    public Timestamp getDtCadastro() {
        return dtCadastro;
    }

    public void setDtCadastro(Timestamp dtCadastro) {
        this.dtCadastro = dtCadastro;
    }

    public String getAlteraPreco() {
        return alteraPreco;
    }

    public void setAlteraPreco(String alteraPreco) {
        this.alteraPreco = alteraPreco;
    }

    public String getPrateleira() {
        return prateleira;
    }

    public void setPrateleira(String prateleira) {
        this.prateleira = prateleira;
    }

    public BigDecimal getPeso() {
        return peso;
    }

    public void setPeso(BigDecimal peso) {
        this.peso = peso;
    }

    public BigDecimal getCubagem() {
        return cubagem;
    }

    public void setCubagem(BigDecimal cubagem) {
        this.cubagem = cubagem;
    }

    public String getCdFabrica() {
        return cdFabrica;
    }

    public void setCdFabrica(String cdFabrica) {
        this.cdFabrica = cdFabrica;
    }

    public Integer getCapacidade() {
        return capacidade;
    }

    public void setCapacidade(Integer capacidade) {
        this.capacidade = capacidade;
    }

    public String getCombustivel() {
        return combustivel;
    }

    public void setCombustivel(String combustivel) {
        this.combustivel = combustivel;
    }

    public String getRenavam() {
        return renavam;
    }

    public void setRenavam(String renavam) {
        this.renavam = renavam;
    }

    public String getChassi() {
        return chassi;
    }

    public void setChassi(String chassi) {
        this.chassi = chassi;
    }

    public String getMotor() {
        return motor;
    }

    public void setMotor(String motor) {
        this.motor = motor;
    }

    public String getPotencia() {
        return potencia;
    }

    public void setPotencia(String potencia) {
        this.potencia = potencia;
    }

    public Integer getAnoFabricacao() {
        return anoFabricacao;
    }

    public void setAnoFabricacao(Integer anoFabricacao) {
        this.anoFabricacao = anoFabricacao;
    }

    public Integer getAnoModelo() {
        return anoModelo;
    }

    public void setAnoModelo(Integer anoModelo) {
        this.anoModelo = anoModelo;
    }

    public String getCilindrada() {
        return cilindrada;
    }

    public void setCilindrada(String cilindrada) {
        this.cilindrada = cilindrada;
    }

    public String getCdPerfil() {
        return cdPerfil;
    }

    public void setCdPerfil(String cdPerfil) {
        this.cdPerfil = cdPerfil;
    }

    public String getCdAcabamento() {
        return cdAcabamento;
    }

    public void setCdAcabamento(String cdAcabamento) {
        this.cdAcabamento = cdAcabamento;
    }

    public String getGravura() {
        return gravura;
    }

    public void setGravura(String gravura) {
        this.gravura = gravura;
    }

    public String getSombra() {
        return sombra;
    }

    public void setSombra(String sombra) {
        this.sombra = sombra;
    }

    public String getNcm() {
        return ncm;
    }

    public void setNcm(String ncm) {
        this.ncm = ncm;
    }

    public BigDecimal getVlIpi() {
        return vlIpi;
    }

    public void setVlIpi(BigDecimal vlIpi) {
        this.vlIpi = vlIpi;
    }

    public BigDecimal getVlSubstituicao() {
        return vlSubstituicao;
    }

    public void setVlSubstituicao(BigDecimal vlSubstituicao) {
        this.vlSubstituicao = vlSubstituicao;
    }

    public String getCdMontadora() {
        return cdMontadora;
    }

    public void setCdMontadora(String cdMontadora) {
        this.cdMontadora = cdMontadora;
    }

    public String getTamanho() {
        return tamanho;
    }

    public void setTamanho(String tamanho) {
        this.tamanho = tamanho;
    }

    public BigDecimal getPrProteina() {
        return prProteina;
    }

    public void setPrProteina(BigDecimal prProteina) {
        this.prProteina = prProteina;
    }

    public String getTpProduto() {
        return tpProduto;
    }

    public void setTpProduto(String tpProduto) {
        this.tpProduto = tpProduto;
    }

    public String getDsModelo() {
        return dsModelo;
    }

    public void setDsModelo(String dsModelo) {
        this.dsModelo = dsModelo;
    }

    public BigDecimal getComissao2() {
        return comissao2;
    }

    public void setComissao2(BigDecimal comissao2) {
        this.comissao2 = comissao2;
    }

    public BigDecimal getComissao3() {
        return comissao3;
    }

    public void setComissao3(BigDecimal comissao3) {
        this.comissao3 = comissao3;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public Integer getCapacidadeVolumetrica() {
        return capacidadeVolumetrica;
    }

    public void setCapacidadeVolumetrica(Integer capacidadeVolumetrica) {
        this.capacidadeVolumetrica = capacidadeVolumetrica;
    }

    public String getCdProdutoDnf() {
        return cdProdutoDnf;
    }

    public void setCdProdutoDnf(String cdProdutoDnf) {
        this.cdProdutoDnf = cdProdutoDnf;
    }

    public BigDecimal getKgMilheiro() {
        return kgMilheiro;
    }

    public void setKgMilheiro(BigDecimal kgMilheiro) {
        this.kgMilheiro = kgMilheiro;
    }

    public String getNmUsuario() {
        return nmUsuario;
    }

    public void setNmUsuario(String nmUsuario) {
        this.nmUsuario = nmUsuario;
    }

    public Integer getDiasEntrega() {
        return diasEntrega;
    }

    public void setDiasEntrega(Integer diasEntrega) {
        this.diasEntrega = diasEntrega;
    }

    public String getClassificacao() {
        return classificacao;
    }

    public void setClassificacao(String classificacao) {
        this.classificacao = classificacao;
    }

    public Integer getQtPecasUmVolume() {
        return qtPecasUmVolume;
    }

    public void setQtPecasUmVolume(Integer qtPecasUmVolume) {
        this.qtPecasUmVolume = qtPecasUmVolume;
    }

    public String getObsOrcamento() {
        return obsOrcamento;
    }

    public void setObsOrcamento(String obsOrcamento) {
        this.obsOrcamento = obsOrcamento;
    }

    public String getObsNf() {
        return obsNf;
    }

    public void setObsNf(String obsNf) {
        this.obsNf = obsNf;
    }

    public Integer getNrMesesGarantia() {
        return nrMesesGarantia;
    }

    public void setNrMesesGarantia(Integer nrMesesGarantia) {
        this.nrMesesGarantia = nrMesesGarantia;
    }

    public BigDecimal getPrDescontoGerente2() {
        return prDescontoGerente2;
    }

    public void setPrDescontoGerente2(BigDecimal prDescontoGerente2) {
        this.prDescontoGerente2 = prDescontoGerente2;
    }

    public BigDecimal getPrDescontoVendedor2() {
        return prDescontoVendedor2;
    }

    public void setPrDescontoVendedor2(BigDecimal prDescontoVendedor2) {
        this.prDescontoVendedor2 = prDescontoVendedor2;
    }

    public BigDecimal getPesoBruto() {
        return pesoBruto;
    }

    public void setPesoBruto(BigDecimal pesoBruto) {
        this.pesoBruto = pesoBruto;
    }

    public String getCaminhoFoto() {
        return caminhoFoto;
    }

    public void setCaminhoFoto(String caminhoFoto) {
        this.caminhoFoto = caminhoFoto;
    }

    public BigDecimal getVlDec() {
        return vlDec;
    }

    public void setVlDec(BigDecimal vlDec) {
        this.vlDec = vlDec;
    }

    public String getMontadora() {
        return montadora;
    }

    public void setMontadora(String montadora) {
        this.montadora = montadora;
    }

    public BigDecimal getIpiVenda() {
        return ipiVenda;
    }

    public void setIpiVenda(BigDecimal ipiVenda) {
        this.ipiVenda = ipiVenda;
    }

    public Integer getAnoFabricabao() {
        return anoFabricabao;
    }

    public void setAnoFabricabao(Integer anoFabricabao) {
        this.anoFabricabao = anoFabricabao;
    }

    public String getPrioridade() {
        return prioridade;
    }

    public void setPrioridade(String prioridade) {
        this.prioridade = prioridade;
    }

    public String getPisCofins() {
        return pisCofins;
    }

    public void setPisCofins(String pisCofins) {
        this.pisCofins = pisCofins;
    }

    public Timestamp getDtVencimentoNota() {
        return dtVencimentoNota;
    }

    public void setDtVencimentoNota(Timestamp dtVencimentoNota) {
        this.dtVencimentoNota = dtVencimentoNota;
    }

    public String getCdReceita() {
        return cdReceita;
    }

    public void setCdReceita(String cdReceita) {
        this.cdReceita = cdReceita;
    }

    public Integer getCdDespesa() {
        return cdDespesa;
    }

    public void setCdDespesa(Integer cdDespesa) {
        this.cdDespesa = cdDespesa;
    }

    public Integer getCdTipo() {
        return cdTipo;
    }

    public void setCdTipo(Integer cdTipo) {
        this.cdTipo = cdTipo;
    }

    public BigDecimal getVlMaoObra() {
        return vlMaoObra;
    }

    public void setVlMaoObra(BigDecimal vlMaoObra) {
        this.vlMaoObra = vlMaoObra;
    }

    public String getModalidadeBcIcms() {
        return modalidadeBcIcms;
    }

    public void setModalidadeBcIcms(String modalidadeBcIcms) {
        this.modalidadeBcIcms = modalidadeBcIcms;
    }

    public String getModalidadeBcIcmsSt() {
        return modalidadeBcIcmsSt;
    }

    public void setModalidadeBcIcmsSt(String modalidadeBcIcmsSt) {
        this.modalidadeBcIcmsSt = modalidadeBcIcmsSt;
    }

    public String getEnquadramentoIpi() {
        return enquadramentoIpi;
    }

    public void setEnquadramentoIpi(String enquadramentoIpi) {
        this.enquadramentoIpi = enquadramentoIpi;
    }

    public String getSituacaoTributariaIpi() {
        return situacaoTributariaIpi;
    }

    public void setSituacaoTributariaIpi(String situacaoTributariaIpi) {
        this.situacaoTributariaIpi = situacaoTributariaIpi;
    }

    public String getSituacaoTributariaPis() {
        return situacaoTributariaPis;
    }

    public void setSituacaoTributariaPis(String situacaoTributariaPis) {
        this.situacaoTributariaPis = situacaoTributariaPis;
    }

    public BigDecimal getPrAliquotaPis() {
        return prAliquotaPis;
    }

    public void setPrAliquotaPis(BigDecimal prAliquotaPis) {
        this.prAliquotaPis = prAliquotaPis;
    }

    public String getSituacaoTributariaCofins() {
        return situacaoTributariaCofins;
    }

    public void setSituacaoTributariaCofins(String situacaoTributariaCofins) {
        this.situacaoTributariaCofins = situacaoTributariaCofins;
    }

    public BigDecimal getPrAliquotaCofins() {
        return prAliquotaCofins;
    }

    public void setPrAliquotaCofins(BigDecimal prAliquotaCofins) {
        this.prAliquotaCofins = prAliquotaCofins;
    }

    public BigDecimal getPrAdicionadoSubstituicao() {
        return prAdicionadoSubstituicao;
    }

    public void setPrAdicionadoSubstituicao(BigDecimal prAdicionadoSubstituicao) {
        this.prAdicionadoSubstituicao = prAdicionadoSubstituicao;
    }

    public BigDecimal getPrSubstituicao() {
        return prSubstituicao;
    }

    public void setPrSubstituicao(BigDecimal prSubstituicao) {
        this.prSubstituicao = prSubstituicao;
    }

    public Integer getCdTipoEntrada() {
        return cdTipoEntrada;
    }

    public void setCdTipoEntrada(Integer cdTipoEntrada) {
        this.cdTipoEntrada = cdTipoEntrada;
    }

    public String getDsAplicacao() {
        return dsAplicacao;
    }

    public void setDsAplicacao(String dsAplicacao) {
        this.dsAplicacao = dsAplicacao;
    }

    public String getConversao() {
        return conversao;
    }

    public void setConversao(String conversao) {
        this.conversao = conversao;
    }

    public BigDecimal getPrIcmsCompra() {
        return prIcmsCompra;
    }

    public void setPrIcmsCompra(BigDecimal prIcmsCompra) {
        this.prIcmsCompra = prIcmsCompra;
    }

    public String getSomenteCotacaoCompra() {
        return somenteCotacaoCompra;
    }

    public void setSomenteCotacaoCompra(String somenteCotacaoCompra) {
        this.somenteCotacaoCompra = somenteCotacaoCompra;
    }

    public Integer getCdGrupoServicoClassificacao() {
        return cdGrupoServicoClassificacao;
    }

    public void setCdGrupoServicoClassificacao(Integer cdGrupoServicoClassificacao) {
        this.cdGrupoServicoClassificacao = cdGrupoServicoClassificacao;
    }

    public Integer getCdServicoClassificacao() {
        return cdServicoClassificacao;
    }

    public void setCdServicoClassificacao(Integer cdServicoClassificacao) {
        this.cdServicoClassificacao = cdServicoClassificacao;
    }

    public String getCdTributacaoIss() {
        return cdTributacaoIss;
    }

    public void setCdTributacaoIss(String cdTributacaoIss) {
        this.cdTributacaoIss = cdTributacaoIss;
    }

    public String getCdTipoItemSped() {
        return cdTipoItemSped;
    }

    public void setCdTipoItemSped(String cdTipoItemSped) {
        this.cdTipoItemSped = cdTipoItemSped;
    }

    public String getCdExcecaoNcmSped() {
        return cdExcecaoNcmSped;
    }

    public void setCdExcecaoNcmSped(String cdExcecaoNcmSped) {
        this.cdExcecaoNcmSped = cdExcecaoNcmSped;
    }

    public String getCdGeneroSped() {
        return cdGeneroSped;
    }

    public void setCdGeneroSped(String cdGeneroSped) {
        this.cdGeneroSped = cdGeneroSped;
    }

    public BigDecimal getPrReducaoIcmsSt() {
        return prReducaoIcmsSt;
    }

    public void setPrReducaoIcmsSt(BigDecimal prReducaoIcmsSt) {
        this.prReducaoIcmsSt = prReducaoIcmsSt;
    }

    public BigDecimal getPrFatorReducaoSnSt() {
        return prFatorReducaoSnSt;
    }

    public void setPrFatorReducaoSnSt(BigDecimal prFatorReducaoSnSt) {
        this.prFatorReducaoSnSt = prFatorReducaoSnSt;
    }

    public BigDecimal getIndiceAjusteMva() {
        return indiceAjusteMva;
    }

    public void setIndiceAjusteMva(BigDecimal indiceAjusteMva) {
        this.indiceAjusteMva = indiceAjusteMva;
    }

    public String getMovtoSped() {
        return movtoSped;
    }

    public void setMovtoSped(String movtoSped) {
        this.movtoSped = movtoSped;
    }

    public Integer getPrioridadeOrdem() {
        return prioridadeOrdem;
    }

    public void setPrioridadeOrdem(Integer prioridadeOrdem) {
        this.prioridadeOrdem = prioridadeOrdem;
    }

    public String getAlteraDescricaoCompra() {
        return alteraDescricaoCompra;
    }

    public void setAlteraDescricaoCompra(String alteraDescricaoCompra) {
        this.alteraDescricaoCompra = alteraDescricaoCompra;
    }

    public String getLiberaLocacao() {
        return liberaLocacao;
    }

    public void setLiberaLocacao(String liberaLocacao) {
        this.liberaLocacao = liberaLocacao;
    }

    public String getCriptografia() {
        return criptografia;
    }

    public void setCriptografia(String criptografia) {
        this.criptografia = criptografia;
    }

    public String getCdAnp() {
        return cdAnp;
    }

    public void setCdAnp(String cdAnp) {
        this.cdAnp = cdAnp;
    }

    public BigDecimal getLargura() {
        return largura;
    }

    public void setLargura(BigDecimal largura) {
        this.largura = largura;
    }

    public BigDecimal getProfundidade() {
        return profundidade;
    }

    public void setProfundidade(BigDecimal profundidade) {
        this.profundidade = profundidade;
    }

    public BigDecimal getAltura() {
        return altura;
    }

    public void setAltura(BigDecimal altura) {
        this.altura = altura;
    }

    public String getSazonal() {
        return sazonal;
    }

    public void setSazonal(String sazonal) {
        this.sazonal = sazonal;
    }

    public Integer getNrEspecificacaoIcms() {
        return nrEspecificacaoIcms;
    }

    public void setNrEspecificacaoIcms(Integer nrEspecificacaoIcms) {
        this.nrEspecificacaoIcms = nrEspecificacaoIcms;
    }

    public Integer getNrEspecificacaoPisCofins() {
        return nrEspecificacaoPisCofins;
    }

    public void setNrEspecificacaoPisCofins(Integer nrEspecificacaoPisCofins) {
        this.nrEspecificacaoPisCofins = nrEspecificacaoPisCofins;
    }

    public Integer getNrEspecificacaoIpi() {
        return nrEspecificacaoIpi;
    }

    public void setNrEspecificacaoIpi(Integer nrEspecificacaoIpi) {
        this.nrEspecificacaoIpi = nrEspecificacaoIpi;
    }

    public String getSituacaoTributariaCompra() {
        return situacaoTributariaCompra;
    }

    public void setSituacaoTributariaCompra(String situacaoTributariaCompra) {
        this.situacaoTributariaCompra = situacaoTributariaCompra;
    }

    public BigDecimal getPrIcmsAjusteMva() {
        return prIcmsAjusteMva;
    }

    public void setPrIcmsAjusteMva(BigDecimal prIcmsAjusteMva) {
        this.prIcmsAjusteMva = prIcmsAjusteMva;
    }

    public BigDecimal getPrReducaoIcmsCompra() {
        return prReducaoIcmsCompra;
    }

    public void setPrReducaoIcmsCompra(BigDecimal prReducaoIcmsCompra) {
        this.prReducaoIcmsCompra = prReducaoIcmsCompra;
    }

    public Integer getNrEspecificacaoCompras() {
        return nrEspecificacaoCompras;
    }

    public void setNrEspecificacaoCompras(Integer nrEspecificacaoCompras) {
        this.nrEspecificacaoCompras = nrEspecificacaoCompras;
    }

    public String getNmUsuarioAlteracao() {
        return nmUsuarioAlteracao;
    }

    public void setNmUsuarioAlteracao(String nmUsuarioAlteracao) {
        this.nmUsuarioAlteracao = nmUsuarioAlteracao;
    }

    public Timestamp getDtAlteracao() {
        return dtAlteracao;
    }

    public void setDtAlteracao(Timestamp dtAlteracao) {
        this.dtAlteracao = dtAlteracao;
    }

    public String getCest() {
        return cest;
    }

    public void setCest(String cest) {
        this.cest = cest;
    }

    public BigDecimal getPrDescontoDemander() {
        return prDescontoDemander;
    }

    public void setPrDescontoDemander(BigDecimal prDescontoDemander) {
        this.prDescontoDemander = prDescontoDemander;
    }

    public String getFci() {
        return fci;
    }

    public void setFci(String fci) {
        this.fci = fci;
    }

    public String getCdFabricante() {
        return cdFabricante;
    }

    public void setCdFabricante(String cdFabricante) {
        this.cdFabricante = cdFabricante;
    }

    public String getPisCofinsMonofasico() {
        return pisCofinsMonofasico;
    }

    public void setPisCofinsMonofasico(String pisCofinsMonofasico) {
        this.pisCofinsMonofasico = pisCofinsMonofasico;
    }

    public BigDecimal getVlBcIcmsStRet() {
        return vlBcIcmsStRet;
    }

    public void setVlBcIcmsStRet(BigDecimal vlBcIcmsStRet) {
        this.vlBcIcmsStRet = vlBcIcmsStRet;
    }

    public BigDecimal getPrStRet() {
        return prStRet;
    }

    public void setPrStRet(BigDecimal prStRet) {
        this.prStRet = prStRet;
    }

    public BigDecimal getVlIcmsRet() {
        return vlIcmsRet;
    }

    public void setVlIcmsRet(BigDecimal vlIcmsRet) {
        this.vlIcmsRet = vlIcmsRet;
    }

    public BigDecimal getVlIcmsStRet() {
        return vlIcmsStRet;
    }

    public void setVlIcmsStRet(BigDecimal vlIcmsStRet) {
        this.vlIcmsStRet = vlIcmsStRet;
    }

    public Integer getCdSimilaridade() {
        return cdSimilaridade;
    }

    public void setCdSimilaridade(Integer cdSimilaridade) {
        this.cdSimilaridade = cdSimilaridade;
    }

    public String getVerificadoAutokm() {
        return verificadoAutokm;
    }

    public void setVerificadoAutokm(String verificadoAutokm) {
        this.verificadoAutokm = verificadoAutokm;
    }

    public String getDsFabricanteAutokm() {
        return dsFabricanteAutokm;
    }

    public void setDsFabricanteAutokm(String dsFabricanteAutokm) {
        this.dsFabricanteAutokm = dsFabricanteAutokm;
    }

    public BigDecimal getQtFracionada() {
        return qtFracionada;
    }

    public void setQtFracionada(BigDecimal qtFracionada) {
        this.qtFracionada = qtFracionada;
    }

    public String getCdUnidadeFracionada() {
        return cdUnidadeFracionada;
    }

    public void setCdUnidadeFracionada(String cdUnidadeFracionada) {
        this.cdUnidadeFracionada = cdUnidadeFracionada;
    }

    public String getCdAliquota() {
        return cdAliquota;
    }

    public void setCdAliquota(String cdAliquota) {
        this.cdAliquota = cdAliquota;
    }

    public Integer getCdProdutoAgrupador() {
        return cdProdutoAgrupador;
    }

    public void setCdProdutoAgrupador(Integer cdProdutoAgrupador) {
        this.cdProdutoAgrupador = cdProdutoAgrupador;
    }

    public String getObsLojaVirtual() {
        return obsLojaVirtual;
    }

    public void setObsLojaVirtual(String obsLojaVirtual) {
        this.obsLojaVirtual = obsLojaVirtual;
    }

    public String getIcmsStRetidoAnteriormente() {
        return icmsStRetidoAnteriormente;
    }

    public void setIcmsStRetidoAnteriormente(String icmsStRetidoAnteriormente) {
        this.icmsStRetidoAnteriormente = icmsStRetidoAnteriormente;
    }
}