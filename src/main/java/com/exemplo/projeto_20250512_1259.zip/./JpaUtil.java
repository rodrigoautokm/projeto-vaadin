package com.exemplo;

import org.hibernate.jpa.HibernatePersistenceProvider;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.sql.DataSource;
import java.util.HashMap;
import java.util.Map;

public class JpaUtil {

    public static EntityManager getEntityManager(DataSource dataSource) {
        Map<String, Object> properties = new HashMap<>();
        properties.put("hibernate.connection.datasource", dataSource);
        properties.put("hibernate.dialect", "org.hibernate.dialect.SQLAnywhereDialect");
        properties.put("hibernate.show_sql", false);
        properties.put("hibernate.format_sql", false);
        properties.put("hibernate.hbm2ddl.auto", "none");
        properties.put("hibernate.temp.use_jdbc_metadata_defaults", false);
        properties.put("hibernate.connection.characterEncoding", "ISO-8859-1");

        EntityManagerFactory emf = new HibernatePersistenceProvider()
                .createEntityManagerFactory("dynamic-unit", properties);
        return emf.createEntityManager();
    }
}
