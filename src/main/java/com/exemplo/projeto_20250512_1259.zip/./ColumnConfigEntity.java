package com.exemplo;

import javax.persistence.*;

@Entity
@Table(name = "column_config")
public class ColumnConfigEntity {

    @Id
    private Integer id;

    @Column(name = "class_name")
    private String className;

    @Column(name = "usuario")
    private String usuario;

    @Column(name = "field_name")
    private String fieldName;

    @Column(name = "header")
    private String header;

    @Column(name = "visible")
    private String visible;

    @Column(name = "width")
    private String width;

    @Column(name = "data_type")
    private String dataType;

    @Column(name = "style")
    private String style;

    @Column(name = "filter_type")
    private String filterType;

    @Column(name = "dropdown_values")
    private String dropdownValues;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getFieldName() {
        return fieldName;
    }

    public void setFieldName(String fieldName) {
        this.fieldName = fieldName;
    }

    public String getHeader() {
        return header;
    }

    public void setHeader(String header) {
        this.header = header;
    }

    public String getVisible() {
        return visible;
    }

    public void setVisible(String visible) {
        this.visible = visible;
    }

    public String getWidth() {
        return width;
    }

    public void setWidth(String width) {
        this.width = width;
    }

    public String getDataType() {
        return dataType;
    }

    public void setDataType(String dataType) {
        this.dataType = dataType;
    }

    public String getStyle() {
        return style;
    }

    public void setStyle(String style) {
        this.style = style;
    }

    public String getFilterType() {
        return filterType;
    }

    public void setFilterType(String filterType) {
        this.filterType = filterType;
    }

    public String getDropdownValues() {
        return dropdownValues;
    }

    public void setDropdownValues(String dropdownValues) {
        this.dropdownValues = dropdownValues;
    }
}