package com.exemplo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;

@Service
public class SortConfigService {

    @Autowired
    private SortConfigRepository repository;

    @Transactional
    public void salvarSortConfig(String usuario, String viewId, String sortColumn, String sortDirection) {
        SortConfigId id = new SortConfigId(usuario, viewId);
        SortConfig config = new SortConfig();
        config.setId(id);
        config.setSortColumn(sortColumn);
        config.setSortDirection(sortDirection);
        repository.save(config);
    }

    public SortConfig obterConfig(String usuario, String viewId) {
        return repository.findById(new SortConfigId(usuario, viewId)).orElse(null);
    }
}