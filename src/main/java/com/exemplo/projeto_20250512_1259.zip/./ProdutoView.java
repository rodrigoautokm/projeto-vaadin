package com.exemplo;

import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.grid.GridSortOrder;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.data.provider.SortDirection;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.Objects;

@Route(value = "produtos", layout = MainLayout.class)
public class ProdutoView extends AbstractGridView<Produto> {

    private static final Logger logger = LoggerFactory.getLogger(ProdutoView.class);

    private final GridColumnConfigService columnConfigService;
    private final ProdutoService produtoService;
    private final ProdutoCadastro produtoCadastro;

    @Autowired
    public ProdutoView(ProdutoService produtoService, GridColumnConfigService columnConfigService, ProdutoCadastro produtoCadastro) {
        super("Produtos", "produtos", produtoService::listar);
        this.columnConfigService = columnConfigService;
        this.produtoService = produtoService;
        this.produtoCadastro = produtoCadastro;
        logger.info("Inicializando ProdutoView");
        logger.info("produtoCadastro injetado: {}", produtoCadastro != null ? "Sim" : "Não");

        // Configurar o grid para permitir seleção de um único produto
        grid.setSelectionMode(Grid.SelectionMode.SINGLE);

        // Adicionar botões "Novo Produto" e "Editar Produto" acima do grid
        Button newProductButton = new Button("Novo Produto", new Icon(VaadinIcon.PLUS));
        newProductButton.addClickListener(event -> {
            logger.info("Botão 'Novo Produto' clicado");
            Produto novoProduto = new Produto();
            novoProduto.setCdProduto(getNextCdProduto());
            openCadastroDialog(novoProduto);
        });

        Button editProductButton = new Button("Editar Produto", new Icon(VaadinIcon.EDIT));
        editProductButton.addClickListener(event -> {
            logger.info("Botão 'Editar Produto' clicado");
            Set<Produto> selectedItems = grid.getSelectedItems();
            if (selectedItems.isEmpty()) {
                logger.warn("Nenhum produto selecionado para edição");
                Notification.show("Por favor, selecione um produto para editar.", 3000, Notification.Position.TOP_CENTER);
                return;
            }
            Produto produto = selectedItems.iterator().next();
            openCadastroDialog(produto);
        });

        HorizontalLayout buttonLayout = new HorizontalLayout(newProductButton, editProductButton);
        buttonLayout.setWidthFull();
        add(buttonLayout);

        // Adicionar listener de duplo clique para abrir o diálogo de edição
        grid.addItemDoubleClickListener(event -> {
            logger.info("Duplo clique detectado no grid");
            Produto produto = event.getItem();
            if (produto != null) {
                logger.info("Produto selecionado para edição: {}", produto.getCdProduto());
                openCadastroDialog(produto);
            } else {
                logger.warn("Nenhum produto selecionado ao dar duplo clique");
                Notification.show("Nenhum produto selecionado.", 3000, Notification.Position.TOP_CENTER);
            }
        });
    }

    @Override
    protected Class<Produto> getEntityClass() {
        return Produto.class;
    }

    @Override
    protected List<GridFilterUtil.ColumnConfig<Produto>> configureColumns() {
        logger.info("Configurando colunas da grid para ProdutoView");

        List<GridFilterUtil.ColumnConfig<Produto>> columnConfigs = new ArrayList<>();
        grid.removeAllColumns();

        String[] fields = {
            "cd_produto", "nr_digito", "ds_produto", "ds_abreviacao", "cd_subgrupo", "cd_grupo", "cd_marca",
            "cd_cor", "voltagem", "cd_fornecedor", "situacao", "reducao_icms", "icms", "ipi", "classificacao_fiscal",
            "origem_situacao_tributaria", "situacao_tributaria", "vl_contabil", "vl_compra", "vl_venda", "vl_custo",
            "comissao", "lucro", "estoque_minimo", "estoque_maximo", "cd_unidade", "vl_custo_medio",
            "pr_desconto_vendedor", "pr_desconto_gerente", "saldo_negativo", "cd_barra", "nr_componentes",
            "referencia", "dt_cadastro", "altera_preco", "prateleira", "peso", "cubagem", "cd_fabrica",
            "capacidade", "combustivel", "renavam", "chassi", "motor", "potencia", "ano_fabricacao", "ano_modelo",
            "cilindrada", "cd_perfil", "cd_acabamento", "gravura", "sombra", "ncm", "vl_ipi", "vl_substituicao",
            "cd_montadora", "tamanho", "pr_proteina", "tp_produto", "ds_modelo", "comissao2", "comissao3", "numero",
            "capacidade_volumetrica", "cd_produto_dnf", "kg_milheiro", "nm_usuario", "dias_entrega",
            "classificacao", "qt_pecas_um_volume", "obs_orcamento", "obs_nf", "nr_meses_garantia",
            "pr_desconto_gerente_2", "pr_desconto_vendedor_2", "peso_bruto", "caminho_foto", "vl_dec",
            "montadora", "ipi_venda", "ano_fabricabao", "prioridade", "pis_cofins", "dt_vencimento_nota",
            "cd_receita", "cd_despesa", "cd_tipo", "vl_mao_obra", "modalidade_bc_icms", "modalidade_bc_icms_st",
            "enquadramento_ipi", "situacao_tributaria_ipi", "situacao_tributaria_pis", "pr_aliquota_pis",
            "situacao_tributaria_cofins", "pr_aliquota_cofins", "pr_adicionado_substituicao", "pr_substituicao",
            "cd_tipo_entrada", "ds_aplicacao", "conversao", "pr_icms_compra", "somente_cotacao_compra",
            "cd_grupo_servico_classificacao", "cd_servico_classificacao", "cd_tributacao_iss", "cd_tipo_item_sped",
            "cd_excecao_ncm_sped", "cd_genero_sped", "pr_reducao_icms_st", "pr_fator_reducao_sn_st",
            "indice_ajuste_mva", "movto_sped", "prioridade_ordem", "altera_descricao_compra", "libera_locacao",
            "criptografia", "cd_anp", "largura", "profundidade", "altura", "sazonal", "nr_especificacao_icms",
            "nr_especificacao_pis_cofins", "nr_especificacao_ipi", "situacao_tributaria_compra",
            "pr_icms_ajuste_mva", "pr_reducao_icms_compra", "nr_especificacao_compras", "nm_usuario_alteracao",
            "dt_alteracao", "cest", "pr_desconto_demander", "fci", "cd_fabricante", "pis_cofins_monofasico",
            "vl_bc_icms_st_ret", "pr_st_ret", "vl_icms_ret", "vl_icms_st_ret", "cd_similaridade",
            "verificado_autokm", "ds_fabricante_autokm", "qt_fracionada", "cd_unidade_fracionada", "cd_aliquota",
            "cd_produto_agrupador", "obs_loja_virtual", "icms_st_retido_anteriormente"
        };

        for (String field : fields) {
            String propertyPath = toCamelCase(field);
            Grid.Column<Produto> gridColumn = grid.addColumn(propertyPath)
                    .setKey(field);

            String usuarioId = getUsuarioId();
            if (usuarioId == null) {
                usuarioId = "default";
            }
            GridColumnConfig config = columnConfigService.getColumnConfig("produtos", usuarioId, field);
            if (config == null) {
                logger.warn("Configuração não encontrada para o campo: {}. Usando configuração padrão.", field);
                config = new GridColumnConfig();
                config.setField(field);
                config.setHeader(field);
                config.setVisible(true);
                config.setWidth("100px");
                config.setType("STRING");
                config.setStyle("");
                config.setFilterType("EQUALS");
            }

            logger.debug("Configuração para o campo {}: header={}, visible={}, width={}, type={}, style={}",
                    field, config.getHeader(), config.isVisible(), config.getWidth(), config.getType(), config.getStyle());

            gridColumn.setHeader(config.getHeader());
            gridColumn.setWidth(config.getWidth());
            gridColumn.setSortable(true);
            gridColumn.setVisible(config.isVisible());

            // Aplicar estilo do XML
            if (config.getStyle() != null && !config.getStyle().isEmpty()) {
                String[] styleRules = config.getStyle().split(";");
                for (String rule : styleRules) {
                    if (rule.trim().isEmpty()) continue;
                    String[] parts = rule.split(":");
                    if (parts.length == 2) {
                        String property = parts[0].trim();
                        String value = parts[1].trim();
                        gridColumn.getElement().getStyle().set(property, value);
                    }
                }
            }

            GridFilterUtil.ColumnConfig<Produto> columnConfig = new GridFilterUtil.ColumnConfig<>(
                    gridColumn,
                    config.getHeader(),
                    item -> {
                        try {
                            String[] parts = propertyPath.split("\\.");
                            Object current = item;
                            for (String part : parts) {
                                java.lang.reflect.Field fieldObj = current.getClass().getDeclaredField(part);
                                fieldObj.setAccessible(true);
                                current = fieldObj.get(current);
                                if (current == null) {
                                    return null;
                                }
                            }
                            return current;
                        } catch (Exception e) {
                            logger.error("Erro ao extrair valor para propriedade {}: {}", propertyPath, e.getMessage());
                            return null;
                        }
                    },
                    config
            );
            columnConfigs.add(columnConfig);
        }

        logger.info("Total de colunas configuradas: {}", grid.getColumns().size());

        gridUtil.initialize(gridId, grid, columnConfigs, Produto::new);

        grid.sort(List.of(new GridSortOrder<>(grid.getColumnByKey("ds_produto"), SortDirection.ASCENDING)));

        return columnConfigs;
    }

    private void openCadastroDialog(Produto produto) {
        logger.info("Abrindo diálogo de edição para produto: {}", produto.getCdProduto());
        try {
            produtoCadastro.initialize(produto, updatedProduto -> {
                logger.info("Produto atualizado: {}", updatedProduto.getCdProduto());
                List<Produto> updatedList = produtoService.listar();
                if (updatedList == null) {
                    logger.warn("Lista de produtos retornada por produtoService.listar() é nula. Usando lista vazia.");
                    updatedList = new ArrayList<>();
                }
                updateData(updatedList);
            });
            logger.info("Chamando produtoCadastro.open()");
            produtoCadastro.open();
            logger.info("Diálogo de edição aberto com sucesso");
        } catch (Exception e) {
            logger.error("Erro ao abrir diálogo de edição: {}", e.getMessage(), e);
            Notification.show("Erro ao abrir a tela de edição: " + e.getMessage(), 3000, Notification.Position.TOP_CENTER);
        }
    }

    private Integer getNextCdProduto() {
        logger.info("Calculando próximo cd_produto");
        List<Produto> produtos = produtoService.listar();
        if (produtos == null || produtos.isEmpty()) {
            logger.warn("Nenhum produto encontrado para calcular próximo cd_produto. Retornando 1.");
            return 1;
        }
        return produtos.stream()
                .map(Produto::getCdProduto)
                .filter(Objects::nonNull)
                .max(Integer::compareTo)
                .map(max -> max + 1)
                .orElse(1);
    }

    private String toCamelCase(String fieldName) {
        StringBuilder camelCase = new StringBuilder();
        boolean capitalizeNext = false;
        for (char c : fieldName.toCharArray()) {
            if (c == '_') {
                capitalizeNext = true;
            } else {
                camelCase.append(capitalizeNext ? Character.toUpperCase(c) : c);
                capitalizeNext = false;
            }
        }
        return camelCase.toString();
    }
}