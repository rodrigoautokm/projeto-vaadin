package com.exemplo;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

@org.springframework.stereotype.Repository
public interface VendasRepository extends org.springframework.data.repository.Repository<Object[], Long> {

    @Query(value = "CALL pr_rel_vendas_r04(:param1, :dataInicio, :dataFim, :param4, :param5, :param6, :param7, " +
                   ":param8, :param9, :param10, :param11, :param12, :param13, :param14, :param15, :param16, " +
                   ":param17, :param18, :param19, :param20)", nativeQuery = true)
    List<Object[]> executarRelVendas(
        @Param("param1") int param1,
        @Param("dataInicio") String dataInicio,
        @Param("dataFim") String dataFim,
        @Param("param4") int param4,
        @Param("param5") int param5,
        @Param("param6") int param6,
        @Param("param7") int param7,
        @Param("param8") int param8,
        @Param("param9") int param9,
        @Param("param10") int param10,
        @Param("param11") int param11,
        @Param("param12") int param12,
        @Param("param13") String param13,
        @Param("param14") int param14,
        @Param("param15") String param15,
        @Param("param16") String param16,
        @Param("param17") int param17,
        @Param("param18") String param18,
        @Param("param19") String param19,
        @Param("param20") int param20
    );
}