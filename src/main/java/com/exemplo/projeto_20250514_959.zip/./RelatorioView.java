package com.exemplo;

import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.html.H1;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.router.*;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.*;

@Route(value = "rel_vendas", layout = MainLayout.class)
@RouteAlias(value = "rel_dre", layout = MainLayout.class)
@RouteAlias(value = "rel_listagem", layout = MainLayout.class)
@PageTitle("Relatório Dinâmico")
public class RelatorioView extends AbstractGridView<RelatorioDinamicoResult> implements BeforeEnterObserver {

    private final RelatorioService relatorioService;
    private final ParametroRelatorioService parametroService;
    private final GridColumnConfigRelatorioService gridColumnConfigRelatorioService;

    private String procedureName;
    private String tituloPagina;
    private Map<String, Object> parametrosSelecionados;

    @Autowired
    public RelatorioView(RelatorioService relatorioService,
                         ParametroRelatorioService parametroService,
                         GridColumnConfigRelatorioService gridColumnConfigRelatorioService) {
        super("Relatório", "relatorio", () -> List.of());
        this.relatorioService = relatorioService;
        this.parametroService = parametroService;
        this.gridColumnConfigRelatorioService = gridColumnConfigRelatorioService;
    }

    @Override
    public void beforeEnter(BeforeEnterEvent event) {
        String path = event.getLocation().getPath();
        switch (path) {
            case "rel_vendas":
                procedureName = "pr_rel_vendas_r04";
                tituloPagina = "Relatório de Vendas";
                break;
            case "rel_dre":
                procedureName = "pr_rel_demonstrativo_resultado_arvore";
                tituloPagina = "Relatório DRE";
                break;
            case "rel_listagem":
                procedureName = "pr_listagem_pedidos";
                tituloPagina = "Listagem de Pedidos";
                break;
            default:
                Notification.show("Rota inválida.");
                return;
        }

        H1 titulo = new H1(tituloPagina);
        Button parametrosBtn = new Button("Parâmetros", VaadinIcon.COG.create(), e -> abrirDialogParametros());

        HorizontalLayout topBar = new HorizontalLayout(titulo, parametrosBtn);
        topBar.setWidthFull();
        topBar.setSpacing(true);
        add(topBar);
    }

    private void abrirDialogParametros() {
        List<ParametroRelatorio> parametros = parametroService.getParametros(procedureName);
        System.out.println("🟡 Parâmetros carregados: " + parametros.size());
        for (ParametroRelatorio p : parametros) {
            System.out.printf("🔸 Parametro: field=%s, tipo=%s, header=%s%n", p.getField(), p.getTipo(), p.getHeader());
        }

        new ParametroDialogBuilder("Parâmetros", parametros, valores -> {
            this.parametrosSelecionados = valores;
            System.out.println("✅ Parâmetros selecionados: " + valores);
            try {
                List<RelatorioDinamicoResult> dados = relatorioService.executarProcedure(procedureName, valores);
                updateData(dados);
                Notification.show("Relatório carregado com " + dados.size() + " registros.");
            } catch (Exception ex) {
                ex.printStackTrace();
                Notification.show("Erro ao executar relatório: " + ex.getMessage(), 5000, Notification.Position.MIDDLE);
            }
        }).abrir();
    }

    @Override
    public Class<RelatorioDinamicoResult> getEntityClass() {
        return RelatorioDinamicoResult.class;
    }

   
    protected List<RelatorioDinamicoResult> getData() {
        return List.of();
    }

    @Override
    protected GenericRepository<RelatorioDinamicoResult, ?> getRepository() {
        return null;
    }

    @Override
    public List<GridFilterUtil.ColumnConfig<RelatorioDinamicoResult>> configureColumns() {
        List<GridFilterUtil.ColumnConfig<RelatorioDinamicoResult>> columnConfigs = new ArrayList<>();
        List<GridColumnConfig> configs = gridColumnConfigRelatorioService.getColumnConfigs(procedureName);

        System.out.println("🔁 Configurando colunas para " + procedureName + ": total = " + configs.size());

        for (GridColumnConfig config : configs) {
            if (!config.isVisible()) continue;

            Grid.Column<RelatorioDinamicoResult> column = grid.addColumn(item -> {
                Object value = item.getCampos().get(config.getField());
                return value != null ? value.toString() : "";
            }).setKey(config.getField());

            column.setHeader(config.getHeader());
            column.setSortable(true);
            column.setAutoWidth(true);
            if (config.getWidth() != null) {
                column.setWidth(config.getWidth());
            }
            if (config.getStyle() != null) {
                Arrays.stream(config.getStyle().split(";"))
                        .filter(rule -> rule.contains(":"))
                        .forEach(rule -> {
                            String[] parts = rule.split(":");
                            column.getElement().getStyle().set(parts[0].trim(), parts[1].trim());
                        });
            }

            columnConfigs.add(new GridFilterUtil.ColumnConfig<>(
                    column,
                    config.getHeader(),
                    item -> {
                        Object v = item.getCampos().get(config.getField());
                        return v != null ? v.toString() : null;
                    },
                    config
            ));
        }

        System.out.println("✅ Total de colunas configuradas: " + columnConfigs.size());
        return columnConfigs;
    }
}
