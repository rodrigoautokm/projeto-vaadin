package com.exemplo;

import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.datepicker.DatePicker;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.formlayout.FormLayout;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.NumberField;
import com.vaadin.flow.component.textfield.TextField;

import java.time.LocalDate;
import java.util.*;
import java.util.function.Consumer;

public class ParametroDialogBuilder {

    private final Dialog dialog;
    private final Map<String, Object> valores = new HashMap<>();
    private final Map<String, Component> componentes = new HashMap<>();

    public ParametroDialogBuilder(String titulo, List<ParametroRelatorio> parametros, Consumer<Map<String, Object>> onConfirmar) {
        dialog = new Dialog();
        dialog.setCloseOnOutsideClick(false);
        dialog.setCloseOnEsc(true);
        dialog.setWidth("600px");

        VerticalLayout layout = new VerticalLayout();
        layout.setSpacing(true);
        layout.setPadding(true);

        FormLayout formLayout = new FormLayout();

        for (ParametroRelatorio parametro : parametros) {
            Component input = criarComponenteParametro(parametro);
            if (input != null) {
                formLayout.addFormItem(input, parametro.getHeader());
                componentes.put(parametro.getField(), input);
            }
        }

        layout.add(formLayout);

        HorizontalLayout botoes = new HorizontalLayout();
        Button btnConfirmar = new Button("Executar", event -> {
            for (ParametroRelatorio parametro : parametros) {
                Component comp = componentes.get(parametro.getField());
                if (comp instanceof TextField) {
                    valores.put(parametro.getField(), ((TextField) comp).getValue());
                } else if (comp instanceof DatePicker) {
                    valores.put(parametro.getField(), ((DatePicker) comp).getValue());
                } else if (comp instanceof NumberField) {
                    valores.put(parametro.getField(), ((NumberField) comp).getValue());
                }
            }
            dialog.close();
            onConfirmar.accept(valores);
        });

        Button btnCancelar = new Button("Cancelar", event -> dialog.close());
        botoes.add(btnConfirmar, btnCancelar);
        layout.add(botoes);

        dialog.add(layout);
    }

    public void abrir() {
        dialog.open();
    }

    private Component criarComponenteParametro(ParametroRelatorio parametro) {
        String tipo = parametro.getTipo() != null ? parametro.getTipo().toUpperCase() : "";

        switch (tipo) {
            case "STRING":
                return new TextField();
            case "DATE":
                DatePicker dp = new DatePicker();
                dp.setLocale(new Locale("pt", "BR"));
                dp.setValue(LocalDate.now());
                return dp;
            case "NUMBER":
            case "DECIMAL":
            case "DOUBLE":
            case "FLOAT":
            case "INTEGER":
                NumberField nf = new NumberField();
                nf.setStep(1);
                nf.setHasControls(true);
                return nf;
            default:
                Notification.show("Tipo de parâmetro desconhecido: " + tipo);
                return null;
        }
    }
}
