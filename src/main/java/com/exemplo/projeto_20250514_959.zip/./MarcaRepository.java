package com.exemplo;

public interface MarcaRepository extends GenericRepository<Marca, Short> {
}