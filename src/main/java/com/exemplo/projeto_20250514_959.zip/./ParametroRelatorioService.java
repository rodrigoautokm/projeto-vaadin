package com.exemplo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
public class ParametroRelatorioService {

    private static final Logger logger = LoggerFactory.getLogger(ParametroRelatorioService.class);

    private final JdbcTemplate jdbcTemplate;

    public ParametroRelatorioService(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public List<ParametroRelatorio> getParametros(String procedureName) {
        logger.info("Buscando parâmetros para a procedure: {}", procedureName);
        List<ParametroRelatorio> parametros = new ArrayList<>();

        String sql = "SELECT parametro_nome, tipo, dropdown_values, visible " +
                     "FROM vw_procedure_parametros WHERE procedure_name = ? ORDER BY ordem";

        try {
            List<Map<String, Object>> rows = jdbcTemplate.queryForList(sql, procedureName);

            for (Map<String, Object> row : rows) {
                String nome = (String) row.get("parametro_nome");
                String tipo = (String) row.get("tipo");
                String dropdownValues = (String) row.getOrDefault("dropdown_values", "");
                Object visObj = row.get("visible");

                boolean visible = false;
                if (visObj instanceof Number) {
                    visible = ((Number) visObj).intValue() == 1;
                }

                ParametroRelatorio parametro = new ParametroRelatorio(nome, tipo, dropdownValues, visible);
                parametros.add(parametro);
                logger.debug("Parâmetro carregado: {}", parametro);
            }

            logger.info("Total de parâmetros carregados: {}", parametros.size());
        } catch (Exception e) {
            logger.error("Erro ao buscar parâmetros para procedure '{}': {}", procedureName, e.getMessage(), e);
        }

        return parametros;
    }
}
