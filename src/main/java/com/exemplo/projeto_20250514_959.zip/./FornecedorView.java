package com.exemplo;

import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import org.springframework.beans.factory.annotation.Autowired;

@PageTitle("Fornecedores")
@Route(value = "fornecedores", layout = MainLayout.class)
public class FornecedorView extends AbstractGridView<Fornecedor> {

    private final FornecedorRepository fornecedorRepository;

    @Autowired
    public FornecedorView(FornecedorRepository fornecedorRepository) {
        super("Fornecedores", "fornecedores", fornecedorRepository::findAll);
        this.fornecedorRepository = fornecedorRepository;
    }

    @Override
    public Class<Fornecedor> getEntityClass() {
        return Fornecedor.class;
    }

    @Override
    protected GenericRepository<Fornecedor, ?> getRepository() {
        return fornecedorRepository;
    }
}