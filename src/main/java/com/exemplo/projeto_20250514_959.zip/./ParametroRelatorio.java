package com.exemplo;

public class ParametroRelatorio {
    private String field;
    private String tipo;
    private String header;
    private boolean obrigatorio;

    public ParametroRelatorio(String field, String tipo, String header, boolean obrigatorio) {
        this.field = field;
        this.tipo = tipo;
        this.header = header;
        this.obrigatorio = obrigatorio;
    }

    public String getField() {
        return field;
    }

    public String getTipo() {
        return tipo;
    }

    public String getHeader() {
        return header;
    }

    public boolean isObrigatorio() {
        return obrigatorio;
    }

    public void setField(String field) {
        this.field = field;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public void setHeader(String header) {
        this.header = header;
    }

    public void setObrigatorio(boolean obrigatorio) {
        this.obrigatorio = obrigatorio;
    }
}
