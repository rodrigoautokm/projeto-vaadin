package com.exemplo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.*;

@Service
public class RelatorioService {

    private static final Logger logger = LoggerFactory.getLogger(RelatorioService.class);

    private final JdbcTemplate jdbcTemplate;

    public RelatorioService(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public List<RelatorioDinamicoResult> executarProcedure(String procedureName, Map<String, Object> parametros) {
        logger.info("Executando procedure: {}", procedureName);
        List<RelatorioDinamicoResult> resultados = new ArrayList<>();

        String sql = construirSqlChamada(procedureName, parametros.size());
        logger.debug("SQL gerado: {}", sql);

        try (Connection connection = jdbcTemplate.getDataSource().getConnection();
             CallableStatement stmt = connection.prepareCall(sql)) {

            int index = 1;
            for (Map.Entry<String, Object> entry : parametros.entrySet()) {
                Object valor = entry.getValue();
                if (valor instanceof String) {
                    stmt.setString(index, (String) valor);
                } else if (valor instanceof Integer) {
                    stmt.setInt(index, (Integer) valor);
                } else if (valor instanceof Double) {
                    stmt.setDouble(index, (Double) valor);
                } else if (valor instanceof java.util.Date) {
                    stmt.setDate(index, new Date(((java.util.Date) valor).getTime()));
                } else if (valor == null) {
                    stmt.setNull(index, Types.VARCHAR); // Tipo genérico
                } else {
                    stmt.setObject(index, valor);
                }
                index++;
            }

            boolean temResultado = stmt.execute();
            if (temResultado) {
                try (ResultSet rs = stmt.getResultSet()) {
                    while (rs.next()) {
                        Map<String, Object> row = new HashMap<>();
                        int colCount = rs.getMetaData().getColumnCount();
                        for (int i = 1; i <= colCount; i++) {
                            String colName = rs.getMetaData().getColumnLabel(i);
                            Object valor = rs.getObject(i);
                            row.put(colName, valor);
                        }
                        resultados.add(new RelatorioDinamicoResult(row));
                    }
                }
            }
        } catch (Exception e) {
            logger.error("Erro ao executar procedure {}: {}", procedureName, e.getMessage(), e);
            throw new RuntimeException("Erro ao executar procedure " + procedureName, e);
        }

        logger.info("Procedure {} retornou {} registros", procedureName, resultados.size());
        return resultados;
    }

    private String construirSqlChamada(String procedureName, int qtdParametros) {
        StringBuilder sb = new StringBuilder();
        sb.append("CALL ").append(procedureName).append("(");
        for (int i = 0; i < qtdParametros; i++) {
            if (i > 0) sb.append(", ");
            sb.append("?");
        }
        sb.append(")");
        return sb.toString();
    }
}
