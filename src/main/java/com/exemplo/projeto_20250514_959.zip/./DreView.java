package com.exemplo;

import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.datepicker.DatePicker;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.router.Route;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@Route(value = "dre", layout = MainLayout.class)
public class DreView extends AbstractGridView<DreItem> {

    private static final Logger logger = LoggerFactory.getLogger(DreView.class);

    private final DreService dreService;
    private final GridColumnConfigService columnConfigService;
    private DatePicker dataInicioPicker;
    private DatePicker dataFimPicker;

    @Autowired
    public DreView(DreService dreService, GridColumnConfigService columnConfigService) {
        super("Relatório DRE", "dre", () -> new ArrayList<>());
        logger.info("Inicializando DreView");
        this.dreService = dreService;
        this.columnConfigService = columnConfigService;

        LocalDate inicio = LocalDate.of(2023, 4, 1);
        LocalDate fim = LocalDate.of(2024, 1, 1);
        dataInicioPicker = new DatePicker("Data Início");
        dataInicioPicker.setValue(inicio);
        dataInicioPicker.getStyle()
            .set("margin-right", "10px");

        dataFimPicker = new DatePicker("Data Fim");
        dataFimPicker.setValue(fim);
        dataFimPicker.getStyle()
            .set("margin-right", "10px");

        Button gerarButton = new Button("Gerar");
        gerarButton.getStyle()
            .set("margin", "0");
        gerarButton.addClickListener(event -> atualizarGrid());

        HorizontalLayout filtros = new HorizontalLayout(dataInicioPicker, dataFimPicker, gerarButton);
        addFilters(filtros);
    }

    @Override
    public Class<DreItem> getEntityClass() {
        return DreItem.class;
    }

    @Override
    public List<GridFilterUtil.ColumnConfig<DreItem>> configureColumns() {
        logger.info("Configurando grid com GridFilterUtil");

        String[] fields = {
            "agrupa", "descricao", "valor", "fornecedor", "situacao",
            "data_emissao", "data_vencimento", "data_pagamento", "observacao", "despesa1"
        };

        List<GridFilterUtil.ColumnConfig<DreItem>> columnConfigs = new ArrayList<>();
        for (String field : fields) {
            GridColumnConfig config = columnConfigService.getColumnConfig(field);
            if (config == null) {
                logger.warn("Configuração não encontrada para o campo: {}. Usando configuração padrão.", field);
                config = new GridColumnConfig();
                config.setField(field);
                config.setHeader(field);
                config.setWidth("100px");
                config.setVisible(true);
                config.setType("STRING");
            }

            logger.debug("Configuração para o campo {}: header={}, visible={}, width={}, type={}, style={}",
                field, config.getHeader(), config.isVisible(), config.getWidth(), config.getType(), config.getStyle());

            if (config.isVisible()) {
                logger.debug("Adicionando coluna: {}", field);
                Grid.Column<DreItem> column = grid.addColumn(item -> {
                    try {
                        switch (field) {
                            case "agrupa":
                                return item.getAgrupa();
                            case "descricao":
                                return item.getDescricao();
                            case "valor":
                                return item.getValor();
                            case "fornecedor":
                                return item.getFornecedor();
                            case "situacao":
                                return item.getSituacao();
                            case "data_emissao":
                                return item.getDataEmissao();
                            case "data_vencimento":
                                return item.getDataVencimento();
                            case "data_pagamento":
                                return item.getDataPagamento();
                            case "observacao":
                                return item.getObservacao();
                            case "despesa1":
                                return item.getDespesa1();
                            default:
                                logger.warn("Campo não reconhecido: {}", field);
                                return null;
                        }
                    } catch (Exception e) {
                        logger.error("Erro ao acessar o campo {} para o item DRE: {}", field, item, e);
                        return null;
                    }
                }).setKey(field);

                column.setHeader(config.getHeader());
                column.setWidth(config.getWidth());
                column.setSortable(true);
                column.setVisible(true);
                column.setAutoWidth(false);

                if (config.getStyle() != null && !config.getStyle().isEmpty()) {
                    String[] styleRules = config.getStyle().split(";");
                    for (String rule : styleRules) {
                        if (rule.trim().isEmpty()) continue;
                        String[] parts = rule.split(":");
                        if (parts.length == 2) {
                            String property = parts[0].trim();
                            String value = parts[1].trim();
                            column.getElement().getStyle().set(property, value);
                            logger.debug("Estilo aplicado à coluna {}: {}: {}", field, property, value);
                        }
                    }
                }

                GridFilterUtil.ColumnConfig<DreItem> columnConfig = new GridFilterUtil.ColumnConfig<>(
                    column,
                    config.getHeader(),
                    item -> {
                        switch (field) {
                            case "agrupa":
                                return item.getAgrupa();
                            case "descricao":
                                return item.getDescricao();
                            case "valor":
                                return item.getValor() != null ? String.valueOf(item.getValor()) : null;
                            case "fornecedor":
                                return item.getFornecedor();
                            case "situacao":
                                return item.getSituacao();
                            case "data_emissao":
                                return item.getDataEmissao();
                            case "data_vencimento":
                                return item.getDataVencimento();
                            case "data_pagamento":
                                return item.getDataPagamento();
                            case "observacao":
                                return item.getObservacao();
                            case "despesa1":
                                return item.getDespesa1();
                            default:
                                return null;
                        }
                    },
                    config
                );

                columnConfigs.add(columnConfig);
            }
        }

        logger.info("Total de colunas configuradas: {}", grid.getColumns().size());

        if (grid.getColumns().size() < 2) {
            logger.warn("Número de colunas insuficiente para mesclagem. Adicionando colunas fictícias.");
            grid.addColumn(item -> "").setKey("dummy1").setHeader("").setVisible(false);
            grid.addColumn(item -> "").setKey("dummy2").setHeader("").setVisible(false);
        }

        return columnConfigs;
    }

    private void atualizarGrid() {
        LocalDateTime inicio = dataInicioPicker.getValue().atStartOfDay();
        LocalDateTime fim = dataFimPicker.getValue().atTime(23, 59, 59, 999000000);
        try {
            items = dreService.consultarDre(formatarData(inicio), formatarData(fim));
            if (items == null || items.isEmpty()) {
                logger.warn("Nenhum dado encontrado para o período selecionado");
                Notification.show("Nenhum dado encontrado.", 3000, Notification.Position.MIDDLE);
                items = new ArrayList<>();
                items.add(new DreItem("Teste", "Descrição Teste", 1000.0, "Fornecedor", "Ativo",
                        "2023-10-01", "2023-10-15", "2023-10-10", "Obs", "Despesa"));
            }
            updateData(items);
        } catch (Exception e) {
            logger.error("Erro ao atualizar a grid", e);
            Notification.show("Erro ao buscar dados: " + e.getMessage(), 3000, Notification.Position.MIDDLE);
            updateData(new ArrayList<>());
        }
    }

    private String formatarData(LocalDateTime data) {
        return data.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS"));
    }

    @Override
    protected GenericRepository<DreItem, ?> getRepository() {
        return null;
    }
}