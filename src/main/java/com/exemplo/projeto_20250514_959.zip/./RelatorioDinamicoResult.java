package com.exemplo;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class RelatorioDinamicoResult implements Serializable {

    private Map<String, Object> campos = new HashMap<>();

    public RelatorioDinamicoResult() {
    }

    public RelatorioDinamicoResult(Map<String, Object> campos) {
        this.campos = campos;
    }

    public Map<String, Object> getCampos() {
        return campos;
    }

    public void setCampos(Map<String, Object> campos) {
        this.campos = campos;
    }
}
