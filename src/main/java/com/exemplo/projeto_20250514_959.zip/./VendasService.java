package com.exemplo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class VendasService {

    private static final Logger logger = LoggerFactory.getLogger(VendasService.class);

    @Autowired
    private VendasRepository vendasRepository;

    public List<VendasItem> executarRelVendas(int param1, String dataInicio, String dataFim, int param4, int param5,
                                              int param6, int param7, int param8, int param9, int param10, int param11,
                                              int param12, String param13, int param14, String param15, String param16,
                                              int param17, String param18, String param19, int param20) {
        logger.info("Consultando Vendas via Repositório para o período: {} a {}", dataInicio, dataFim);

        CustomUserDetails userDetails = (CustomUserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Integer cdEmpresa = userDetails.getCdEmpresa().intValue();
        logger.info("Usuário autenticado com cdEmpresa: {}", cdEmpresa.intValue());

        try {
            List<Object[]> resultados = vendasRepository.executarRelVendas(
                param1, dataInicio, dataFim, param4, param5, param6, param7, param8, param9, param10,
                param11, param12, param13, param14, param15, param16, param17, param18, param19, param20
            );

            List<VendasItem> vendasItens = new ArrayList<>();
            for (Object[] tuple : resultados) {
                VendasItem item = new VendasItem(
                    safeString(tuple, 0),  // nr_pedido
                    safeString(tuple, 1),  // nm_cliente
                    safeString(tuple, 2),  // ds_produto
                    safeDouble(tuple, 3),  // qt_produto
                    safeDouble(tuple, 4),  // vl_unitario
                    safeDouble(tuple, 5),  // vl_desconto
                    safeDouble(tuple, 6),  // vl_custo
                    safeString(tuple, 7),  // dt_emissao
                    safeString(tuple, 8),  // situacao
                    safeString(tuple, 9)   // ds_grupo
                );
                vendasItens.add(item);
            }

            logger.info("Consulta executada com sucesso. Total de itens: {}", vendasItens.size());
            return vendasItens;

        } catch (Exception e) {
            logger.error("Erro ao consultar vendas via Repositório: {}", e.getMessage(), e);
            return new ArrayList<>();
        }
    }

    private String safeString(Object[] row, int index) {
        try {
            Object value = row[index];
            return value != null ? value.toString() : "N/A";
        } catch (Exception e) {
            return "N/A";
        }
    }

    private Double safeDouble(Object[] row, int index) {
        try {
            Object value = row[index];
            return value != null ? Double.parseDouble(value.toString().replace(",", ".")) : 0.0;
        } catch (Exception e) {
            return 0.0;
        }
    }
}