package com.exemplo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class GridColumnConfigService {

    private static final Logger logger = LoggerFactory.getLogger(GridColumnConfigService.class);

    @Autowired
    private JdbcTemplate jdbcTemplate;

    private final Map<String, Map<String, GridColumnConfig>> cache = new HashMap<>();

    public List<GridColumnConfig> listar() {
        logger.debug("Listando configurações de colunas da view vw_column_config");

        // Limpar o cache antes de carregar novas configurações
        limparCache();
        logger.debug("Cache limpo antes de carregar configurações.");

        String sql = "SELECT id, class_name, field_name, header, type, visible, numeric_width, width, style, filter_type, dropdown_values, alias " +
                    "FROM vw_column_config";
        List<Map<String, Object>> rows;
        try {
            rows = jdbcTemplate.queryForList(sql);
        } catch (Exception e) {
            logger.error("Erro ao executar consulta SQL para vw_column_config: {}", e.getMessage(), e);
            return new ArrayList<>();
        }

        List<GridColumnConfig> configs = new ArrayList<>();
        for (Map<String, Object> row : rows) {
            GridColumnConfig config = new GridColumnConfig();

            // Tratar id como BigDecimal e converter para Integer
            Object idObj = row.get("id");
            if (idObj instanceof BigDecimal) {
                config.setId(((BigDecimal) idObj).intValue());
            } else if (idObj instanceof Integer) {
                config.setId((Integer) idObj);
            } else {
                logger.warn("Valor de id não é BigDecimal nem Integer: {}", idObj);
                config.setId(0); // Valor padrão
            }

            config.setClassName((String) row.get("class_name"));
            config.setField((String) row.get("field_name"));
            config.setHeader((String) row.get("header"));
            config.setType((String) row.get("type"));

            // Tratar visible como BigDecimal e converter para Integer
            Object visibleObj = row.get("visible");
            boolean visible;
            if (visibleObj instanceof BigDecimal) {
                visible = ((BigDecimal) visibleObj).intValue() == 1;
            } else if (visibleObj instanceof Integer) {
                visible = (Integer) visibleObj == 1;
            } else {
                logger.warn("Valor de visible não é BigDecimal nem Integer: {}", visibleObj);
                visible = false; // Valor padrão
            }
            config.setVisible(visible);

            // Tratar numeric_width como BigDecimal e converter para Integer
            Object numericWidthObj = row.get("numeric_width");
            if (numericWidthObj instanceof BigDecimal) {
                config.setNumericWidth(((BigDecimal) numericWidthObj).intValue());
            } else if (numericWidthObj instanceof Integer) {
                config.setNumericWidth((Integer) numericWidthObj);
            } else {
                logger.warn("Valor de numeric_width não é BigDecimal nem Integer: {}", numericWidthObj);
                config.setNumericWidth(100); // Valor padrão
            }

            config.setWidth((String) row.get("width"));
            config.setStyle((String) row.get("style"));
            config.setFilterType((String) row.get("filter_type"));
            config.setDropdownValues((String) row.get("dropdown_values"));
            config.setAlias((String) row.get("alias"));

            // Preencher dropdownValueMap a partir de dropdown_values
            if (config.getDropdownValues() != null && !config.getDropdownValues().isEmpty()) {
                Map<String, String> dropdownValueMap = new HashMap<>();
                String[] pairs = config.getDropdownValues().split(";");
                for (String pair : pairs) {
                    String[] keyValue = pair.split("=");
                    if (keyValue.length == 2) {
                        dropdownValueMap.put(keyValue[0], keyValue[1]);
                    }
                }
                config.setDropdownValueMap(dropdownValueMap);
            }

            configs.add(config);
            logger.debug("Configuração carregada: class_name={}, field_name={}, header={}, type={}, visible={}, width={}",
                config.getClassName(), config.getField(), config.getHeader(), config.getType(), config.isVisible(), config.getWidth());
        }

        logger.info("Total de configurações carregadas: {}", configs.size());
        return configs;
    }

    public GridColumnConfig getColumnConfig(String field) {
        logger.debug("Buscando configuração para o campo: {}", field);
        List<GridColumnConfig> configs = listar();
        return configs.stream()
                .filter(config -> config.getField().equalsIgnoreCase(field))
                .findFirst()
                .orElse(null);
    }

    public GridColumnConfig getColumnConfig(String className, String usuario, String fieldName) {
        logger.debug("Buscando configuração para class_name: {}, usuario: {}, field_name: {}", className, usuario, fieldName);

        String key = (className + "_" + usuario).toLowerCase();
        Map<String, GridColumnConfig> cachedConfigs = cache.get(key);
        if (cachedConfigs == null) {
            List<GridColumnConfig> configs = listar();
            Map<String, GridColumnConfig> map = new HashMap<>();
            for (GridColumnConfig config : configs) {
                if (config.getClassName().equalsIgnoreCase(className)) {
                    map.put(config.getField().toLowerCase(), config);
                }
            }
            cache.put(key, map);
            cachedConfigs = map;
        }

        GridColumnConfig config = cachedConfigs.get(fieldName.toLowerCase());
        if (config == null) {
            logger.warn("Configuração não encontrada para class_name: {}, field_name: {}", className, fieldName);
        }
        return config;
    }

    public void limparCache() {
        logger.debug("Limpando cache de configurações de colunas");
        cache.clear();
    }

public List<GridColumnConfig> getConfigsForClass(String className) {
    return listar().stream()
        .filter(config -> config.getClassName() != null && config.getClassName().equalsIgnoreCase(className))
        .toList();
}

public List<GridColumnConfig> getColumnConfigs(String className) {
    logger.debug("Buscando configurações para a classe: {}", className);
    return listar().stream()
        .filter(config -> config.getClassName().equalsIgnoreCase(className))
        .toList();
}


}