package com.exemplo;

import com.vaadin.flow.router.BeforeEnterEvent;
import com.vaadin.flow.router.BeforeEnterObserver;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.component.Component; // Importação adicionada
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

@PageTitle("Fornecedores")
@Route(value = "fornecedores", layout = MainLayout.class)
public class FornecedorView extends AbstractGridView<Fornecedor> implements BeforeEnterObserver {

    private static final Logger logger = LoggerFactory.getLogger(FornecedorView.class);
    private final FornecedorRepository fornecedorRepository;

    @Autowired
    private DataSourceHelper dataSourceHelper;

    @Autowired
    public FornecedorView(FornecedorRepository fornecedorRepository) {
        super("Fornecedores", Fornecedor.class, fornecedorRepository::findAll);
        logger.info("Inicializando FornecedorView com gridId 'fornecedor'");
        this.fornecedorRepository = fornecedorRepository;
    }

    
    protected Fornecedor createNewItem() {
        return new Fornecedor();
    }

    @Override
    public Class<Fornecedor> getEntityClass() {
        logger.info("Retornando classe de entidade Fornecedor");
        return Fornecedor.class;
    }

    @Override
    protected Object getRepository() {
        logger.info("Retornando repositório de Fornecedor");
        return fornecedorRepository;
    }

    @Override
    public void beforeEnter(BeforeEnterEvent event) {
        if (dataSourceHelper != null) {
            dataSourceHelper.configurarDataSourceAtual();
            logger.info("DataSource configurado para FornecedorView");
        } else {
            logger.warn("DataSourceHelper é nulo para FornecedorView. Verifique a configuração do Spring.");
        }

        // Inicializa gridUtil e configura as colunas
        if (gridColumnConfigService == null) {
            logger.error("gridColumnConfigService é nulo para {}. Verifique a configuração do Spring.", title);
            return;
        }

        this.columnConfigs = configureColumns();
        logger.info("ColumnConfigs gerados: {}", columnConfigs != null ? columnConfigs.size() : 0);
        if (columnConfigs == null || columnConfigs.isEmpty()) {
            logger.error("Nenhuma coluna configurada para {}. GridFilterUtil não será inicializado.", title);
            return;
        }

        gridUtil = new GridFilterUtil<>(gridId, grid, columnConfigs, getUsuarioId(), getCdEmpresaUsuario());
        logger.info("GridFilterUtil inicializado com gridId={}, usuarioId={}, cdEmpresa={}", gridId, getUsuarioId(), getCdEmpresaUsuario());

        Component filterLayout = gridUtil.getLayout();
        if (filterLayout != null) {
            add(filterLayout);
            logger.debug("Layout do GridFilterUtil adicionado à view.");
        } else {
            logger.error("Layout do GridFilterUtil é nulo para {}.", title);
        }
    }
}