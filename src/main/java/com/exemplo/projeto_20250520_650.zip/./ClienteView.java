package com.exemplo;

import com.vaadin.flow.router.BeforeEnterEvent;
import com.vaadin.flow.router.BeforeEnterObserver;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import com.vaadin.flow.component.Component;

@PageTitle("Clientes")
@Route(value = "clientes", layout = MainLayout.class)
public class ClienteView extends AbstractGridView<Cliente> implements BeforeEnterObserver {

    private static final Logger logger = LoggerFactory.getLogger(ClienteView.class);
    private final ClienteRepository clienteRepository;

    @Autowired
    private DataSourceHelper dataSourceHelper;

    @Autowired
    public ClienteView(ClienteRepository clienteRepository) {
        super("Clientes", Cliente.class, clienteRepository::findAll);
        logger.info("Inicializando ClienteView com gridId 'cliente'");
        this.clienteRepository = clienteRepository;
    }

    
    protected Cliente createNewItem() {
        return new Cliente();
    }

    @Override
    public Class<Cliente> getEntityClass() {
        logger.info("Retornando classe de entidade Cliente");
        return Cliente.class;
    }

    @Override
    protected Object getRepository() {
        logger.info("Retornando repositório de Cliente");
        return clienteRepository;
    }

    @Override
    public void beforeEnter(BeforeEnterEvent event) {
        if (dataSourceHelper != null) {
            dataSourceHelper.configurarDataSourceAtual();
            logger.info("DataSource configurado para ClienteView");
        } else {
            logger.warn("DataSourceHelper é nulo para ClienteView. Verifique a configuração do Spring.");
        }

        // Inicializa gridUtil e configura as colunas
        if (gridColumnConfigService == null) {
            logger.error("gridColumnConfigService é nulo para {}. Verifique a configuração do Spring.", title);
            return;
        }

        this.columnConfigs = configureColumns();
        logger.info("ColumnConfigs gerados: {}", columnConfigs != null ? columnConfigs.size() : 0);
        if (columnConfigs == null || columnConfigs.isEmpty()) {
            logger.error("Nenhuma coluna configurada para {}. GridFilterUtil não será inicializado.", title);
            return;
        }

        gridUtil = new GridFilterUtil<>(gridId, grid, columnConfigs, getUsuarioId(), getCdEmpresaUsuario());
        logger.info("GridFilterUtil inicializado com gridId={}, usuarioId={}, cdEmpresa={}", gridId, getUsuarioId(), getCdEmpresaUsuario());

        Component filterLayout = gridUtil.getLayout();
        if (filterLayout != null) {
            add(filterLayout);
            logger.debug("Layout do GridFilterUtil adicionado à view.");
        } else {
            logger.error("Layout do GridFilterUtil é nulo para {}.", title);
        }
    }
}