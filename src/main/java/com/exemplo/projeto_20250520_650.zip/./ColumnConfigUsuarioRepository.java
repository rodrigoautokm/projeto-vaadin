package com.exemplo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ColumnConfigUsuarioRepository extends JpaRepository<ColumnConfigUsuario, Integer> {

    List<ColumnConfigUsuario> findByUsuarioAndClassName(String usuario, String className);

    void deleteByUsuarioAndClassName(String usuario, String className);
}