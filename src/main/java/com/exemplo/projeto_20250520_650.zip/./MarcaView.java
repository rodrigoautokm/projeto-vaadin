package com.exemplo;

import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.router.BeforeEnterEvent;
import com.vaadin.flow.router.BeforeEnterObserver;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.component.Component; // Importação para o tipo Component do Vaadin
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

// Removida a importação direta de org.springframework.stereotype.Component
// A anotação @Component será resolvida automaticamente como org.springframework.stereotype.Component

@Route(value = "marcas", layout = MainLayout.class)
@org.springframework.stereotype.Component // Usando o nome qualificado para evitar ambiguidade
public class MarcaView extends AbstractGridView<Marca> implements BeforeEnterObserver {

    private static final Logger logger = LoggerFactory.getLogger(MarcaView.class);
    private final MarcaRepository repository;

    @Autowired
    public MarcaView(MarcaRepository repository) {
        super("Marcas", Marca.class, repository::findAll);
        logger.info("Inicializando MarcaView com gridId 'marca'");
        this.repository = repository;
    }

    
    protected Marca createNewItem() {
        return new Marca();
    }

    @Override
    public Class<Marca> getEntityClass() {
        logger.info("Retornando classe de entidade Marca");
        return Marca.class;
    }

    @Override
    protected Object getRepository() {
        logger.info("Retornando repositório de Marca");
        return repository;
    }

    @Override
    public void beforeEnter(BeforeEnterEvent event) {
        logger.info("Executando beforeEnter em MarcaView");
        if (!isUserAuthenticated()) {
            logger.warn("Usuário não autenticado, redirecionando para login");
            event.rerouteTo("login");
            Notification.show("Por favor, faça login para acessar esta página.", 3000, Notification.Position.TOP_CENTER);
            return;
        }

        // Inicializa gridUtil e configura as colunas
        if (gridColumnConfigService == null) {
            logger.error("gridColumnConfigService é nulo para {}. Verifique a configuração do Spring.", title);
            return;
        }

        this.columnConfigs = configureColumns();
        logger.info("ColumnConfigs gerados: {}", columnConfigs != null ? columnConfigs.size() : 0);
        if (columnConfigs == null || columnConfigs.isEmpty()) {
            logger.error("Nenhuma coluna configurada para {}. GridFilterUtil não será inicializado.", title);
            return;
        }

        gridUtil = new GridFilterUtil<>(gridId, grid, columnConfigs, getUsuarioId(), getCdEmpresaUsuario());
        logger.info("GridFilterUtil inicializado com gridId={}, usuarioId={}, cdEmpresa={}", gridId, getUsuarioId(), getCdEmpresaUsuario());

        Component filterLayout = gridUtil.getLayout();
        if (filterLayout != null) {
            add(filterLayout);
            logger.debug("Layout do GridFilterUtil adicionado à view.");
        } else {
            logger.error("Layout do GridFilterUtil é nulo para {}.", title);
        }
    }

    private boolean isUserAuthenticated() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        boolean isAuthenticated = authentication != null && authentication.isAuthenticated() && !"anonymousUser".equals(authentication.getPrincipal());
        logger.info("Verificação de autenticação: {}", isAuthenticated);
        return isAuthenticated;
    }
}
